<?php
/**
 * Plugin Name: WooCommerce Nostr Market
 * Plugin URI: https://github.com/sovereign-marketplace/woo-nostr-market
 * Description: Sync WooCommerce products to Nostr NIP-15 marketplace protocol
 * Version: 1.0.0
 * Author: Sovereign Marketplace
 * Author URI: https://sovereign-marketplace.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: woo-nostr-market
 * Domain Path: /languages
 * Requires at least: 6.0
 * Requires PHP: 7.4
 * WC requires at least: 7.0
 * WC tested up to: 8.5
 *
 * @package WooNostrMarket
 */

defined( 'ABSPATH' ) || exit;

// Plugin constants.
define( 'WOO_NOSTR_MARKET_VERSION', '1.3.0' );
define( 'WOO_NOSTR_MARKET_PLUGIN_FILE', __FILE__ );
define( 'WOO_NOSTR_MARKET_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WOO_NOSTR_MARKET_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

/**
 * Main plugin class.
 */
final class WooNostrMarket {

	/**
	 * Plugin instance.
	 *
	 * @var WooNostrMarket
	 */
	private static $instance = null;

	/**
	 * Settings instance.
	 *
	 * @var WooNostrMarket_Settings
	 */
	public $settings;

	/**
	 * Nostr client instance.
	 *
	 * @var WooNostrMarket_Nostr_Client
	 */
	public $nostr_client;

	/**
	 * Stall manager instance.
	 *
	 * @var WooNostrMarket_Stall_Manager
	 */
	public $stall_manager;

	/**
	 * Product sync instance.
	 *
	 * @var WooNostrMarket_Product_Sync
	 */
	public $product_sync;

	/**
	 * Get plugin instance.
	 *
	 * @return WooNostrMarket
	 */
	public static function instance() {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor.
	 */
	private function __construct() {
		$this->init_hooks();
	}

	/**
	 * Initialize hooks.
	 */
	private function init_hooks() {
		register_activation_hook( __FILE__, array( $this, 'activate' ) );
		register_deactivation_hook( __FILE__, array( $this, 'deactivate' ) );

		add_action( 'plugins_loaded', array( $this, 'init' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
	}

	/**
	 * Plugin activation.
	 */
	public function activate() {
		// Check WooCommerce dependency.
		if ( ! class_exists( 'WooCommerce' ) ) {
			deactivate_plugins( plugin_basename( __FILE__ ) );
			wp_die(
				esc_html__( 'WooCommerce Nostr Market requires WooCommerce to be installed and active.', 'woo-nostr-market' ),
				'Plugin dependency check',
				array( 'back_link' => true )
			);
		}

		// Create default options.
		$defaults = array(
			'nostr_private_key' => '',
			'nostr_public_key'  => '',
			'relay_urls'        => array(
				'wss://relay.damus.io',
				'wss://nos.lol',
				'wss://relay.nostr.band',
			),
			'btcpay_url'        => '',
			'btcpay_api_key'    => '',
			'btcpay_store_id'   => '',
			'lightning_address' => '',
			'stall_id'          => '',
			'webhook_secret'    => '',
			'enable_nip15'      => true,  // Plebeian Market, LNbits NostrMarket.
			'enable_nip99'      => true,  // Shopstr.
		);

		foreach ( $defaults as $key => $value ) {
			if ( false === get_option( 'woo_nostr_market_' . $key ) ) {
				add_option( 'woo_nostr_market_' . $key, $value );
			}
		}

		// Create stall ID if not exists.
		if ( empty( get_option( 'woo_nostr_market_stall_id' ) ) ) {
			update_option( 'woo_nostr_market_stall_id', wp_generate_uuid4() );
		}

		// Flush rewrite rules.
		flush_rewrite_rules();
	}

	/**
	 * Plugin deactivation.
	 */
	public function deactivate() {
		flush_rewrite_rules();
	}

	/**
	 * Initialize plugin.
	 */
	public function init() {
		// Check WooCommerce dependency.
		if ( ! $this->check_woocommerce() ) {
			return;
		}

		$this->load_classes();
		$this->init_classes();
	}

	/**
	 * Check if WooCommerce is active.
	 *
	 * @return bool
	 */
	private function check_woocommerce() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			add_action( 'admin_notices', array( $this, 'woocommerce_missing_notice' ) );
			return false;
		}
		return true;
	}

	/**
	 * WooCommerce missing notice.
	 */
	public function woocommerce_missing_notice() {
		?>
		<div class="notice notice-error">
			<p>
				<?php
				printf(
					/* translators: %s: WooCommerce plugin link */
					esc_html__( 'WooCommerce Nostr Market requires %s to be installed and active.', 'woo-nostr-market' ),
					'<a href="https://woocommerce.com/" target="_blank">WooCommerce</a>'
				);
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * Load plugin classes.
	 */
	private function load_classes() {
		require_once WOO_NOSTR_MARKET_PLUGIN_DIR . 'includes/class-secp256k1.php';
		require_once WOO_NOSTR_MARKET_PLUGIN_DIR . 'includes/class-settings.php';
		require_once WOO_NOSTR_MARKET_PLUGIN_DIR . 'includes/class-nostr-client.php';
		require_once WOO_NOSTR_MARKET_PLUGIN_DIR . 'includes/class-stall-manager.php';
		require_once WOO_NOSTR_MARKET_PLUGIN_DIR . 'includes/class-product-sync.php';
		require_once WOO_NOSTR_MARKET_PLUGIN_DIR . 'includes/class-order-listener.php';
		require_once WOO_NOSTR_MARKET_PLUGIN_DIR . 'includes/class-nip07-ajax.php';
		require_once WOO_NOSTR_MARKET_PLUGIN_DIR . 'includes/class-webhook-api.php';

		if ( is_admin() ) {
			require_once WOO_NOSTR_MARKET_PLUGIN_DIR . 'admin/class-admin-page.php';
		}
	}

	/**
	 * Order listener instance.
	 *
	 * @var WooNostrMarket_Order_Listener
	 */
	public $order_listener;

	/**
	 * Webhook API instance.
	 *
	 * @var WooNostrMarket_Webhook_API
	 */
	public $webhook_api;

	/**
	 * Initialize plugin classes.
	 */
	private function init_classes() {
		$this->settings      = new WooNostrMarket_Settings();
		$this->nostr_client  = new WooNostrMarket_Nostr_Client( $this->settings );
		$this->stall_manager = new WooNostrMarket_Stall_Manager( $this->settings, $this->nostr_client );
		$this->product_sync  = new WooNostrMarket_Product_Sync( $this->settings, $this->nostr_client, $this->stall_manager );

		// Order listener for processing Nostr orders.
		$this->order_listener = new WooNostrMarket_Order_Listener( $this->settings, $this->nostr_client );

		// Webhook API for receiving orders from nostr-order-listener service.
		$this->webhook_api = new WooNostrMarket_Webhook_API( $this->settings, $this->nostr_client, $this->order_listener );

		// NIP-07 AJAX handlers for browser extension signing.
		new WooNostrMarket_NIP07_Ajax( $this->settings, $this->stall_manager, $this->product_sync );

		if ( is_admin() ) {
			new WooNostrMarket_Admin_Page( $this->settings, $this->nostr_client, $this->stall_manager, $this->product_sync );
		}
	}

	/**
	 * Enqueue admin assets.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_admin_assets( $hook ) {
		if ( 'woocommerce_page_woo-nostr-market' !== $hook ) {
			return;
		}

		wp_enqueue_style(
			'woo-nostr-market-admin',
			WOO_NOSTR_MARKET_PLUGIN_URL . 'assets/css/admin.css',
			array(),
			WOO_NOSTR_MARKET_VERSION
		);

		// NIP-07 browser signing JavaScript.
		wp_enqueue_script(
			'woo-nostr-market-nip07',
			WOO_NOSTR_MARKET_PLUGIN_URL . 'assets/js/nip07-signer.js',
			array( 'jquery' ),
			WOO_NOSTR_MARKET_VERSION,
			true
		);

		// Localize script with AJAX URL and nonce.
		wp_localize_script(
			'woo-nostr-market-nip07',
			'wooNostrMarket',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'woo_nostr_market_nip07' ),
			)
		);
	}
}

/**
 * Get plugin instance.
 *
 * @return WooNostrMarket
 */
function woo_nostr_market() {
	return WooNostrMarket::instance();
}

// Initialize plugin.
woo_nostr_market();
