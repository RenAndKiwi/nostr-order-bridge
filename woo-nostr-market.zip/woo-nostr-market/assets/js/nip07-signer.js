/**
 * NIP-07 Browser Extension Signer
 * 
 * Handles Nostr event signing via browser extensions (Alby, nos2x, etc.)
 * Private key never touches the server - signing happens client-side.
 * 
 * @package WooNostrMarket
 */

(function($) {
    'use strict';

    const WooNostrNIP07 = {
        /**
         * Relay URLs (loaded from settings).
         */
        relays: [],

        /**
         * Check if NIP-07 extension is available.
         * @returns {boolean}
         */
        isAvailable: function() {
            return typeof window.nostr !== 'undefined';
        },

        /**
         * Load relay URLs from the settings textarea.
         * @returns {string[]}
         */
        getRelays: function() {
            const textarea = document.querySelector('textarea[name="woo_nostr_market_relay_urls"]');
            if (textarea && textarea.value) {
                return textarea.value.split('\n').map(r => r.trim()).filter(r => r.startsWith('wss://') || r.startsWith('ws://'));
            }
            return ['wss://relay.damus.io', 'wss://nos.lol', 'wss://relay.nostr.band'];
        },

        /**
         * Publish a signed event directly to relays via WebSocket (browser-side).
         * @param {Object} signedEvent - Fully signed Nostr event
         * @returns {Promise<{success: number, failed: number, total: number}>}
         */
        publishToRelays: function(signedEvent) {
            const relays = this.getRelays();
            const timeout = 8000;

            const publishToOne = (relayUrl) => {
                return new Promise((resolve) => {
                    try {
                        const ws = new WebSocket(relayUrl);
                        let settled = false;
                        const timer = setTimeout(() => {
                            if (!settled) { settled = true; ws.close(); resolve({ relay: relayUrl, success: false, error: 'timeout' }); }
                        }, timeout);

                        ws.onopen = () => {
                            ws.send(JSON.stringify(['EVENT', signedEvent]));
                        };
                        ws.onmessage = (msg) => {
                            try {
                                const data = JSON.parse(msg.data);
                                if (data[0] === 'OK' && data[1] === signedEvent.id) {
                                    clearTimeout(timer);
                                    if (!settled) { settled = true; ws.close(); resolve({ relay: relayUrl, success: data[2] !== false, message: data[3] || '' }); }
                                }
                            } catch(e) {}
                        };
                        ws.onerror = () => {
                            clearTimeout(timer);
                            if (!settled) { settled = true; ws.close(); resolve({ relay: relayUrl, success: false, error: 'connection error' }); }
                        };
                    } catch (e) {
                        resolve({ relay: relayUrl, success: false, error: e.message });
                    }
                });
            };

            return Promise.all(relays.map(publishToOne)).then((results) => {
                const success = results.filter(r => r.success).length;
                console.log('Relay publish results:', results);
                return { success, failed: results.length - success, total: results.length, results };
            });
        },

        /**
         * Get public key from extension.
         * @returns {Promise<string>} Hex public key
         */
        getPublicKey: async function() {
            if (!this.isAvailable()) {
                throw new Error('No NIP-07 extension detected. Please install Alby or nos2x.');
            }
            return await window.nostr.getPublicKey();
        },

        /**
         * Sign an event using the browser extension.
         * @param {Object} unsignedEvent - Event without id, pubkey, sig
         * @returns {Promise<Object>} Signed event with id, pubkey, sig
         */
        signEvent: async function(unsignedEvent) {
            if (!this.isAvailable()) {
                throw new Error('No NIP-07 extension detected. Please install Alby or nos2x.');
            }

            // Extension adds id, pubkey, and sig
            const signedEvent = await window.nostr.signEvent(unsignedEvent);
            return signedEvent;
        },

        /**
         * Initialize the NIP-07 UI elements.
         */
        init: function() {
            const self = this;

            // Check extension availability on page load
            $(document).ready(function() {
                self.updateUI();
                
                // Bind event handlers
                $('#woo-nostr-connect-extension').on('click', function(e) {
                    e.preventDefault();
                    self.connectExtension();
                });

                $('#woo-nostr-publish-stall-nip07').on('click', function(e) {
                    e.preventDefault();
                    self.publishStallWithExtension();
                });

                $('#woo-nostr-sync-products-nip07').on('click', function(e) {
                    e.preventDefault();
                    self.syncProductsWithExtension();
                });

                // Single product publish button
                $(document).on('click', '.woo-nostr-publish-product-nip07', function(e) {
                    e.preventDefault();
                    const productId = $(this).data('product-id');
                    self.publishProductWithExtension(productId);
                });
            });

            // Re-check if user installs extension while on page
            window.addEventListener('load', function() {
                setTimeout(function() {
                    self.updateUI();
                }, 1000);
            });
        },

        /**
         * Update UI based on extension availability.
         */
        updateUI: function() {
            const available = this.isAvailable();
            const $status = $('#woo-nostr-nip07-status');
            const $serverMode = $('.woo-nostr-server-signing');
            const $browserMode = $('.woo-nostr-browser-signing');

            if (available) {
                $status.html('<span class="dashicons dashicons-yes-alt" style="color: green;"></span> NIP-07 extension detected (Alby/nos2x)');
                $browserMode.show();
                
                // Check if we have a connected pubkey
                const savedPubkey = $('#woo-nostr-saved-pubkey').val();
                if (savedPubkey) {
                    $('#woo-nostr-connected-pubkey').text(savedPubkey.substring(0, 16) + '...');
                    $('#woo-nostr-connection-status').show();
                }
            } else {
                $status.html('<span class="dashicons dashicons-warning" style="color: orange;"></span> No NIP-07 extension detected. <a href="https://getalby.com" target="_blank">Install Alby</a> for browser signing.');
                $browserMode.hide();
            }
        },

        /**
         * Connect to browser extension and save public key.
         */
        connectExtension: async function() {
            const self = this;
            const $button = $('#woo-nostr-connect-extension');
            const $status = $('#woo-nostr-connect-status');

            $button.prop('disabled', true).text('Connecting...');
            $status.html('');

            try {
                const pubkey = await this.getPublicKey();
                
                // Save pubkey to WordPress via AJAX
                const response = await $.ajax({
                    url: wooNostrMarket.ajaxUrl,
                    method: 'POST',
                    data: {
                        action: 'woo_nostr_save_pubkey',
                        nonce: wooNostrMarket.nonce,
                        pubkey: pubkey,
                        signing_mode: 'browser'
                    }
                });

                if (response.success) {
                    $status.html('<span class="dashicons dashicons-yes-alt" style="color: green;"></span> Connected! Public key: ' + pubkey.substring(0, 16) + '...');
                    $('#woo-nostr-saved-pubkey').val(pubkey);
                    $('#woo-nostr-connected-pubkey').text(pubkey.substring(0, 16) + '...');
                    $('#woo-nostr-connection-status').show();
                    
                    // Hide server-side key input since we're using browser signing
                    $('.woo-nostr-server-key-input').hide();
                } else {
                    throw new Error(response.data || 'Failed to save public key');
                }
            } catch (error) {
                $status.html('<span class="dashicons dashicons-no" style="color: red;"></span> Error: ' + error.message);
            } finally {
                $button.prop('disabled', false).text('Connect Nostr Extension');
            }
        },

        /**
         * Publish stall using browser extension for signing.
         */
        publishStallWithExtension: async function() {
            const self = this;
            const $button = $('#woo-nostr-publish-stall-nip07');
            const $status = $('#woo-nostr-stall-status');

            $button.prop('disabled', true).text('Preparing...');
            $status.html('');

            try {
                // Get unsigned stall event from server
                const prepareResponse = await $.ajax({
                    url: wooNostrMarket.ajaxUrl,
                    method: 'POST',
                    data: {
                        action: 'woo_nostr_prepare_stall_event',
                        nonce: wooNostrMarket.nonce
                    }
                });

                if (!prepareResponse.success) {
                    throw new Error(prepareResponse.data || 'Failed to prepare stall event');
                }

                const unsignedEvent = prepareResponse.data.event;
                $status.html('Signing with extension...');
                $button.text('Sign in Alby...');

                // Sign with browser extension
                const signedEvent = await this.signEvent(unsignedEvent);
                $status.html('Publishing to relays...');
                $button.text('Publishing...');

                // Publish directly to relays from browser
                const relayResult = await this.publishToRelays(signedEvent);

                if (relayResult.success > 0) {
                    // Also notify server to update stall status
                    await $.ajax({
                        url: wooNostrMarket.ajaxUrl,
                        method: 'POST',
                        data: {
                            action: 'woo_nostr_mark_stall_published',
                            nonce: wooNostrMarket.nonce,
                            event: JSON.stringify(signedEvent),
                            event_type: 'stall'
                        }
                    }).catch(function() {}); // Non-critical

                    $status.html('<span class="dashicons dashicons-yes-alt" style="color: green;"></span> Published to ' + relayResult.success + ' of ' + relayResult.total + ' relays.');
                } else {
                    throw new Error('Failed to publish to any relay. Check relay URLs.');
                }
            } catch (error) {
                if (error.message.includes('User rejected')) {
                    $status.html('<span class="dashicons dashicons-info" style="color: orange;"></span> Signing cancelled by user.');
                } else {
                    $status.html('<span class="dashicons dashicons-no" style="color: red;"></span> Error: ' + error.message);
                }
            } finally {
                $button.prop('disabled', false).text('Publish Stall (Browser Sign)');
            }
        },

        /**
         * Sync all products using browser extension for signing.
         */
        syncProductsWithExtension: async function() {
            const self = this;
            const $button = $('#woo-nostr-sync-products-nip07');
            const $status = $('#woo-nostr-sync-status');
            const $progress = $('#woo-nostr-sync-progress');

            $button.prop('disabled', true).text('Preparing...');
            $status.html('');
            $progress.show().find('.progress-bar').css('width', '0%');

            try {
                // Get list of products to sync
                const listResponse = await $.ajax({
                    url: wooNostrMarket.ajaxUrl,
                    method: 'POST',
                    data: {
                        action: 'woo_nostr_list_products_for_sync',
                        nonce: wooNostrMarket.nonce
                    }
                });

                if (!listResponse.success) {
                    throw new Error(listResponse.data || 'Failed to get product list');
                }

                const products = listResponse.data.products;
                const total = products.length;
                let synced = 0;
                let failed = 0;

                $status.html('Syncing ' + total + ' products...');

                for (const product of products) {
                    try {
                        $button.text('Sign product ' + (synced + 1) + '/' + total + '...');
                        
                        // Get unsigned event for this product
                        const prepareResponse = await $.ajax({
                            url: wooNostrMarket.ajaxUrl,
                            method: 'POST',
                            data: {
                                action: 'woo_nostr_prepare_product_event',
                                nonce: wooNostrMarket.nonce,
                                product_id: product.id
                            }
                        });

                        if (!prepareResponse.success) {
                            console.error('Failed to prepare product ' + product.id);
                            failed++;
                            continue;
                        }

                        // Sign with extension
                        const signedEvent = await this.signEvent(prepareResponse.data.event);

                        // Publish directly to relays from browser
                        const relayResult = await this.publishToRelays(signedEvent);

                        if (relayResult.success > 0) {
                            // Notify server to update product sync status
                            await $.ajax({
                                url: wooNostrMarket.ajaxUrl,
                                method: 'POST',
                                data: {
                                    action: 'woo_nostr_mark_product_synced',
                                    nonce: wooNostrMarket.nonce,
                                    event: JSON.stringify(signedEvent),
                                    event_type: 'product',
                                    product_id: product.id
                                }
                            }).catch(function() {}); // Non-critical
                        }

                        synced++;
                    } catch (productError) {
                        console.error('Error syncing product ' + product.id, productError);
                        if (productError.message.includes('User rejected')) {
                            // User cancelled - stop the whole sync
                            throw new Error('Sync cancelled by user');
                        }
                        failed++;
                    }

                    // Update progress
                    const progress = Math.round(((synced + failed) / total) * 100);
                    $progress.find('.progress-bar').css('width', progress + '%');
                }

                $status.html('<span class="dashicons dashicons-yes-alt" style="color: green;"></span> Sync complete: ' + synced + ' synced, ' + failed + ' failed out of ' + total + ' products.');
            } catch (error) {
                $status.html('<span class="dashicons dashicons-no" style="color: red;"></span> Error: ' + error.message);
            } finally {
                $button.prop('disabled', false).text('Sync All Products (Browser Sign)');
                $progress.hide();
            }
        },

        /**
         * Publish a single product using browser extension.
         * @param {number} productId - WooCommerce product ID
         */
        publishProductWithExtension: async function(productId) {
            const self = this;
            const $button = $('.woo-nostr-publish-product-nip07[data-product-id="' + productId + '"]');
            const originalText = $button.text();

            $button.prop('disabled', true).text('Preparing...');

            try {
                // Get unsigned event
                const prepareResponse = await $.ajax({
                    url: wooNostrMarket.ajaxUrl,
                    method: 'POST',
                    data: {
                        action: 'woo_nostr_prepare_product_event',
                        nonce: wooNostrMarket.nonce,
                        product_id: productId
                    }
                });

                if (!prepareResponse.success) {
                    throw new Error(prepareResponse.data || 'Failed to prepare event');
                }

                $button.text('Sign in Alby...');

                // Sign with extension
                const signedEvent = await this.signEvent(prepareResponse.data.event);

                $button.text('Publishing...');

                // Publish directly to relays from browser
                const relayResult = await this.publishToRelays(signedEvent);

                if (relayResult.success > 0) {
                    // Notify server
                    await $.ajax({
                        url: wooNostrMarket.ajaxUrl,
                        method: 'POST',
                        data: {
                            action: 'woo_nostr_mark_product_synced',
                            nonce: wooNostrMarket.nonce,
                            event: JSON.stringify(signedEvent),
                            event_type: 'product',
                            product_id: productId
                        }
                    }).catch(function() {});

                    $button.text('✓ Published to ' + relayResult.success + ' relays!');
                    setTimeout(function() {
                        $button.text(originalText);
                    }, 2000);
                } else {
                    throw new Error('Failed to publish to any relay');
                }
            } catch (error) {
                alert('Error: ' + error.message);
                $button.text(originalText);
            } finally {
                $button.prop('disabled', false);
            }
        }
    };

    // Initialize
    WooNostrNIP07.init();

    // Expose globally for debugging
    window.WooNostrNIP07 = WooNostrNIP07;

})(jQuery);
