<?php
/**
 * Minimal secp256k1 elliptic curve operations.
 *
 * Provides ECDH and public key derivation without external binaries.
 * Used for NIP-04 encryption/decryption and key management.
 * Requires PHP GMP extension (available on 95%+ of PHP installations).
 *
 * @package WooNostrMarket
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WooNostrMarket_Secp256k1
 */
class WooNostrMarket_Secp256k1 {

	/**
	 * Field prime p.
	 *
	 * @var GMP
	 */
	private $p;

	/**
	 * Group order n.
	 *
	 * @var GMP
	 */
	private $n;

	/**
	 * Generator point x-coordinate.
	 *
	 * @var GMP
	 */
	private $gx;

	/**
	 * Generator point y-coordinate.
	 *
	 * @var GMP
	 */
	private $gy;

	/**
	 * Constructor.
	 *
	 * @throws RuntimeException If GMP extension is not available.
	 */
	public function __construct() {
		if ( ! extension_loaded( 'gmp' ) ) {
			throw new RuntimeException( 'GMP PHP extension is required for secp256k1 operations. Install it with: apt-get install php-gmp' );
		}

		$this->p  = gmp_init( 'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEFFFFFC2F', 16 );
		$this->n  = gmp_init( 'FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141', 16 );
		$this->gx = gmp_init( '79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798', 16 );
		$this->gy = gmp_init( '483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8', 16 );
	}

	/**
	 * Check if GMP is available.
	 *
	 * @return bool
	 */
	public static function is_available() {
		return extension_loaded( 'gmp' );
	}

	/**
	 * Modular reduction (always positive).
	 *
	 * @param GMP      $a Value.
	 * @param GMP|null $m Modulus (defaults to field prime p).
	 * @return GMP
	 */
	private function mod( $a, $m = null ) {
		if ( null === $m ) {
			$m = $this->p;
		}
		$r = gmp_mod( $a, $m );
		if ( gmp_sign( $r ) < 0 ) {
			$r = gmp_add( $r, $m );
		}
		return $r;
	}

	/**
	 * Point addition on the curve.
	 *
	 * @param array|null $p1 First point [x, y] or null (infinity).
	 * @param array|null $p2 Second point [x, y] or null (infinity).
	 * @return array|null Resulting point or null (infinity).
	 */
	private function point_add( $p1, $p2 ) {
		if ( null === $p1 ) {
			return $p2;
		}
		if ( null === $p2 ) {
			return $p1;
		}

		list( $x1, $y1 ) = $p1;
		list( $x2, $y2 ) = $p2;

		if ( gmp_cmp( $x1, $x2 ) === 0 ) {
			if ( gmp_cmp( $y1, $y2 ) === 0 ) {
				return $this->point_double( $p1 );
			}
			return null; // Point at infinity.
		}

		$dx = $this->mod( gmp_sub( $x2, $x1 ) );
		$dy = $this->mod( gmp_sub( $y2, $y1 ) );
		$s  = $this->mod( gmp_mul( $dy, gmp_invert( $dx, $this->p ) ) );

		$x3 = $this->mod( gmp_sub( gmp_sub( gmp_mul( $s, $s ), $x1 ), $x2 ) );
		$y3 = $this->mod( gmp_sub( gmp_mul( $s, gmp_sub( $x1, $x3 ) ), $y1 ) );

		return array( $x3, $y3 );
	}

	/**
	 * Point doubling on the curve.
	 *
	 * @param array|null $pt Point [x, y] or null.
	 * @return array|null Resulting point or null.
	 */
	private function point_double( $pt ) {
		if ( null === $pt ) {
			return null;
		}

		list( $x, $y ) = $pt;

		if ( gmp_cmp( $y, gmp_init( 0 ) ) === 0 ) {
			return null;
		}

		// s = (3 * x^2) / (2 * y) mod p. Note: a = 0 for secp256k1.
		$num = $this->mod( gmp_mul( gmp_init( 3 ), gmp_mul( $x, $x ) ) );
		$den = $this->mod( gmp_mul( gmp_init( 2 ), $y ) );
		$s   = $this->mod( gmp_mul( $num, gmp_invert( $den, $this->p ) ) );

		$x3 = $this->mod( gmp_sub( gmp_mul( $s, $s ), gmp_mul( gmp_init( 2 ), $x ) ) );
		$y3 = $this->mod( gmp_sub( gmp_mul( $s, gmp_sub( $x, $x3 ) ), $y ) );

		return array( $x3, $y3 );
	}

	/**
	 * Scalar multiplication using double-and-add (right-to-left binary method).
	 *
	 * @param GMP        $k     Scalar.
	 * @param array|null $point Base point [x, y].
	 * @return array|null Resulting point or null.
	 */
	private function scalar_mult( $k, $point ) {
		$result = null;
		$addend = $point;

		while ( gmp_cmp( $k, gmp_init( 0 ) ) > 0 ) {
			if ( gmp_intval( gmp_mod( $k, gmp_init( 2 ) ) ) === 1 ) {
				$result = $this->point_add( $result, $addend );
			}
			$addend = $this->point_double( $addend );
			$k      = gmp_div_q( $k, gmp_init( 2 ) );
		}

		return $result;
	}

	/**
	 * Recover y-coordinate from x-coordinate.
	 *
	 * Solves y^2 = x^3 + 7 (mod p). Returns the even y.
	 *
	 * @param GMP $x X-coordinate.
	 * @return GMP Y-coordinate (even).
	 * @throws RuntimeException If no valid y exists.
	 */
	private function recover_y( $x ) {
		// y^2 = x^3 + 7 mod p.
		$y_sq = $this->mod( gmp_add( gmp_powm( $x, gmp_init( 3 ), $this->p ), gmp_init( 7 ) ) );

		// p ≡ 3 (mod 4), so sqrt = y_sq^((p+1)/4) mod p.
		$exp = gmp_div_q( gmp_add( $this->p, gmp_init( 1 ) ), gmp_init( 4 ) );
		$y   = gmp_powm( $y_sq, $exp, $this->p );

		// Verify the square root.
		if ( gmp_cmp( $this->mod( gmp_mul( $y, $y ) ), $y_sq ) !== 0 ) {
			throw new RuntimeException( 'Failed to recover y-coordinate: no valid point.' );
		}

		// Return even y (standard for x-only / 02-prefix compressed keys).
		if ( gmp_intval( gmp_mod( $y, gmp_init( 2 ) ) ) !== 0 ) {
			$y = gmp_sub( $this->p, $y );
		}

		return $y;
	}

	/**
	 * Derive public key (x-only, 32-byte hex) from private key.
	 *
	 * @param string $privkey_hex Private key as 64-char hex string.
	 * @return string Public key as 64-char hex string (x-coordinate only).
	 * @throws RuntimeException On invalid key.
	 */
	public function derive_public_key( $privkey_hex ) {
		$k     = gmp_init( $privkey_hex, 16 );
		$point = $this->scalar_mult( $k, array( $this->gx, $this->gy ) );

		if ( null === $point ) {
			throw new RuntimeException( 'Invalid private key: results in point at infinity.' );
		}

		return str_pad( gmp_strval( $point[0], 16 ), 64, '0', STR_PAD_LEFT );
	}

	/**
	 * Compute a Nostr event ID.
	 *
	 * @param string $pubkey     Public key hex.
	 * @param int    $created_at Unix timestamp.
	 * @param int    $kind       Event kind.
	 * @param array  $tags       Event tags.
	 * @param string $content    Event content.
	 * @return string 64-char hex event ID.
	 */
	public function compute_event_id( $pubkey, $created_at, $kind, $tags, $content ) {
		$serialized = json_encode(
			array( 0, $pubkey, $created_at, $kind, $tags, $content ),
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
		);
		return hash( 'sha256', $serialized );
	}

	/**
	 * BIP-340 Schnorr signature.
	 *
	 * @param string $message_hash_hex 64-char hex SHA-256 hash to sign.
	 * @param string $privkey_hex      64-char hex private key.
	 * @return string 128-char hex signature (R.x || s).
	 * @throws RuntimeException On failure.
	 */
	public function schnorr_sign( $message_hash_hex, $privkey_hex ) {
		$d_prime = gmp_init( $privkey_hex, 16 );
		$m_bytes = hex2bin( $message_hash_hex );

		// P = d' * G.
		$p_point = $this->scalar_mult( $d_prime, array( $this->gx, $this->gy ) );
		if ( null === $p_point ) {
			throw new RuntimeException( 'Invalid private key.' );
		}
		list( $px, $py ) = $p_point;

		// If P.y is odd, negate d'.
		$d = $d_prime;
		if ( gmp_intval( gmp_mod( $py, gmp_init( 2 ) ) ) !== 0 ) {
			$d = gmp_sub( $this->n, $d_prime );
		}

		$d_bytes  = hex2bin( str_pad( gmp_strval( $d, 16 ), 64, '0', STR_PAD_LEFT ) );
		$px_bytes = hex2bin( str_pad( gmp_strval( $px, 16 ), 64, '0', STR_PAD_LEFT ) );

		// Deterministic nonce per BIP-340.
		$aux      = random_bytes( 32 );
		$aux_hash = $this->tagged_hash( 'BIP0340/aux', $aux );

		// t = xor(d_bytes, aux_hash).
		$t = '';
		for ( $i = 0; $i < 32; $i++ ) {
			$t .= chr( ord( $d_bytes[ $i ] ) ^ ord( $aux_hash[ $i ] ) );
		}

		// rand = tagged_hash("BIP0340/nonce", t || P.x || m).
		$rand    = $this->tagged_hash( 'BIP0340/nonce', $t . $px_bytes . $m_bytes );
		$k_prime = $this->mod( gmp_init( bin2hex( $rand ), 16 ), $this->n );

		if ( gmp_cmp( $k_prime, gmp_init( 0 ) ) === 0 ) {
			throw new RuntimeException( 'Schnorr nonce is zero.' );
		}

		// R = k' * G.
		$r_point = $this->scalar_mult( $k_prime, array( $this->gx, $this->gy ) );
		if ( null === $r_point ) {
			throw new RuntimeException( 'Schnorr R point is infinity.' );
		}
		list( $rx, $ry ) = $r_point;

		// If R.y is odd, negate k'.
		$k = $k_prime;
		if ( gmp_intval( gmp_mod( $ry, gmp_init( 2 ) ) ) !== 0 ) {
			$k = gmp_sub( $this->n, $k_prime );
		}

		// e = tagged_hash("BIP0340/challenge", R.x || P.x || m).
		$rx_bytes = hex2bin( str_pad( gmp_strval( $rx, 16 ), 64, '0', STR_PAD_LEFT ) );
		$e_hash   = $this->tagged_hash( 'BIP0340/challenge', $rx_bytes . $px_bytes . $m_bytes );
		$e        = $this->mod( gmp_init( bin2hex( $e_hash ), 16 ), $this->n );

		// s = (k + e * d) mod n.
		$s = $this->mod( gmp_add( $k, gmp_mul( $e, $d ) ), $this->n );

		$rx_hex = str_pad( gmp_strval( $rx, 16 ), 64, '0', STR_PAD_LEFT );
		$s_hex  = str_pad( gmp_strval( $s, 16 ), 64, '0', STR_PAD_LEFT );

		return $rx_hex . $s_hex;
	}

	/**
	 * BIP-340 tagged hash: SHA256(SHA256(tag) || SHA256(tag) || msg).
	 *
	 * @param string $tag Tag string.
	 * @param string $msg Raw bytes message.
	 * @return string Raw 32-byte hash.
	 */
	private function tagged_hash( $tag, $msg ) {
		$tag_hash = hash( 'sha256', $tag, true );
		return hash( 'sha256', $tag_hash . $tag_hash . $msg, true );
	}

	/**
	 * ECDH shared secret (x-coordinate of scalar * point).
	 *
	 * @param string $our_privkey_hex   Our private key (64-char hex).
	 * @param string $their_pubkey_hex  Their public key (64-char hex, x-only).
	 * @return string Shared secret as 64-char hex string.
	 * @throws RuntimeException On failure.
	 */
	public function ecdh( $our_privkey_hex, $their_pubkey_hex ) {
		$x = gmp_init( $their_pubkey_hex, 16 );
		$y = $this->recover_y( $x );
		$k = gmp_init( $our_privkey_hex, 16 );

		$point = $this->scalar_mult( $k, array( $x, $y ) );

		if ( null === $point ) {
			throw new RuntimeException( 'ECDH failed: result is point at infinity.' );
		}

		return str_pad( gmp_strval( $point[0], 16 ), 64, '0', STR_PAD_LEFT );
	}
}
