<?php
/**
 * Product sync class for NIP-15 product events.
 *
 * @package WooNostrMarket
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WooNostrMarket_Product_Sync
 *
 * Syncs WooCommerce products to Nostr as kind:30018 (NIP-15) and kind:30402 (NIP-99) events.
 */
class WooNostrMarket_Product_Sync {

	/**
	 * NIP-15 product event kind.
	 *
	 * @var int
	 */
	const PRODUCT_KIND = 30018;

	/**
	 * NIP-99 classified listing event kind.
	 *
	 * @var int
	 */
	const CLASSIFIED_KIND = 30402;

	/**
	 * NIP-99 draft/inactive listing kind.
	 *
	 * @var int
	 */
	const CLASSIFIED_DRAFT_KIND = 30403;

	/**
	 * Delete event kind.
	 *
	 * @var int
	 */
	const DELETE_KIND = 5;

	/**
	 * Settings instance.
	 *
	 * @var WooNostrMarket_Settings
	 */
	private $settings;

	/**
	 * Nostr client instance.
	 *
	 * @var WooNostrMarket_Nostr_Client
	 */
	private $nostr_client;

	/**
	 * Stall manager instance.
	 *
	 * @var WooNostrMarket_Stall_Manager
	 */
	private $stall_manager;

	/**
	 * Constructor.
	 *
	 * @param WooNostrMarket_Settings      $settings      Settings instance.
	 * @param WooNostrMarket_Nostr_Client  $nostr_client  Nostr client instance.
	 * @param WooNostrMarket_Stall_Manager $stall_manager Stall manager instance.
	 */
	public function __construct(
		WooNostrMarket_Settings $settings,
		WooNostrMarket_Nostr_Client $nostr_client,
		WooNostrMarket_Stall_Manager $stall_manager
	) {
		$this->settings      = $settings;
		$this->nostr_client  = $nostr_client;
		$this->stall_manager = $stall_manager;

		$this->init_hooks();
	}

	/**
	 * Initialize WordPress/WooCommerce hooks.
	 */
	private function init_hooks() {
		// Hook into product save.
		add_action( 'save_post_product', array( $this, 'on_product_save' ), 20, 3 );

		// Hook into product deletion.
		add_action( 'before_delete_post', array( $this, 'on_product_delete' ), 10, 2 );

		// Hook into product trash.
		add_action( 'wp_trash_post', array( $this, 'on_product_trash' ) );

		// Hook into stock changes.
		add_action( 'woocommerce_product_set_stock', array( $this, 'on_stock_change' ) );
	}

	/**
	 * Handle product save.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 * @param bool    $update  Whether this is an update.
	 */
	public function on_product_save( $post_id, $post, $update ) {
		// Skip autosaves and revisions.
		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( wp_is_post_revision( $post_id ) ) {
			return;
		}

		// Skip if not configured.
		if ( ! $this->settings->is_configured() ) {
			return;
		}

		// Only sync published products.
		if ( 'publish' !== $post->post_status ) {
			return;
		}

		// Sync the product.
		$this->publish_product( $post_id );
	}

	/**
	 * Handle product deletion.
	 *
	 * @param int     $post_id Post ID.
	 * @param WP_Post $post    Post object.
	 */
	public function on_product_delete( $post_id, $post = null ) {
		if ( null === $post ) {
			$post = get_post( $post_id );
		}

		if ( ! $post || 'product' !== $post->post_type ) {
			return;
		}

		// Skip if not configured.
		if ( ! $this->settings->is_configured() ) {
			return;
		}

		// Publish delete event.
		$this->delete_product( $post_id );
	}

	/**
	 * Handle product trash.
	 *
	 * @param int $post_id Post ID.
	 */
	public function on_product_trash( $post_id ) {
		$post = get_post( $post_id );

		if ( ! $post || 'product' !== $post->post_type ) {
			return;
		}

		// Skip if not configured.
		if ( ! $this->settings->is_configured() ) {
			return;
		}

		// Publish delete event (treat trash as delete for Nostr).
		$this->delete_product( $post_id );
	}

	/**
	 * Handle stock change.
	 *
	 * @param WC_Product $product Product object.
	 */
	public function on_stock_change( $product ) {
		// Skip if not configured.
		if ( ! $this->settings->is_configured() ) {
			return;
		}

		// Republish product with updated stock.
		$this->publish_product( $product->get_id() );
	}

	/**
	 * Map a WooCommerce product to NIP-15 format.
	 *
	 * @param int $product_id Product ID.
	 * @return array|WP_Error NIP-15 product data or error.
	 */
	public function map_product_to_nip15( $product_id ) {
		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			return new WP_Error( 'invalid_product', __( 'Product not found.', 'woo-nostr-market' ) );
		}

		// Only handle simple products for MVP.
		if ( $product->is_type( 'variable' ) ) {
			// For variable products, we could create multiple NIP-15 products per variation.
			// For MVP, we'll just use the parent product with price range info.
			return $this->map_variable_product( $product );
		}

		// Get product images.
		$images = $this->get_product_images( $product );

		// Get product specs (attributes).
		$specs = $this->get_product_specs( $product );

		// Build NIP-15 product structure.
		$nip15_product = array(
			'id'          => (string) $product_id,
			'stall_id'    => $this->settings->get_stall_id(),
			'name'        => $product->get_name(),
			'description' => $this->get_product_description( $product ),
			'images'      => $images,
			'currency'    => strtolower( get_woocommerce_currency() ),
			'price'       => (float) $product->get_price(),
			'quantity'    => $this->get_product_quantity( $product ),
		);

		// Add optional fields.
		if ( ! empty( $specs ) ) {
			$nip15_product['specs'] = $specs;
		}

		// Add categories as tags (will be 't' tags in the event).
		$categories = $this->get_product_categories( $product );

		return array(
			'product'    => $nip15_product,
			'categories' => $categories,
		);
	}

	/**
	 * Map a variable product to NIP-15 format.
	 *
	 * @param WC_Product_Variable $product Variable product.
	 * @return array NIP-15 product data.
	 */
	private function map_variable_product( $product ) {
		$prices     = $product->get_variation_prices();
		$min_price  = min( $prices['price'] );
		$max_price  = max( $prices['price'] );
		$images     = $this->get_product_images( $product );
		$specs      = $this->get_product_specs( $product );
		$categories = $this->get_product_categories( $product );

		// Add variation attributes to specs.
		$attributes = $product->get_variation_attributes();
		foreach ( $attributes as $attr_name => $values ) {
			$specs[] = array(
				str_replace( 'pa_', '', $attr_name ),
				implode( ', ', $values ),
			);
		}

		$nip15_product = array(
			'id'          => (string) $product->get_id(),
			'stall_id'    => $this->settings->get_stall_id(),
			'name'        => $product->get_name(),
			'description' => $this->get_product_description( $product ),
			'images'      => $images,
			'currency'    => strtolower( get_woocommerce_currency() ),
			'price'       => (float) $min_price,
			'quantity'    => $this->get_product_quantity( $product ),
		);

		if ( ! empty( $specs ) ) {
			$nip15_product['specs'] = $specs;
		}

		// Note price range in description if different.
		if ( $min_price !== $max_price ) {
			$nip15_product['description'] .= sprintf(
				"\n\n%s: %s - %s",
				__( 'Price range', 'woo-nostr-market' ),
				wc_price( $min_price ),
				wc_price( $max_price )
			);
		}

		return array(
			'product'    => $nip15_product,
			'categories' => $categories,
		);
	}

	/**
	 * Get product images.
	 *
	 * @param WC_Product $product Product.
	 * @return array Image URLs.
	 */
	private function get_product_images( $product ) {
		$images = array();

		// Featured image.
		$featured_id = $product->get_image_id();
		if ( $featured_id ) {
			$url = wp_get_attachment_url( $featured_id );
			if ( $url ) {
				$images[] = $url;
			}
		}

		// Gallery images.
		$gallery_ids = $product->get_gallery_image_ids();
		foreach ( $gallery_ids as $image_id ) {
			$url = wp_get_attachment_url( $image_id );
			if ( $url ) {
				$images[] = $url;
			}
		}

		return $images;
	}

	/**
	 * Get product specs (attributes).
	 *
	 * @param WC_Product $product Product.
	 * @return array Specs as [key, value] pairs.
	 */
	private function get_product_specs( $product ) {
		$specs = array();

		// SKU.
		$sku = $product->get_sku();
		if ( ! empty( $sku ) ) {
			$specs[] = array( 'sku', $sku );
		}

		// Weight.
		$weight = $product->get_weight();
		if ( ! empty( $weight ) ) {
			$specs[] = array( 'weight', $weight . ' ' . get_option( 'woocommerce_weight_unit' ) );
		}

		// Dimensions.
		$dimensions = $product->get_dimensions( false );
		if ( ! empty( $dimensions['length'] ) ) {
			$dim_unit = get_option( 'woocommerce_dimension_unit' );
			$specs[]  = array(
				'dimensions',
				sprintf(
					'%s × %s × %s %s',
					$dimensions['length'],
					$dimensions['width'],
					$dimensions['height'],
					$dim_unit
				),
			);
		}

		// Product attributes.
		$attributes = $product->get_attributes();
		foreach ( $attributes as $attr ) {
			if ( is_a( $attr, 'WC_Product_Attribute' ) ) {
				$name = wc_attribute_label( $attr->get_name() );
				if ( $attr->is_taxonomy() ) {
					$values = wc_get_product_terms( $product->get_id(), $attr->get_name(), array( 'fields' => 'names' ) );
					$value  = implode( ', ', $values );
				} else {
					$value = implode( ', ', $attr->get_options() );
				}
				if ( ! empty( $value ) ) {
					$specs[] = array( $name, $value );
				}
			}
		}

		return $specs;
	}

	/**
	 * Get product description.
	 *
	 * @param WC_Product $product Product.
	 * @return string Description.
	 */
	private function get_product_description( $product ) {
		$description = $product->get_description();

		// Fall back to short description if empty.
		if ( empty( $description ) ) {
			$description = $product->get_short_description();
		}

		// Strip HTML and clean up.
		$description = wp_strip_all_tags( $description );
		$description = html_entity_decode( $description, ENT_QUOTES, 'UTF-8' );

		return $description;
	}

	/**
	 * Get product quantity.
	 *
	 * @param WC_Product $product Product.
	 * @return int Quantity (0 if unlimited/not managed).
	 */
	private function get_product_quantity( $product ) {
		if ( ! $product->managing_stock() ) {
			// Return a high number for "unlimited" stock.
			return $product->is_in_stock() ? 9999 : 0;
		}

		$stock = $product->get_stock_quantity();
		return max( 0, (int) $stock );
	}

	/**
	 * Get product categories.
	 *
	 * @param WC_Product $product Product.
	 * @return array Category names.
	 */
	private function get_product_categories( $product ) {
		$categories = array();
		$term_ids   = $product->get_category_ids();

		foreach ( $term_ids as $term_id ) {
			$term = get_term( $term_id, 'product_cat' );
			if ( $term && ! is_wp_error( $term ) ) {
				$categories[] = $term->name;
			}
		}

		return $categories;
	}

	/**
	 * Map a WooCommerce product to NIP-99 format (classified listing).
	 *
	 * @param int $product_id Product ID.
	 * @return array|WP_Error NIP-99 event data or error.
	 */
	public function map_product_to_nip99( $product_id ) {
		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			return new WP_Error( 'invalid_product', __( 'Product not found.', 'woo-nostr-market' ) );
		}

		// Get product data.
		$images     = $this->get_product_images( $product );
		$categories = $this->get_product_categories( $product );
		$price      = (float) $product->get_price();
		$currency   = strtoupper( get_woocommerce_currency() );

		// Handle variable products.
		if ( $product->is_type( 'variable' ) ) {
			$prices    = $product->get_variation_prices();
			$min_price = min( $prices['price'] );
			$price     = (float) $min_price;
		}

		// Build markdown content for NIP-99.
		$content = $this->get_product_description( $product );

		// Add product details to content.
		$specs = $this->get_product_specs( $product );
		if ( ! empty( $specs ) ) {
			$content .= "\n\n**Details:**\n";
			foreach ( $specs as $spec ) {
				$content .= sprintf( "- %s: %s\n", $spec[0], $spec[1] );
			}
		}

		// Add stock info.
		$stock = $this->get_product_quantity( $product );
		if ( $stock < 9999 && $stock > 0 ) {
			$content .= sprintf( "\n*%d in stock*", $stock );
		} elseif ( $stock === 0 ) {
			$content .= "\n*Out of stock*";
		}

		// Build tags for NIP-99.
		$tags = array(
			array( 'd', (string) $product_id ),
			array( 'title', $product->get_name() ),
			array( 'price', (string) $price, $currency ),
			array( 'published_at', (string) strtotime( $product->get_date_created() ) ),
		);

		// Add summary (short description).
		$short_desc = wp_strip_all_tags( $product->get_short_description() );
		if ( ! empty( $short_desc ) ) {
			$tags[] = array( 'summary', substr( $short_desc, 0, 200 ) );
		} else {
			// Use first 200 chars of main description.
			$tags[] = array( 'summary', substr( wp_strip_all_tags( $product->get_description() ), 0, 200 ) );
		}

		// Add location (store location from settings or WooCommerce).
		$store_address = get_option( 'woocommerce_store_address' );
		$store_city    = get_option( 'woocommerce_store_city' );
		$store_country = get_option( 'woocommerce_default_country' );
		if ( $store_city || $store_country ) {
			$location_parts = array_filter( array( $store_city, $store_country ) );
			$tags[]         = array( 'location', implode( ', ', $location_parts ) );
		}

		// Add images.
		foreach ( $images as $image_url ) {
			$tags[] = array( 'image', $image_url );
		}

		// Add category tags.
		foreach ( $categories as $category ) {
			$tags[] = array( 't', strtolower( $category ) );
		}

		// Add status.
		$tags[] = array( 'status', $product->is_in_stock() ? 'active' : 'sold' );

		// Add product URL for reference.
		$tags[] = array( 'r', get_permalink( $product_id ) );

		return array(
			'content' => $content,
			'tags'    => $tags,
		);
	}

	/**
	 * Publish a product to Nostr (both NIP-15 and NIP-99).
	 *
	 * @param int $product_id Product ID.
	 * @return array|WP_Error Publish results or error.
	 */
	public function publish_product( $product_id ) {
		$results = array(
			'nip15' => null,
			'nip99' => null,
		);

		// Check which protocols are enabled.
		$enable_nip15 = $this->settings->get( 'enable_nip15', true );
		$enable_nip99 = $this->settings->get( 'enable_nip99', true );

		// Publish NIP-15 (kind:30018).
		if ( $enable_nip15 ) {
			$mapped = $this->map_product_to_nip15( $product_id );

			if ( ! is_wp_error( $mapped ) ) {
				$tags = array(
					array( 'd', (string) $product_id ),
				);

				foreach ( $mapped['categories'] as $category ) {
					$tags[] = array( 't', strtolower( $category ) );
				}

				$content = wp_json_encode( $mapped['product'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

				$results['nip15'] = $this->nostr_client->create_sign_and_publish(
					self::PRODUCT_KIND,
					$content,
					$tags
				);
			} else {
				$results['nip15'] = $mapped;
			}
		}

		// Publish NIP-99 (kind:30402).
		if ( $enable_nip99 ) {
			$mapped99 = $this->map_product_to_nip99( $product_id );

			if ( ! is_wp_error( $mapped99 ) ) {
				$results['nip99'] = $this->nostr_client->create_sign_and_publish(
					self::CLASSIFIED_KIND,
					$mapped99['content'],
					$mapped99['tags']
				);
			} else {
				$results['nip99'] = $mapped99;
			}
		}

		// Check if at least one succeeded.
		$any_success = false;
		if ( ! empty( $results['nip15'] ) && ! is_wp_error( $results['nip15'] ) && ! empty( $results['nip15']['success'] ) ) {
			$any_success = true;
		}
		if ( ! empty( $results['nip99'] ) && ! is_wp_error( $results['nip99'] ) && ! empty( $results['nip99']['success'] ) ) {
			$any_success = true;
		}

		if ( $any_success ) {
			update_post_meta( $product_id, '_woo_nostr_last_sync', time() );
		}

		// Return combined result.
		return array(
			'success' => $any_success,
			'message' => $this->build_publish_message( $results ),
			'results' => $results,
		);
	}

	/**
	 * Build a human-readable publish message.
	 *
	 * @param array $results Publish results.
	 * @return string Message.
	 */
	private function build_publish_message( $results ) {
		$messages = array();

		if ( ! empty( $results['nip15'] ) && ! is_wp_error( $results['nip15'] ) ) {
			if ( ! empty( $results['nip15']['success'] ) ) {
				$messages[] = 'NIP-15 (Plebeian Market) ✓';
			} else {
				$messages[] = 'NIP-15 ✗';
			}
		}

		if ( ! empty( $results['nip99'] ) && ! is_wp_error( $results['nip99'] ) ) {
			if ( ! empty( $results['nip99']['success'] ) ) {
				$messages[] = 'NIP-99 (Shopstr) ✓';
			} else {
				$messages[] = 'NIP-99 ✗';
			}
		}

		return implode( ', ', $messages );
	}

	/**
	 * Delete a product from Nostr (publish kind:5 delete events for both formats).
	 *
	 * @param int $product_id Product ID.
	 * @return array|WP_Error Publish results or error.
	 */
	public function delete_product( $product_id ) {
		$pubkey  = $this->settings->get_public_key();
		$results = array();

		// Check which protocols are enabled.
		$enable_nip15 = $this->settings->get( 'enable_nip15', true );
		$enable_nip99 = $this->settings->get( 'enable_nip99', true );

		// Delete NIP-15 event.
		if ( $enable_nip15 ) {
			$tags = array(
				array( 'a', self::PRODUCT_KIND . ':' . $pubkey . ':' . $product_id ),
			);

			$results['nip15'] = $this->nostr_client->create_sign_and_publish(
				self::DELETE_KIND,
				__( 'Product removed from store.', 'woo-nostr-market' ),
				$tags
			);
		}

		// Delete NIP-99 event.
		if ( $enable_nip99 ) {
			$tags = array(
				array( 'a', self::CLASSIFIED_KIND . ':' . $pubkey . ':' . $product_id ),
			);

			$results['nip99'] = $this->nostr_client->create_sign_and_publish(
				self::DELETE_KIND,
				__( 'Listing removed.', 'woo-nostr-market' ),
				$tags
			);
		}

		return $results;
	}

	/**
	 * Sync all published products.
	 *
	 * @param callable|null $progress_callback Optional callback for progress updates.
	 * @return array Sync results.
	 */
	public function sync_all_products( $progress_callback = null ) {
		$results = array(
			'total'     => 0,
			'success'   => 0,
			'failed'    => 0,
			'skipped'   => 0,
			'errors'    => array(),
		);

		// Get all published products.
		$products = wc_get_products(
			array(
				'status' => 'publish',
				'limit'  => -1,
				'return' => 'ids',
			)
		);

		$results['total'] = count( $products );

		foreach ( $products as $index => $product_id ) {
			$result = $this->publish_product( $product_id );

			if ( is_wp_error( $result ) ) {
				$results['failed']++;
				$results['errors'][ $product_id ] = $result->get_error_message();
			} elseif ( ! empty( $result['success'] ) ) {
				$results['success']++;
			} else {
				$results['failed']++;
				$results['errors'][ $product_id ] = $result['message'] ?? __( 'Unknown error', 'woo-nostr-market' );
			}

			// Call progress callback if provided.
			if ( is_callable( $progress_callback ) ) {
				call_user_func( $progress_callback, $index + 1, $results['total'], $product_id );
			}

			// Small delay to avoid overwhelming relays.
			usleep( 100000 ); // 100ms.
		}

		return $results;
	}

	/**
	 * Get sync status for a product.
	 *
	 * @param int $product_id Product ID.
	 * @return array Sync status.
	 */
	public function get_product_sync_status( $product_id ) {
		$last_sync = get_post_meta( $product_id, '_woo_nostr_last_sync', true );
		$product   = wc_get_product( $product_id );

		if ( ! $product ) {
			return array(
				'synced'     => false,
				'last_sync'  => null,
				'is_current' => false,
			);
		}

		$last_modified = strtotime( $product->get_date_modified() );

		return array(
			'synced'     => ! empty( $last_sync ),
			'last_sync'  => $last_sync ? (int) $last_sync : null,
			'is_current' => ! empty( $last_sync ) && $last_sync >= $last_modified,
		);
	}

	/**
	 * Get count of products needing sync.
	 *
	 * @return int Count.
	 */
	public function get_pending_sync_count() {
		global $wpdb;

		// Products that have never been synced or were modified after last sync.
		$count = $wpdb->get_var(
			"SELECT COUNT(DISTINCT p.ID)
			FROM {$wpdb->posts} p
			LEFT JOIN {$wpdb->postmeta} pm ON p.ID = pm.post_id AND pm.meta_key = '_woo_nostr_last_sync'
			WHERE p.post_type = 'product'
			AND p.post_status = 'publish'
			AND (
				pm.meta_value IS NULL
				OR UNIX_TIMESTAMP(p.post_modified) > CAST(pm.meta_value AS UNSIGNED)
			)"
		);

		return (int) $count;
	}
}
