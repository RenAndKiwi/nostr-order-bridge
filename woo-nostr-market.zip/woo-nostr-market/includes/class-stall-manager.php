<?php
/**
 * Stall manager class for NIP-15 stall events.
 *
 * @package WooNostrMarket
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WooNostrMarket_Stall_Manager
 *
 * Creates and publishes kind:30017 stall events per NIP-15 spec.
 */
class WooNostrMarket_Stall_Manager {

	/**
	 * NIP-15 stall event kind.
	 *
	 * @var int
	 */
	const STALL_KIND = 30017;

	/**
	 * Settings instance.
	 *
	 * @var WooNostrMarket_Settings
	 */
	private $settings;

	/**
	 * Nostr client instance.
	 *
	 * @var WooNostrMarket_Nostr_Client
	 */
	private $nostr_client;

	/**
	 * Constructor.
	 *
	 * @param WooNostrMarket_Settings     $settings     Settings instance.
	 * @param WooNostrMarket_Nostr_Client $nostr_client Nostr client instance.
	 */
	public function __construct( WooNostrMarket_Settings $settings, WooNostrMarket_Nostr_Client $nostr_client ) {
		$this->settings     = $settings;
		$this->nostr_client = $nostr_client;
	}

	/**
	 * Get stall data from WooCommerce settings.
	 *
	 * @return array Stall data.
	 */
	public function get_stall_data() {
		$stall_id    = $this->settings->get_stall_id();
		$store_name  = get_bloginfo( 'name' );
		$description = get_bloginfo( 'description' );
		$currency    = get_woocommerce_currency();

		// Get shipping zones and format for NIP-15.
		$shipping = $this->get_shipping_data();

		return array(
			'id'          => $stall_id,
			'name'        => $store_name,
			'description' => $description,
			'currency'    => strtolower( $currency ),
			'shipping'    => $shipping,
		);
	}

	/**
	 * Get shipping data from WooCommerce shipping zones.
	 *
	 * @return array Shipping zones formatted for NIP-15.
	 */
	private function get_shipping_data() {
		$shipping = array();

		// Get all shipping zones.
		$zones = WC_Shipping_Zones::get_zones();

		foreach ( $zones as $zone_data ) {
			$zone = new WC_Shipping_Zone( $zone_data['zone_id'] );

			// Get the first flat rate or free shipping method.
			$methods = $zone->get_shipping_methods( true );
			$cost    = 0;

			foreach ( $methods as $method ) {
				if ( 'flat_rate' === $method->id ) {
					$cost = floatval( $method->get_option( 'cost', 0 ) );
					break;
				} elseif ( 'free_shipping' === $method->id ) {
					$cost = 0;
					break;
				}
			}

			// Get zone locations (regions).
			$regions = array();
			foreach ( $zone_data['zone_locations'] as $location ) {
				if ( 'country' === $location->type ) {
					$regions[] = $location->code;
				} elseif ( 'state' === $location->type ) {
					$regions[] = $location->code;
				} elseif ( 'continent' === $location->type ) {
					$regions[] = $location->code;
				}
			}

			$shipping[] = array(
				'id'      => 'zone_' . $zone_data['zone_id'],
				'name'    => $zone_data['zone_name'],
				'cost'    => $cost,
				'regions' => $regions,
			);
		}

		// Add "Rest of the World" zone if it exists.
		$rest_of_world = new WC_Shipping_Zone( 0 );
		$methods       = $rest_of_world->get_shipping_methods( true );

		if ( ! empty( $methods ) ) {
			$cost = 0;
			foreach ( $methods as $method ) {
				if ( 'flat_rate' === $method->id ) {
					$cost = floatval( $method->get_option( 'cost', 0 ) );
					break;
				}
			}

			$shipping[] = array(
				'id'      => 'zone_0',
				'name'    => __( 'Worldwide', 'woo-nostr-market' ),
				'cost'    => $cost,
				'regions' => array( 'Worldwide' ),
			);
		}

		// If no shipping zones configured, add a default.
		if ( empty( $shipping ) ) {
			$shipping[] = array(
				'id'      => 'default',
				'name'    => __( 'Standard Shipping', 'woo-nostr-market' ),
				'cost'    => 0,
				'regions' => array( 'Worldwide' ),
			);
		}

		return $shipping;
	}

	/**
	 * Create a stall event in NIP-15 format.
	 *
	 * @param array $stall_data Stall data.
	 * @return array Event structure.
	 */
	public function create_stall_event( $stall_data = null ) {
		if ( null === $stall_data ) {
			$stall_data = $this->get_stall_data();
		}

		// NIP-15 stall content is JSON.
		$content = wp_json_encode( $stall_data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

		// Tags for parameterized replaceable event.
		$tags = array(
			array( 'd', $stall_data['id'] ), // Unique identifier for this stall.
		);

		return array(
			'kind'    => self::STALL_KIND,
			'content' => $content,
			'tags'    => $tags,
		);
	}

	/**
	 * Publish the stall to Nostr relays.
	 *
	 * @return array|WP_Error Publish results or error.
	 */
	public function publish_stall() {
		// Check if configured.
		if ( ! $this->settings->is_configured() ) {
			return new WP_Error(
				'not_configured',
				__( 'Plugin is not configured. Please set up your Nostr keys first.', 'woo-nostr-market' )
			);
		}

		// Get stall data and create event.
		$stall_data  = $this->get_stall_data();
		$event       = $this->create_stall_event( $stall_data );

		// Sign and publish.
		$result = $this->nostr_client->create_sign_and_publish(
			$event['kind'],
			$event['content'],
			$event['tags']
		);

		if ( is_wp_error( $result ) ) {
			return $result;
		}

		// Save last published timestamp.
		update_option( 'woo_nostr_market_stall_last_published', time() );

		return $result;
	}

	/**
	 * Get the last published timestamp for the stall.
	 *
	 * @return int|false Unix timestamp or false if never published.
	 */
	public function get_last_published() {
		return get_option( 'woo_nostr_market_stall_last_published', false );
	}

	/**
	 * Get stall status information for display.
	 *
	 * @return array Status info.
	 */
	public function get_status() {
		$stall_data     = $this->get_stall_data();
		$last_published = $this->get_last_published();

		return array(
			'stall_id'       => $stall_data['id'],
			'name'           => $stall_data['name'],
			'description'    => $stall_data['description'],
			'currency'       => $stall_data['currency'],
			'shipping_zones' => count( $stall_data['shipping'] ),
			'last_published' => $last_published,
			'is_configured'  => $this->settings->is_configured(),
		);
	}

	/**
	 * Validate stall data before publishing.
	 *
	 * @return array Validation result with 'valid' boolean and 'errors' array.
	 */
	public function validate() {
		$errors     = array();
		$stall_data = $this->get_stall_data();

		if ( empty( $stall_data['name'] ) ) {
			$errors[] = __( 'Store name is required. Set it in Settings → General.', 'woo-nostr-market' );
		}

		if ( empty( $stall_data['currency'] ) ) {
			$errors[] = __( 'Currency is required. Set it in WooCommerce → Settings → General.', 'woo-nostr-market' );
		}

		if ( ! $this->settings->is_configured() ) {
			$errors[] = __( 'Nostr keys are not configured.', 'woo-nostr-market' );
		}

		$relays = $this->settings->get_relay_urls();
		if ( empty( $relays ) ) {
			$errors[] = __( 'No relays configured.', 'woo-nostr-market' );
		}

		return array(
			'valid'  => empty( $errors ),
			'errors' => $errors,
		);
	}
}
