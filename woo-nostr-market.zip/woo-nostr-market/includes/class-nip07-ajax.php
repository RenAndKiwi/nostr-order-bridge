<?php
/**
 * NIP-07 AJAX handlers for browser extension signing.
 *
 * @package WooNostrMarket
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WooNostrMarket_NIP07_Ajax
 *
 * Handles AJAX requests for NIP-07 browser signing flow.
 */
class WooNostrMarket_NIP07_Ajax {

	/**
	 * Settings instance.
	 *
	 * @var WooNostrMarket_Settings
	 */
	private $settings;

	/**
	 * Stall manager instance.
	 *
	 * @var WooNostrMarket_Stall_Manager
	 */
	private $stall_manager;

	/**
	 * Product sync instance.
	 *
	 * @var WooNostrMarket_Product_Sync
	 */
	private $product_sync;

	/**
	 * Constructor.
	 *
	 * @param WooNostrMarket_Settings      $settings      Settings instance.
	 * @param WooNostrMarket_Stall_Manager $stall_manager Stall manager instance.
	 * @param WooNostrMarket_Product_Sync  $product_sync  Product sync instance.
	 */
	public function __construct(
		WooNostrMarket_Settings $settings,
		WooNostrMarket_Stall_Manager $stall_manager,
		WooNostrMarket_Product_Sync $product_sync
	) {
		$this->settings      = $settings;
		$this->stall_manager = $stall_manager;
		$this->product_sync  = $product_sync;

		$this->init_hooks();
	}

	/**
	 * Initialize AJAX hooks.
	 */
	private function init_hooks() {
		add_action( 'wp_ajax_woo_nostr_save_pubkey', array( $this, 'save_pubkey' ) );
		add_action( 'wp_ajax_woo_nostr_prepare_stall_event', array( $this, 'prepare_stall_event' ) );
		add_action( 'wp_ajax_woo_nostr_prepare_product_event', array( $this, 'prepare_product_event' ) );
		add_action( 'wp_ajax_woo_nostr_list_products_for_sync', array( $this, 'list_products_for_sync' ) );
		add_action( 'wp_ajax_woo_nostr_publish_signed_event', array( $this, 'publish_signed_event' ) );
		add_action( 'wp_ajax_woo_nostr_mark_stall_published', array( $this, 'mark_stall_published' ) );
		add_action( 'wp_ajax_woo_nostr_mark_product_synced', array( $this, 'mark_product_synced' ) );
	}

	/**
	 * Verify AJAX request.
	 *
	 * @return bool
	 */
	private function verify_request() {
		if ( ! check_ajax_referer( 'woo_nostr_market_nip07', 'nonce', false ) ) {
			wp_send_json_error( 'Invalid security token.' );
			return false;
		}

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( 'Permission denied.' );
			return false;
		}

		return true;
	}

	/**
	 * Save public key from browser extension.
	 */
	public function save_pubkey() {
		if ( ! $this->verify_request() ) {
			return;
		}

		$pubkey = isset( $_POST['pubkey'] ) ? sanitize_text_field( wp_unslash( $_POST['pubkey'] ) ) : '';
		$signing_mode = isset( $_POST['signing_mode'] ) ? sanitize_text_field( wp_unslash( $_POST['signing_mode'] ) ) : 'browser';

		if ( empty( $pubkey ) || ! preg_match( '/^[a-fA-F0-9]{64}$/', $pubkey ) ) {
			wp_send_json_error( 'Invalid public key format.' );
			return;
		}

		// Save public key and signing mode.
		$this->settings->set( 'nostr_public_key', $pubkey );
		$this->settings->set( 'signing_mode', $signing_mode );

		// Clear any server-side private key if switching to browser mode.
		if ( 'browser' === $signing_mode ) {
			$this->settings->delete( 'nostr_private_key' );
		}

		wp_send_json_success( array(
			'message' => 'Public key saved.',
			'pubkey'  => $pubkey,
		) );
	}

	/**
	 * Prepare unsigned stall event for browser signing.
	 */
	public function prepare_stall_event() {
		if ( ! $this->verify_request() ) {
			return;
		}

		// Get stall data.
		$stall_data = $this->stall_manager->get_stall_data();

		if ( is_wp_error( $stall_data ) ) {
			wp_send_json_error( $stall_data->get_error_message() );
			return;
		}

		// Build unsigned event (browser will add pubkey, id, sig).
		$unsigned_event = array(
			'created_at' => time(),
			'kind'       => 30017, // NIP-15 stall.
			'tags'       => array(
				array( 'd', $stall_data['id'] ),
			),
			'content'    => wp_json_encode( $stall_data, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ),
		);

		wp_send_json_success( array(
			'event'      => $unsigned_event,
			'stall_data' => $stall_data,
		) );
	}

	/**
	 * Prepare unsigned product event for browser signing.
	 */
	public function prepare_product_event() {
		if ( ! $this->verify_request() ) {
			return;
		}

		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;

		if ( ! $product_id ) {
			wp_send_json_error( 'Product ID required.' );
			return;
		}

		// Map product to NIP-15 format.
		$mapped = $this->product_sync->map_product_to_nip15( $product_id );

		if ( is_wp_error( $mapped ) ) {
			wp_send_json_error( $mapped->get_error_message() );
			return;
		}

		// Build tags.
		$tags = array(
			array( 'd', (string) $product_id ),
		);

		// Add category tags.
		foreach ( $mapped['categories'] as $category ) {
			$tags[] = array( 't', strtolower( $category ) );
		}

		// Build unsigned event.
		$unsigned_event = array(
			'created_at' => time(),
			'kind'       => 30018, // NIP-15 product.
			'tags'       => $tags,
			'content'    => wp_json_encode( $mapped['product'], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ),
		);

		wp_send_json_success( array(
			'event'        => $unsigned_event,
			'product_data' => $mapped['product'],
		) );
	}

	/**
	 * List products available for sync.
	 */
	public function list_products_for_sync() {
		if ( ! $this->verify_request() ) {
			return;
		}

		$products = wc_get_products( array(
			'status' => 'publish',
			'limit'  => -1,
			'return' => 'ids',
		) );

		$product_list = array();
		foreach ( $products as $product_id ) {
			$product = wc_get_product( $product_id );
			if ( $product ) {
				$product_list[] = array(
					'id'   => $product_id,
					'name' => $product->get_name(),
				);
			}
		}

		wp_send_json_success( array(
			'products' => $product_list,
			'total'    => count( $product_list ),
		) );
	}

	/**
	 * Publish a pre-signed event to relays.
	 */
	public function publish_signed_event() {
		if ( ! $this->verify_request() ) {
			return;
		}

		$event_json = isset( $_POST['event'] ) ? wp_unslash( $_POST['event'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$event_type = isset( $_POST['event_type'] ) ? sanitize_text_field( wp_unslash( $_POST['event_type'] ) ) : '';
		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;

		if ( empty( $event_json ) ) {
			wp_send_json_error( 'No event provided.' );
			return;
		}

		$event = json_decode( $event_json, true );

		if ( ! $event || ! isset( $event['id'] ) || ! isset( $event['sig'] ) ) {
			wp_send_json_error( 'Invalid signed event format.' );
			return;
		}

		// Verify the event has required fields.
		if ( ! isset( $event['pubkey'] ) || ! isset( $event['kind'] ) || ! isset( $event['content'] ) ) {
			wp_send_json_error( 'Event missing required fields.' );
			return;
		}

		// Verify the pubkey matches our saved pubkey.
		$saved_pubkey = $this->settings->get_public_key();
		if ( $event['pubkey'] !== $saved_pubkey ) {
			wp_send_json_error( 'Event pubkey does not match connected account.' );
			return;
		}

		// Publish to relays.
		$relays = $this->settings->get_relay_urls();

		if ( empty( $relays ) ) {
			wp_send_json_error( 'No relays configured.' );
			return;
		}

		$results       = $this->publish_to_relays( $event, $relays );
		$success_count = count( array_filter( $results, function( $r ) {
			return ! empty( $r['success'] );
		} ) );

		// Update sync metadata if it's a product.
		if ( 'product' === $event_type && $product_id && $success_count > 0 ) {
			update_post_meta( $product_id, '_woo_nostr_last_sync', time() );
			update_post_meta( $product_id, '_woo_nostr_event_id', $event['id'] );
		}

		// Update stall metadata if it's a stall.
		if ( 'stall' === $event_type && $success_count > 0 ) {
			$this->settings->set( 'stall_last_published', time() );
			$this->settings->set( 'stall_event_id', $event['id'] );
		}

		if ( $success_count > 0 ) {
			wp_send_json_success( array(
				'message' => sprintf(
					/* translators: %1$d: successful count, %2$d: total count */
					__( 'Published to %1$d of %2$d relays.', 'woo-nostr-market' ),
					$success_count,
					count( $relays )
				),
				'results' => $results,
			) );
		} else {
			wp_send_json_error( 'Failed to publish to any relay.' );
		}
	}

	/**
	 * Mark stall as published (called after browser-side relay publishing).
	 */
	public function mark_stall_published() {
		if ( ! $this->verify_request() ) {
			return;
		}

		$event_json = isset( $_POST['event'] ) ? wp_unslash( $_POST['event'] ) : ''; // phpcs:ignore
		$event = json_decode( $event_json, true );

		if ( $event && isset( $event['id'] ) ) {
			$this->settings->set( 'stall_last_published', time() );
			$this->settings->set( 'stall_event_id', $event['id'] );
		}

		wp_send_json_success( array( 'message' => 'Stall status updated.' ) );
	}

	/**
	 * Mark product as synced (called after browser-side relay publishing).
	 */
	public function mark_product_synced() {
		if ( ! $this->verify_request() ) {
			return;
		}

		$event_json = isset( $_POST['event'] ) ? wp_unslash( $_POST['event'] ) : ''; // phpcs:ignore
		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$event = json_decode( $event_json, true );

		if ( $product_id && $event && isset( $event['id'] ) ) {
			update_post_meta( $product_id, '_woo_nostr_last_sync', time() );
			update_post_meta( $product_id, '_woo_nostr_event_id', $event['id'] );
		}

		wp_send_json_success( array( 'message' => 'Product sync status updated.' ) );
	}

	/**
	 * Publish event to relays using HTTP POST or WebSocket.
	 *
	 * @param array $event  Signed Nostr event.
	 * @param array $relays Relay URLs.
	 * @return array Results per relay.
	 */
	private function publish_to_relays( $event, $relays ) {
		$results = array();

		// First try nak if available.
		$nak_path = $this->find_nak();
		if ( $nak_path ) {
			return $this->publish_with_nak( $event, $relays, $nak_path );
		}

		// Fallback to HTTP (limited relay support).
		foreach ( $relays as $relay ) {
			// Convert wss:// to https:// for HTTP-capable relays.
			$http_url = str_replace( array( 'wss://', 'ws://' ), array( 'https://', 'http://' ), $relay );

			$response = wp_remote_post(
				$http_url,
				array(
					'headers' => array( 'Content-Type' => 'application/json' ),
					'body'    => wp_json_encode( array( 'EVENT', $event ) ),
					'timeout' => 10,
				)
			);

			$results[ $relay ] = array(
				'success' => ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) < 300,
				'output'  => is_wp_error( $response ) ? $response->get_error_message() : wp_remote_retrieve_body( $response ),
			);
		}

		return $results;
	}

	/**
	 * Find nak CLI path.
	 *
	 * @return string|false Path to nak or false if not found.
	 */
	private function find_nak() {
		$paths = array(
			'nak',
			'/usr/local/bin/nak',
			'/usr/bin/nak',
			getenv( 'HOME' ) . '/.local/bin/nak',
			getenv( 'HOME' ) . '/go/bin/nak',
		);

		foreach ( $paths as $path ) {
			if ( empty( $path ) ) {
				continue;
			}

			$output = array();
			$result = -1;
			exec( escapeshellcmd( $path ) . ' --version 2>&1', $output, $result ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

			if ( 0 === $result || ! empty( $output ) ) {
				return $path;
			}
		}

		return false;
	}

	/**
	 * Publish event using nak CLI.
	 *
	 * @param array  $event    Signed event.
	 * @param array  $relays   Relay URLs.
	 * @param string $nak_path Path to nak binary.
	 * @return array Results per relay.
	 */
	private function publish_with_nak( $event, $relays, $nak_path ) {
		$results    = array();
		$event_json = wp_json_encode( $event );

		foreach ( $relays as $relay ) {
			$output = array();
			$result = -1;

			$cmd = 'echo ' . escapeshellarg( $event_json ) . ' | ' .
				escapeshellcmd( $nak_path ) . ' event ' .
				escapeshellarg( $relay ) . ' 2>&1';

			exec( $cmd, $output, $result ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

			$results[ $relay ] = array(
				'success' => 0 === $result,
				'output'  => implode( "\n", $output ),
			);
		}

		return $results;
	}
}
