<?php
/**
 * Settings management class.
 *
 * @package WooNostrMarket
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WooNostrMarket_Settings
 *
 * Handles plugin settings with encryption for sensitive data.
 */
class WooNostrMarket_Settings {

	/**
	 * Option prefix.
	 *
	 * @var string
	 */
	private $prefix = 'woo_nostr_market_';

	/**
	 * Constructor.
	 */
	public function __construct() {
		// Settings are loaded via WordPress options API.
	}

	/**
	 * Get a setting value.
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $default Default value.
	 * @return mixed
	 */
	public function get( $key, $default = '' ) {
		$value = get_option( $this->prefix . $key, $default );

		// Decrypt sensitive fields.
		if ( 'nostr_private_key' === $key && ! empty( $value ) ) {
			$value = $this->decrypt( $value );
		}

		if ( 'btcpay_api_key' === $key && ! empty( $value ) ) {
			$value = $this->decrypt( $value );
		}

		if ( 'webhook_secret' === $key && ! empty( $value ) ) {
			$value = $this->decrypt( $value );
		}

		return $value;
	}

	/**
	 * Set a setting value.
	 *
	 * @param string $key   Setting key.
	 * @param mixed  $value Setting value.
	 * @return bool
	 */
	public function set( $key, $value ) {
		// Encrypt sensitive fields.
		if ( 'nostr_private_key' === $key && ! empty( $value ) ) {
			$value = $this->encrypt( $value );
		}

		if ( 'btcpay_api_key' === $key && ! empty( $value ) ) {
			$value = $this->encrypt( $value );
		}

		if ( 'webhook_secret' === $key && ! empty( $value ) ) {
			$value = $this->encrypt( $value );
		}

		return update_option( $this->prefix . $key, $value );
	}

	/**
	 * Delete a setting.
	 *
	 * @param string $key Setting key.
	 * @return bool
	 */
	public function delete( $key ) {
		return delete_option( $this->prefix . $key );
	}

	/**
	 * Get the Nostr private key (decrypted).
	 *
	 * @return string
	 */
	public function get_private_key() {
		return $this->get( 'nostr_private_key', '' );
	}

	/**
	 * Get the Nostr public key.
	 *
	 * @return string
	 */
	public function get_public_key() {
		return $this->get( 'nostr_public_key', '' );
	}

	/**
	 * Get relay URLs.
	 *
	 * @return array
	 */
	public function get_relay_urls() {
		$relays = $this->get( 'relay_urls', array() );
		if ( ! is_array( $relays ) ) {
			$relays = array_filter( array_map( 'trim', explode( "\n", $relays ) ) );
		}
		return $relays;
	}

	/**
	 * Get the stall ID.
	 *
	 * @return string
	 */
	public function get_stall_id() {
		$stall_id = $this->get( 'stall_id', '' );
		if ( empty( $stall_id ) ) {
			$stall_id = wp_generate_uuid4();
			$this->set( 'stall_id', $stall_id );
		}
		return $stall_id;
	}

	/**
	 * Get BTCPay URL.
	 *
	 * @return string
	 */
	public function get_btcpay_url() {
		return $this->get( 'btcpay_url', '' );
	}

	/**
	 * Get BTCPay API key (decrypted).
	 *
	 * @return string
	 */
	public function get_btcpay_api_key() {
		return $this->get( 'btcpay_api_key', '' );
	}

	/**
	 * Check if the plugin is configured.
	 *
	 * @return bool
	 */
	public function is_configured() {
		return ! empty( $this->get_private_key() ) && ! empty( $this->get_public_key() );
	}

	/**
	 * Encrypt a value using WordPress salts.
	 *
	 * @param string $value Value to encrypt.
	 * @return string
	 */
	private function encrypt( $value ) {
		if ( empty( $value ) ) {
			return '';
		}

		$key = $this->get_encryption_key();

		// Use OpenSSL for encryption.
		if ( function_exists( 'openssl_encrypt' ) ) {
			$iv        = openssl_random_pseudo_bytes( 16 );
			$encrypted = openssl_encrypt( $value, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );
			if ( false === $encrypted ) {
				return $value; // Fallback to unencrypted if encryption fails.
			}
			return base64_encode( $iv . $encrypted ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
		}

		// No fallback - require OpenSSL for security.
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log( 'WooNostrMarket: OpenSSL required for encryption. Cannot store sensitive data.' );
		return ''; // Return empty - don't store unencrypted keys
	}

	/**
	 * Decrypt a value using WordPress salts.
	 *
	 * @param string $value Value to decrypt.
	 * @return string
	 */
	private function decrypt( $value ) {
		if ( empty( $value ) ) {
			return '';
		}

		$key = $this->get_encryption_key();

		// Use OpenSSL for decryption.
		if ( function_exists( 'openssl_decrypt' ) ) {
			$data = base64_decode( $value, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
			if ( false === $data || strlen( $data ) < 16 ) {
				return $value; // Return as-is if decoding fails.
			}
			$iv        = substr( $data, 0, 16 );
			$encrypted = substr( $data, 16 );
			$decrypted = openssl_decrypt( $encrypted, 'AES-256-CBC', $key, OPENSSL_RAW_DATA, $iv );
			if ( false === $decrypted ) {
				return $value; // Return as-is if decryption fails (might be unencrypted).
			}
			return $decrypted;
		}

		// No fallback without OpenSSL - return empty.
		// phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		error_log( 'WooNostrMarket: OpenSSL required for decryption.' );
		return '';
	}

	/**
	 * Get encryption key from WordPress salts.
	 *
	 * @return string
	 */
	private function get_encryption_key() {
		$salts = '';

		if ( defined( 'AUTH_KEY' ) ) {
			$salts .= AUTH_KEY;
		}
		if ( defined( 'SECURE_AUTH_KEY' ) ) {
			$salts .= SECURE_AUTH_KEY;
		}
		if ( defined( 'LOGGED_IN_KEY' ) ) {
			$salts .= LOGGED_IN_KEY;
		}

		// Create a consistent 32-byte key.
		return hash( 'sha256', $salts, true );
	}

	/**
	 * XOR string encryption/decryption (fallback).
	 *
	 * @param string $string String to XOR.
	 * @param string $key    Key to XOR with.
	 * @return string
	 */
	private function xor_string( $string, $key ) {
		$result     = '';
		$key_length = strlen( $key );

		for ( $i = 0; $i < strlen( $string ); $i++ ) {
			$result .= $string[ $i ] ^ $key[ $i % $key_length ];
		}

		return $result;
	}

	/**
	 * Get all settings for display (masks sensitive data).
	 *
	 * @return array
	 */
	public function get_all_for_display() {
		return array(
			'nostr_public_key' => $this->get_public_key(),
			'has_private_key'  => ! empty( $this->get_private_key() ),
			'relay_urls'       => $this->get_relay_urls(),
			'stall_id'         => $this->get_stall_id(),
			'btcpay_url'       => $this->get_btcpay_url(),
			'has_btcpay_key'   => ! empty( $this->get_btcpay_api_key() ),
		);
	}
}
