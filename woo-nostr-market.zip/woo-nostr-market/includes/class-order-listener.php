<?php
/**
 * Order listener class for NIP-04 encrypted DMs and order processing.
 *
 * @package WooNostrMarket
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WooNostrMarket_Order_Listener
 *
 * Handles:
 * - NIP-04 encryption/decryption
 * - Parsing NIP-15 order messages
 * - Creating WooCommerce orders from Nostr orders
 * - Sending payment requests and status updates via Nostr DM
 */
class WooNostrMarket_Order_Listener {

	/**
	 * NIP-04 direct message kind.
	 *
	 * @var int
	 */
	const DM_KIND = 4;

	/**
	 * NIP-15 order message type.
	 *
	 * @var int
	 */
	const ORDER_TYPE = 0;

	/**
	 * NIP-15 payment request type.
	 *
	 * @var int
	 */
	const PAYMENT_REQUEST_TYPE = 1;

	/**
	 * NIP-15 order status update type.
	 *
	 * @var int
	 */
	const ORDER_STATUS_TYPE = 2;

	/**
	 * Settings instance.
	 *
	 * @var WooNostrMarket_Settings
	 */
	private $settings;

	/**
	 * Nostr client instance.
	 *
	 * @var WooNostrMarket_Nostr_Client
	 */
	private $nostr_client;

	/**
	 * Path to nak CLI.
	 *
	 * @var string
	 */
	private $nak_path = 'nak';

	/**
	 * Constructor.
	 *
	 * @param WooNostrMarket_Settings     $settings     Settings instance.
	 * @param WooNostrMarket_Nostr_Client $nostr_client Nostr client instance.
	 */
	public function __construct( WooNostrMarket_Settings $settings, WooNostrMarket_Nostr_Client $nostr_client ) {
		$this->settings     = $settings;
		$this->nostr_client = $nostr_client;
		
		// Find nak path.
		$this->find_nak_path();
	}

	/**
	 * Find nak CLI path.
	 */
	private function find_nak_path() {
		$paths = array(
			'nak',
			'/usr/local/bin/nak',
			'/usr/bin/nak',
			getenv( 'HOME' ) . '/go/bin/nak',
			'/root/go/bin/nak',
		);

		foreach ( $paths as $path ) {
			$output = array();
			$result = -1;
			exec( escapeshellcmd( $path ) . ' --version 2>&1', $output, $result ); // phpcs:ignore

			if ( 0 === $result || ! empty( $output ) ) {
				$this->nak_path = $path;
				return;
			}
		}
	}

	/**
	 * Parse a NIP-15 order from decrypted message.
	 *
	 * Expected format:
	 * {
	 *   "id": "<customer_order_id>",
	 *   "type": 0,
	 *   "name": "<optional customer name>",
	 *   "address": "123 Main St, City, Country",
	 *   "message": "<optional message>",
	 *   "contact": {
	 *     "nostr": "<customer_pubkey>",
	 *     "phone": "<optional>",
	 *     "email": "<optional>"
	 *   },
	 *   "items": [
	 *     {"product_id": "123", "quantity": 2}
	 *   ],
	 *   "shipping_id": "usa_zone"
	 * }
	 *
	 * @param string $message Decrypted message content (JSON string).
	 * @return array|WP_Error Parsed order data or error.
	 */
	public function parse_order( $message ) {
		$data = json_decode( $message, true );

		if ( null === $data || ! is_array( $data ) ) {
			return new WP_Error( 'invalid_json', __( 'Invalid order JSON.', 'woo-nostr-market' ) );
		}

		if ( ! isset( $data['type'] ) || self::ORDER_TYPE !== (int) $data['type'] ) {
			return new WP_Error( 'not_an_order', __( 'Message is not an order (type 0).', 'woo-nostr-market' ) );
		}

		// Validate required fields.
		if ( empty( $data['id'] ) ) {
			return new WP_Error( 'missing_field', __( 'Order missing required field: id', 'woo-nostr-market' ) );
		}

		if ( empty( $data['items'] ) || ! is_array( $data['items'] ) ) {
			return new WP_Error( 'missing_field', __( 'Order missing required field: items', 'woo-nostr-market' ) );
		}

		// Validate items.
		foreach ( $data['items'] as $item ) {
			if ( empty( $item['product_id'] ) || ! isset( $item['quantity'] ) ) {
				return new WP_Error( 'invalid_item', __( 'Order item missing product_id or quantity.', 'woo-nostr-market' ) );
			}
		}

		return $data;
	}

	/**
	 * Create a WooCommerce order from a NIP-15 order.
	 *
	 * @param array  $order_data    Parsed order data.
	 * @param string $customer_pubkey Customer's Nostr pubkey.
	 * @return WC_Order|WP_Error Created order or error.
	 */
	public function create_wc_order( $order_data, $customer_pubkey ) {
		try {
			// Create the order.
			$order = wc_create_order();

			if ( is_wp_error( $order ) ) {
				return $order;
			}

			// Add line items.
			foreach ( $order_data['items'] as $item ) {
				$product_id = absint( $item['product_id'] );
				$quantity   = absint( $item['quantity'] );

				$product = wc_get_product( $product_id );

				if ( ! $product ) {
					$order->delete( true );
					return new WP_Error(
						'product_not_found',
						sprintf( __( 'Product %d not found.', 'woo-nostr-market' ), $product_id )
					);
				}

				if ( ! $product->is_in_stock() || ( $product->get_stock_quantity() !== null && $product->get_stock_quantity() < $quantity ) ) {
					$order->delete( true );
					return new WP_Error(
						'insufficient_stock',
						sprintf( __( 'Insufficient stock for product %d.', 'woo-nostr-market' ), $product_id )
					);
				}

				$order->add_product( $product, $quantity );
			}

			// Set shipping address if provided.
			if ( ! empty( $order_data['address'] ) ) {
				$address = $this->parse_address( $order_data['address'] );
				$order->set_address( $address, 'shipping' );
				$order->set_address( $address, 'billing' );
			}

			// Set customer name if provided.
			if ( ! empty( $order_data['name'] ) ) {
				$order->set_billing_first_name( $order_data['name'] );
				$order->set_shipping_first_name( $order_data['name'] );
			}

			// Set contact info.
			if ( ! empty( $order_data['contact'] ) ) {
				if ( ! empty( $order_data['contact']['email'] ) ) {
					$order->set_billing_email( sanitize_email( $order_data['contact']['email'] ) );
				}
				if ( ! empty( $order_data['contact']['phone'] ) ) {
					$order->set_billing_phone( sanitize_text_field( $order_data['contact']['phone'] ) );
				}
			}

			// Add shipping cost if shipping zone specified.
			if ( ! empty( $order_data['shipping_id'] ) ) {
				$shipping_cost = $this->get_shipping_cost( $order_data['shipping_id'] );
				if ( $shipping_cost > 0 ) {
					$shipping = new WC_Order_Item_Shipping();
					$shipping->set_method_title( __( 'Nostr Marketplace Shipping', 'woo-nostr-market' ) );
					$shipping->set_total( $shipping_cost );
					$order->add_item( $shipping );
				}
			}

			// Add customer note if message provided.
			if ( ! empty( $order_data['message'] ) ) {
				$order->set_customer_note( sanitize_textarea_field( $order_data['message'] ) );
			}

			// Calculate totals.
			$order->calculate_totals();

			// Set order status to pending payment.
			$order->set_status( 'pending', __( 'Order received via Nostr marketplace.', 'woo-nostr-market' ) );

			// Add Nostr-specific note.
			$order->add_order_note(
				sprintf(
					__( 'Nostr order received. Customer pubkey: %s', 'woo-nostr-market' ),
					substr( $customer_pubkey, 0, 16 ) . '...'
				)
			);

			$order->save();

			return $order;

		} catch ( Exception $e ) {
			return new WP_Error( 'order_creation_failed', $e->getMessage() );
		}
	}

	/**
	 * Parse address string into WooCommerce address array.
	 *
	 * @param string $address_string Full address string.
	 * @return array Address components.
	 */
	private function parse_address( $address_string ) {
		// Simple parsing - put everything in address_1 for now.
		// More sophisticated parsing could extract city, state, country.
		$address = array(
			'first_name' => '',
			'last_name'  => '',
			'company'    => '',
			'address_1'  => sanitize_textarea_field( $address_string ),
			'address_2'  => '',
			'city'       => '',
			'state'      => '',
			'postcode'   => '',
			'country'    => '',
		);

		// Try to extract country if it's the last part after a comma.
		$parts = array_map( 'trim', explode( ',', $address_string ) );
		if ( count( $parts ) >= 2 ) {
			$last_part = array_pop( $parts );
			// Check if it looks like a country code or name.
			if ( strlen( $last_part ) === 2 || strlen( $last_part ) <= 30 ) {
				$address['country']   = strtoupper( substr( $last_part, 0, 2 ) );
				$address['address_1'] = implode( ', ', $parts );
			}
		}

		return $address;
	}

	/**
	 * Get shipping cost for a shipping zone.
	 *
	 * Looks up shipping cost from the stall manager's live WooCommerce data,
	 * matching the shipping_id from the customer's order to configured zones.
	 *
	 * @param string $shipping_id Shipping zone ID from order.
	 * @return float Shipping cost.
	 */
	private function get_shipping_cost( $shipping_id ) {
		// Get live stall data from the stall manager (includes shipping zones).
		$stall_manager = woo_nostr_market()->stall_manager;
		if ( $stall_manager ) {
			$stall_data = $stall_manager->get_stall_data();
			if ( ! empty( $stall_data['shipping'] ) ) {
				foreach ( $stall_data['shipping'] as $zone ) {
					if ( isset( $zone['id'] ) && $zone['id'] === $shipping_id ) {
						return isset( $zone['cost'] ) ? (float) $zone['cost'] : 0;
					}
				}
			}
		}

		return 0;
	}

	/**
	 * Send a payment request to customer via Nostr DM.
	 *
	 * @param WC_Order $order           WooCommerce order.
	 * @param string   $customer_pubkey Customer's Nostr pubkey.
	 * @return array|WP_Error Send result or error.
	 */
	public function send_payment_request( $order, $customer_pubkey ) {
		$nostr_order_id = $order->get_meta( '_nostr_order_id' );

		if ( empty( $nostr_order_id ) ) {
			$nostr_order_id = 'wc-' . $order->get_id();
		}

		// Generate payment options.
		$payment_options = $this->generate_payment_options( $order );

		if ( is_wp_error( $payment_options ) ) {
			return $payment_options;
		}

		// Build NIP-15 payment request message.
		$payment_request = array(
			'id'              => $nostr_order_id,
			'type'            => self::PAYMENT_REQUEST_TYPE,
			'message'         => sprintf(
				__( 'Payment request for order %s. Total: %s', 'woo-nostr-market' ),
				$order->get_order_number(),
				$order->get_formatted_order_total()
			),
			'payment_options' => $payment_options,
		);

		// Encrypt and send.
		$message_json = wp_json_encode( $payment_request );
		
		return $this->send_encrypted_dm( $customer_pubkey, $message_json );
	}

	/**
	 * Generate payment options for an order.
	 *
	 * @param WC_Order $order WooCommerce order.
	 * @return array|WP_Error Payment options array or error.
	 */
	private function generate_payment_options( $order ) {
		$options = array();

		// Try BTCPay Server if configured.
		$btcpay_url     = $this->settings->get( 'btcpay_url' );
		$btcpay_api_key = $this->settings->get( 'btcpay_api_key' );
		$btcpay_store_id = $this->settings->get( 'btcpay_store_id' );

		if ( ! empty( $btcpay_url ) && ! empty( $btcpay_api_key ) && ! empty( $btcpay_store_id ) ) {
			$invoice = $this->create_btcpay_invoice( $order, $btcpay_url, $btcpay_api_key, $btcpay_store_id );

			if ( ! is_wp_error( $invoice ) ) {
				// Add Lightning invoice option.
				if ( ! empty( $invoice['lightning'] ) ) {
					$options[] = array(
						'type' => 'ln',
						'link' => $invoice['lightning'],
					);
				}

				// Add onchain option.
				if ( ! empty( $invoice['bitcoin'] ) ) {
					$options[] = array(
						'type' => 'btc',
						'link' => $invoice['bitcoin'],
					);
				}

				// Add checkout URL.
				if ( ! empty( $invoice['checkoutLink'] ) ) {
					$options[] = array(
						'type' => 'url',
						'link' => $invoice['checkoutLink'],
					);
				}

				// Store invoice ID on order.
				$order->update_meta_data( '_btcpay_invoice_id', $invoice['id'] );
				$order->save();
			}
		}

		// If no BTCPay, check for Lightning Address in settings.
		if ( empty( $options ) ) {
			$lightning_address = $this->settings->get( 'lightning_address' );
			if ( ! empty( $lightning_address ) ) {
				$options[] = array(
					'type' => 'lnurl',
					'link' => $lightning_address,
				);
			}
		}

		if ( empty( $options ) ) {
			return new WP_Error( 'no_payment_options', __( 'No payment options configured.', 'woo-nostr-market' ) );
		}

		return $options;
	}

	/**
	 * Create BTCPay Server invoice.
	 *
	 * @param WC_Order $order    WooCommerce order.
	 * @param string   $url      BTCPay Server URL.
	 * @param string   $api_key  API key.
	 * @param string   $store_id Store ID.
	 * @return array|WP_Error Invoice data or error.
	 */
	private function create_btcpay_invoice( $order, $url, $api_key, $store_id ) {
		$total    = $order->get_total();
		$currency = $order->get_currency();

		$invoice_data = array(
			'amount'   => (float) $total,
			'currency' => $currency,
			'metadata' => array(
				'orderId'     => $order->get_id(),
				'orderNumber' => $order->get_order_number(),
			),
			'checkout' => array(
				'redirectURL' => $order->get_checkout_order_received_url(),
			),
		);

		$response = wp_remote_post(
			trailingslashit( $url ) . 'api/v1/stores/' . $store_id . '/invoices',
			array(
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Authorization' => 'token ' . $api_key,
				),
				'body'    => wp_json_encode( $invoice_data ),
				'timeout' => 30,
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$code = wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $code >= 400 ) {
			return new WP_Error(
				'btcpay_error',
				isset( $body['message'] ) ? $body['message'] : __( 'BTCPay invoice creation failed.', 'woo-nostr-market' )
			);
		}

		// Get payment methods to extract Lightning invoice.
		$payment_methods = $this->get_btcpay_payment_methods( $url, $api_key, $store_id, $body['id'] );

		return array(
			'id'           => $body['id'],
			'checkoutLink' => $body['checkoutLink'],
			'lightning'    => isset( $payment_methods['BTC_LightningNetwork'] ) ? $payment_methods['BTC_LightningNetwork'] : null,
			'bitcoin'      => isset( $payment_methods['BTC'] ) ? $payment_methods['BTC'] : null,
		);
	}

	/**
	 * Get BTCPay payment methods for an invoice.
	 *
	 * @param string $url       BTCPay Server URL.
	 * @param string $api_key   API key.
	 * @param string $store_id  Store ID.
	 * @param string $invoice_id Invoice ID.
	 * @return array Payment methods.
	 */
	private function get_btcpay_payment_methods( $url, $api_key, $store_id, $invoice_id ) {
		$response = wp_remote_get(
			trailingslashit( $url ) . 'api/v1/stores/' . $store_id . '/invoices/' . $invoice_id . '/payment-methods',
			array(
				'headers' => array(
					'Authorization' => 'token ' . $api_key,
				),
				'timeout' => 30,
			)
		);

		if ( is_wp_error( $response ) ) {
			return array();
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $body ) ) {
			return array();
		}

		$methods = array();
		foreach ( $body as $method ) {
			if ( isset( $method['paymentMethodId'] ) && isset( $method['destination'] ) ) {
				$methods[ $method['paymentMethodId'] ] = $method['destination'];
			}
		}

		return $methods;
	}

	/**
	 * Send an order status update to customer.
	 *
	 * @param WC_Order $order           WooCommerce order.
	 * @param bool     $paid            Whether order is paid.
	 * @param bool     $shipped         Whether order is shipped.
	 * @param string   $customer_pubkey Customer's Nostr pubkey.
	 * @return array|WP_Error Send result or error.
	 */
	public function send_order_status_update( $order, $paid = false, $shipped = false, $customer_pubkey = '' ) {
		if ( empty( $customer_pubkey ) ) {
			$customer_pubkey = $order->get_meta( '_nostr_customer_pubkey' );
		}

		if ( empty( $customer_pubkey ) ) {
			return new WP_Error( 'no_customer_pubkey', __( 'No customer pubkey for order.', 'woo-nostr-market' ) );
		}

		$nostr_order_id = $order->get_meta( '_nostr_order_id' );
		if ( empty( $nostr_order_id ) ) {
			$nostr_order_id = 'wc-' . $order->get_id();
		}

		// Build NIP-15 status update message.
		$status_message = '';
		if ( $paid && $shipped ) {
			$status_message = __( 'Your order has been paid and shipped!', 'woo-nostr-market' );
		} elseif ( $paid ) {
			$status_message = __( 'Payment received! Your order is being prepared.', 'woo-nostr-market' );
		} elseif ( $shipped ) {
			$status_message = __( 'Your order has been shipped!', 'woo-nostr-market' );
		}

		$status_update = array(
			'id'      => $nostr_order_id,
			'type'    => self::ORDER_STATUS_TYPE,
			'message' => $status_message,
			'paid'    => $paid,
			'shipped' => $shipped,
		);

		$message_json = wp_json_encode( $status_update );

		return $this->send_encrypted_dm( $customer_pubkey, $message_json );
	}

	/**
	 * Decrypt a NIP-04 message.
	 *
	 * Uses PHP-native secp256k1 + OpenSSL (preferred) with nak CLI fallback.
	 *
	 * @param string $encrypted_content Encrypted content (base64?iv=...).
	 * @param string $sender_pubkey     Sender's public key (hex).
	 * @return string|WP_Error Decrypted content or error.
	 */
	public function decrypt_nip04( $encrypted_content, $sender_pubkey ) {
		$private_key = $this->settings->get_private_key();

		if ( empty( $private_key ) ) {
			return new WP_Error( 'no_private_key', __( 'No private key configured for decryption.', 'woo-nostr-market' ) );
		}

		// Try PHP-native first (no external dependencies).
		if ( WooNostrMarket_Secp256k1::is_available() && function_exists( 'openssl_decrypt' ) ) {
			$result = $this->decrypt_nip04_php( $encrypted_content, $sender_pubkey, $private_key );
			if ( ! is_wp_error( $result ) ) {
				return $result;
			}
			// Log PHP failure and try nak fallback.
			if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
				error_log( '[WooNostrMarket] PHP NIP-04 decrypt failed: ' . $result->get_error_message() . '. Trying nak fallback.' ); // phpcs:ignore
			}
		}

		// Fallback to nak CLI.
		return $this->decrypt_nip04_nak( $encrypted_content, $sender_pubkey, $private_key );
	}

	/**
	 * Decrypt NIP-04 using pure PHP (secp256k1 ECDH + AES-256-CBC).
	 *
	 * @param string $encrypted_content NIP-04 formatted content.
	 * @param string $sender_pubkey     Sender public key (hex).
	 * @param string $private_key       Our private key (hex).
	 * @return string|WP_Error Decrypted content or error.
	 */
	private function decrypt_nip04_php( $encrypted_content, $sender_pubkey, $private_key ) {
		// Parse NIP-04 format: base64(ciphertext)?iv=base64(iv).
		if ( ! preg_match( '/^(.+)\?iv=(.+)$/', $encrypted_content, $matches ) ) {
			return new WP_Error( 'invalid_nip04_format', __( 'Invalid NIP-04 format: expected base64?iv=base64.', 'woo-nostr-market' ) );
		}

		$ciphertext = base64_decode( $matches[1], true ); // phpcs:ignore
		$iv         = base64_decode( $matches[2], true ); // phpcs:ignore

		if ( false === $ciphertext || false === $iv ) {
			return new WP_Error( 'base64_decode_failed', __( 'Failed to decode NIP-04 base64 content.', 'woo-nostr-market' ) );
		}

		if ( 16 !== strlen( $iv ) ) {
			return new WP_Error( 'invalid_iv', __( 'NIP-04 IV must be 16 bytes.', 'woo-nostr-market' ) );
		}

		// Compute ECDH shared secret.
		try {
			$ec                = new WooNostrMarket_Secp256k1();
			$shared_secret_hex = $ec->ecdh( $private_key, $sender_pubkey );
			$shared_secret     = hex2bin( $shared_secret_hex );
		} catch ( Exception $e ) {
			return new WP_Error( 'ecdh_failed', sprintf( __( 'ECDH failed: %s', 'woo-nostr-market' ), $e->getMessage() ) );
		}

		// Decrypt with AES-256-CBC.
		$decrypted = openssl_decrypt( $ciphertext, 'aes-256-cbc', $shared_secret, OPENSSL_RAW_DATA, $iv );

		if ( false === $decrypted ) {
			return new WP_Error( 'aes_decrypt_failed', __( 'AES-256-CBC decryption failed.', 'woo-nostr-market' ) );
		}

		return $decrypted;
	}

	/**
	 * Decrypt NIP-04 using nak CLI (fallback).
	 *
	 * @param string $encrypted_content NIP-04 formatted content.
	 * @param string $sender_pubkey     Sender public key (hex).
	 * @param string $private_key       Our private key (hex).
	 * @return string|WP_Error Decrypted content or error.
	 */
	private function decrypt_nip04_nak( $encrypted_content, $sender_pubkey, $private_key ) {
		$cmd = sprintf(
			'echo %s | %s decode nip04 --sec %s --from %s 2>&1',
			escapeshellarg( $encrypted_content ),
			escapeshellcmd( $this->nak_path ),
			escapeshellarg( $private_key ),
			escapeshellarg( $sender_pubkey )
		);

		$output = array();
		$result = -1;
		exec( $cmd, $output, $result ); // phpcs:ignore

		if ( 0 !== $result || empty( $output ) ) {
			// Try alternative command syntax.
			$cmd = sprintf(
				'%s decode nip04 --sec %s --from %s %s 2>&1',
				escapeshellcmd( $this->nak_path ),
				escapeshellarg( $private_key ),
				escapeshellarg( $sender_pubkey ),
				escapeshellarg( $encrypted_content )
			);

			$output = array();
			exec( $cmd, $output, $result ); // phpcs:ignore

			if ( 0 !== $result || empty( $output ) ) {
				$error_msg = ! empty( $output ) ? implode( "\n", $output ) : __( 'nak CLI not found or decryption failed. Install php-gmp for native decryption.', 'woo-nostr-market' );
				return new WP_Error( 'decryption_failed', $error_msg );
			}
		}

		return implode( "\n", $output );
	}

	/**
	 * Encrypt a message using NIP-04.
	 *
	 * Uses PHP-native secp256k1 + OpenSSL (preferred) with nak CLI fallback.
	 *
	 * @param string $content          Content to encrypt.
	 * @param string $recipient_pubkey Recipient's public key (hex).
	 * @return string|WP_Error Encrypted content or error.
	 */
	public function encrypt_nip04( $content, $recipient_pubkey ) {
		$private_key = $this->settings->get_private_key();

		if ( empty( $private_key ) ) {
			return new WP_Error( 'no_private_key', __( 'No private key configured for encryption.', 'woo-nostr-market' ) );
		}

		// Try PHP-native first.
		if ( WooNostrMarket_Secp256k1::is_available() && function_exists( 'openssl_encrypt' ) ) {
			$result = $this->encrypt_nip04_php( $content, $recipient_pubkey, $private_key );
			if ( ! is_wp_error( $result ) ) {
				return $result;
			}
		}

		// Fallback to nak CLI.
		return $this->encrypt_nip04_nak( $content, $recipient_pubkey, $private_key );
	}

	/**
	 * Encrypt NIP-04 using pure PHP (secp256k1 ECDH + AES-256-CBC).
	 *
	 * @param string $content          Plaintext content.
	 * @param string $recipient_pubkey Recipient public key (hex).
	 * @param string $private_key      Our private key (hex).
	 * @return string|WP_Error NIP-04 formatted string or error.
	 */
	private function encrypt_nip04_php( $content, $recipient_pubkey, $private_key ) {
		// Compute ECDH shared secret.
		try {
			$ec                = new WooNostrMarket_Secp256k1();
			$shared_secret_hex = $ec->ecdh( $private_key, $recipient_pubkey );
			$shared_secret     = hex2bin( $shared_secret_hex );
		} catch ( Exception $e ) {
			return new WP_Error( 'ecdh_failed', $e->getMessage() );
		}

		// Generate random IV.
		$iv = openssl_random_pseudo_bytes( 16 );

		// Encrypt with AES-256-CBC.
		$ciphertext = openssl_encrypt( $content, 'aes-256-cbc', $shared_secret, OPENSSL_RAW_DATA, $iv );

		if ( false === $ciphertext ) {
			return new WP_Error( 'aes_encrypt_failed', __( 'AES-256-CBC encryption failed.', 'woo-nostr-market' ) );
		}

		// NIP-04 format: base64(ciphertext)?iv=base64(iv).
		return base64_encode( $ciphertext ) . '?iv=' . base64_encode( $iv ); // phpcs:ignore
	}

	/**
	 * Encrypt NIP-04 using nak CLI (fallback).
	 *
	 * @param string $content          Plaintext content.
	 * @param string $recipient_pubkey Recipient public key (hex).
	 * @param string $private_key      Our private key (hex).
	 * @return string|WP_Error NIP-04 formatted string or error.
	 */
	private function encrypt_nip04_nak( $content, $recipient_pubkey, $private_key ) {
		$cmd = sprintf(
			'echo %s | %s encode nip04 --sec %s --to %s 2>&1',
			escapeshellarg( $content ),
			escapeshellcmd( $this->nak_path ),
			escapeshellarg( $private_key ),
			escapeshellarg( $recipient_pubkey )
		);

		$output = array();
		$result = -1;
		exec( $cmd, $output, $result ); // phpcs:ignore

		if ( 0 !== $result || empty( $output[0] ) ) {
			$error_msg = ! empty( $output ) ? implode( "\n", $output ) : __( 'nak CLI not found. Install php-gmp for native encryption.', 'woo-nostr-market' );
			return new WP_Error( 'encryption_failed', $error_msg );
		}

		return trim( $output[0] );
	}

	/**
	 * Send an encrypted DM to a pubkey.
	 *
	 * @param string $recipient_pubkey Recipient's pubkey.
	 * @param string $content          Message content (will be encrypted).
	 * @return array|WP_Error Result or error.
	 */
	private function send_encrypted_dm( $recipient_pubkey, $content ) {
		// Encrypt the content.
		$encrypted = $this->encrypt_nip04( $content, $recipient_pubkey );

		if ( is_wp_error( $encrypted ) ) {
			return $encrypted;
		}

		// Create and sign the DM event.
		$tags = array(
			array( 'p', $recipient_pubkey ),
		);

		$result = $this->nostr_client->create_sign_and_publish( self::DM_KIND, $encrypted, $tags );

		return $result;
	}

	/**
	 * Get pending Nostr orders.
	 *
	 * @return array Pending orders with Nostr metadata.
	 */
	public function get_pending_orders() {
		$orders = wc_get_orders(
			array(
				'status'     => 'pending',
				'meta_key'   => '_nostr_order_id',
				'meta_compare' => 'EXISTS',
				'limit'      => 50,
			)
		);

		$result = array();
		foreach ( $orders as $order ) {
			$result[] = array(
				'wc_order_id'      => $order->get_id(),
				'nostr_order_id'   => $order->get_meta( '_nostr_order_id' ),
				'customer_pubkey'  => $order->get_meta( '_nostr_customer_pubkey' ),
				'total'            => $order->get_total(),
				'date_created'     => $order->get_date_created()->getTimestamp(),
			);
		}

		return $result;
	}

	/**
	 * Check if order listener is active.
	 *
	 * @return bool
	 */
	public function is_active() {
		// Active if we have a private key and webhook secret configured.
		$private_key    = $this->settings->get_private_key();
		$webhook_secret = $this->settings->get( 'webhook_secret' );

		return ! empty( $private_key ) && ! empty( $webhook_secret );
	}
}
