<?php
/**
 * REST API endpoint for receiving order webhooks from nostr-order-listener.
 *
 * @package WooNostrMarket
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WooNostrMarket_Webhook_API
 *
 * Handles incoming webhooks from the nostr-order-listener service.
 * Verifies HMAC signatures, decrypts NIP-04 messages, and processes orders.
 */
class WooNostrMarket_Webhook_API {

	/**
	 * REST namespace.
	 *
	 * @var string
	 */
	const REST_NAMESPACE = 'woo-nostr-market/v1';

	/**
	 * Settings instance.
	 *
	 * @var WooNostrMarket_Settings
	 */
	private $settings;

	/**
	 * Nostr client instance.
	 *
	 * @var WooNostrMarket_Nostr_Client
	 */
	private $nostr_client;

	/**
	 * Order listener instance.
	 *
	 * @var WooNostrMarket_Order_Listener
	 */
	private $order_listener;

	/**
	 * Constructor.
	 *
	 * @param WooNostrMarket_Settings       $settings       Settings instance.
	 * @param WooNostrMarket_Nostr_Client   $nostr_client   Nostr client instance.
	 * @param WooNostrMarket_Order_Listener $order_listener Order listener instance.
	 */
	public function __construct( $settings, $nostr_client, $order_listener ) {
		$this->settings       = $settings;
		$this->nostr_client   = $nostr_client;
		$this->order_listener = $order_listener;

		add_action( 'rest_api_init', array( $this, 'register_routes' ) );
	}

	/**
	 * Register REST routes.
	 */
	public function register_routes() {
		register_rest_route(
			self::REST_NAMESPACE,
			'/order-webhook',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_order_webhook' ),
				'permission_callback' => array( $this, 'verify_webhook_signature' ),
			)
		);

		register_rest_route(
			self::REST_NAMESPACE,
			'/webhook-test',
			array(
				'methods'             => 'POST',
				'callback'            => array( $this, 'handle_webhook_test' ),
				'permission_callback' => '__return_true',
			)
		);
	}

	/**
	 * Verify webhook signature.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return bool|WP_Error
	 */
	public function verify_webhook_signature( $request ) {
		$signature_header = $request->get_header( 'X-Webhook-Signature' );
		$webhook_secret   = $this->settings->get( 'webhook_secret' );

		// If no secret configured, reject all webhooks.
		if ( empty( $webhook_secret ) ) {
			return new WP_Error(
				'webhook_not_configured',
				__( 'Webhook secret not configured.', 'woo-nostr-market' ),
				array( 'status' => 403 )
			);
		}

		// If no signature provided, reject.
		if ( empty( $signature_header ) ) {
			return new WP_Error(
				'missing_signature',
				__( 'Missing webhook signature.', 'woo-nostr-market' ),
				array( 'status' => 401 )
			);
		}

		// Parse signature (format: sha256=...)
		if ( ! preg_match( '/^sha256=([a-f0-9]+)$/i', $signature_header, $matches ) ) {
			return new WP_Error(
				'invalid_signature_format',
				__( 'Invalid signature format.', 'woo-nostr-market' ),
				array( 'status' => 401 )
			);
		}

		$provided_signature = $matches[1];

		// Calculate expected signature.
		$body              = $request->get_body();
		$expected_signature = hash_hmac( 'sha256', $body, $webhook_secret );

		// Constant-time comparison.
		if ( ! hash_equals( $expected_signature, $provided_signature ) ) {
			return new WP_Error(
				'invalid_signature',
				__( 'Invalid webhook signature.', 'woo-nostr-market' ),
				array( 'status' => 401 )
			);
		}

		return true;
	}

	/**
	 * Handle incoming order webhook.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response|WP_Error
	 */
	public function handle_order_webhook( $request ) {
		$payload = $request->get_json_params();

		// Validate payload structure.
		if ( empty( $payload['event'] ) || ! is_array( $payload['event'] ) ) {
			return new WP_Error(
				'invalid_payload',
				__( 'Invalid webhook payload: missing event.', 'woo-nostr-market' ),
				array( 'status' => 400 )
			);
		}

		$event = $payload['event'];
		$relay = isset( $payload['relay'] ) ? $payload['relay'] : 'unknown';

		// Validate event structure.
		$required_fields = array( 'id', 'pubkey', 'kind', 'content', 'sig' );
		foreach ( $required_fields as $field ) {
			if ( ! isset( $event[ $field ] ) ) {
				return new WP_Error(
					'invalid_event',
					sprintf( __( 'Invalid event: missing %s.', 'woo-nostr-market' ), $field ),
					array( 'status' => 400 )
				);
			}
		}

		// Must be a DM (kind 4).
		if ( 4 !== (int) $event['kind'] ) {
			return new WP_Error(
				'wrong_event_kind',
				__( 'Event must be kind 4 (direct message).', 'woo-nostr-market' ),
				array( 'status' => 400 )
			);
		}

		// Log incoming event (event ID only, not content).
		$this->log_event( $event['id'], $event['pubkey'], $relay );

		// Process the encrypted DM.
		$result = $this->process_incoming_dm( $event );

		if ( is_wp_error( $result ) ) {
			// Log error but return 200 to prevent retries for non-transient errors.
			$this->log_error( $event['id'], $result->get_error_message() );

			// Return error details for debugging.
			return new WP_REST_Response(
				array(
					'success' => false,
					'error'   => $result->get_error_code(),
					'message' => $result->get_error_message(),
				),
				200 // Return 200 to prevent webhook retries.
			);
		}

		return new WP_REST_Response(
			array(
				'success'  => true,
				'order_id' => $result['order_id'],
				'wc_order' => $result['wc_order_id'],
			),
			200
		);
	}

	/**
	 * Process an incoming encrypted DM.
	 *
	 * @param array $event Nostr event.
	 * @return array|WP_Error Processing result or error.
	 */
	private function process_incoming_dm( $event ) {
		$sender_pubkey = $event['pubkey'];
		$encrypted_content = $event['content'];

		// Decrypt the message using NIP-04.
		$decrypted = $this->order_listener->decrypt_nip04( $encrypted_content, $sender_pubkey );

		if ( is_wp_error( $decrypted ) ) {
			return $decrypted;
		}

		// Parse the message as JSON.
		$message_data = json_decode( $decrypted, true );

		if ( null === $message_data ) {
			return new WP_Error( 'invalid_json', __( 'Decrypted message is not valid JSON.', 'woo-nostr-market' ) );
		}

		// Check message type.
		if ( ! isset( $message_data['type'] ) ) {
			return new WP_Error( 'missing_type', __( 'Message missing type field.', 'woo-nostr-market' ) );
		}

		$type = (int) $message_data['type'];

		switch ( $type ) {
			case 0:
				// New order.
				return $this->process_order( $message_data, $sender_pubkey, $event['id'] );

			case 1:
				// Payment request (we send these, shouldn't receive).
				return new WP_Error( 'unexpected_type', __( 'Received payment request (type 1), expected order.', 'woo-nostr-market' ) );

			case 2:
				// Order status (we send these, shouldn't receive).
				return new WP_Error( 'unexpected_type', __( 'Received order status (type 2), expected order.', 'woo-nostr-market' ) );

			default:
				// Unknown type - might be a regular chat message.
				return new WP_Error( 'unknown_type', sprintf( __( 'Unknown message type: %d', 'woo-nostr-market' ), $type ) );
		}
	}

	/**
	 * Process a new order.
	 *
	 * @param array  $order_data    Parsed order data.
	 * @param string $sender_pubkey Customer's pubkey.
	 * @param string $event_id      Original event ID.
	 * @return array|WP_Error Result with order IDs or error.
	 */
	private function process_order( $order_data, $sender_pubkey, $event_id ) {
		// Parse and validate order.
		$parsed = $this->order_listener->parse_order( wp_json_encode( $order_data ) );

		if ( is_wp_error( $parsed ) ) {
			return $parsed;
		}

		// Check for duplicate order (by nostr order ID).
		$existing = $this->find_existing_order( $order_data['id'] );
		if ( $existing ) {
			return new WP_Error(
				'duplicate_order',
				sprintf( __( 'Order %s already exists (WC #%d).', 'woo-nostr-market' ), $order_data['id'], $existing )
			);
		}

		// Create WooCommerce order.
		$wc_order = $this->order_listener->create_wc_order( $order_data, $sender_pubkey );

		if ( is_wp_error( $wc_order ) ) {
			return $wc_order;
		}

		// Store Nostr metadata on the order.
		$wc_order->update_meta_data( '_nostr_order_id', $order_data['id'] );
		$wc_order->update_meta_data( '_nostr_customer_pubkey', $sender_pubkey );
		$wc_order->update_meta_data( '_nostr_event_id', $event_id );
		$wc_order->save();

		// Send payment request to customer.
		$payment_result = $this->order_listener->send_payment_request( $wc_order, $sender_pubkey );

		if ( is_wp_error( $payment_result ) ) {
			// Order created but payment request failed - log but don't fail.
			$wc_order->add_order_note(
				sprintf( __( 'Failed to send Nostr payment request: %s', 'woo-nostr-market' ), $payment_result->get_error_message() )
			);
		} else {
			$wc_order->add_order_note( __( 'Nostr payment request sent to customer.', 'woo-nostr-market' ) );
		}

		return array(
			'order_id'    => $order_data['id'],
			'wc_order_id' => $wc_order->get_id(),
		);
	}

	/**
	 * Find existing WooCommerce order by Nostr order ID.
	 *
	 * @param string $nostr_order_id Nostr order ID.
	 * @return int|false WC order ID or false.
	 */
	private function find_existing_order( $nostr_order_id ) {
		$orders = wc_get_orders(
			array(
				'meta_key'   => '_nostr_order_id',
				'meta_value' => $nostr_order_id,
				'limit'      => 1,
				'return'     => 'ids',
			)
		);

		return ! empty( $orders ) ? $orders[0] : false;
	}

	/**
	 * Handle webhook test endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function handle_webhook_test( $request ) {
		$payload = $request->get_json_params();

		return new WP_REST_Response(
			array(
				'success' => true,
				'message' => __( 'Webhook endpoint is reachable.', 'woo-nostr-market' ),
				'test'    => isset( $payload['test'] ) ? $payload['test'] : null,
			),
			200
		);
	}

	/**
	 * Log incoming event (minimal - just ID and pubkey prefix).
	 *
	 * @param string $event_id Event ID.
	 * @param string $pubkey   Sender pubkey.
	 * @param string $relay    Relay URL.
	 */
	private function log_event( $event_id, $pubkey, $relay ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log(
				sprintf(
					'[WooNostrMarket] Received DM: event=%s from=%s relay=%s',
					substr( $event_id, 0, 16 ) . '...',
					substr( $pubkey, 0, 16 ) . '...',
					$relay
				)
			);
		}
	}

	/**
	 * Log processing error.
	 *
	 * @param string $event_id Event ID.
	 * @param string $error    Error message.
	 */
	private function log_error( $event_id, $error ) {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log(
				sprintf(
					'[WooNostrMarket] Error processing event %s: %s',
					substr( $event_id, 0, 16 ) . '...',
					$error
				)
			);
		}
	}
}
