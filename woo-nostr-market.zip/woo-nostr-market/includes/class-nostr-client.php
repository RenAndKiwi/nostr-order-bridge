<?php
/**
 * Nostr client class for event signing and relay publishing.
 *
 * @package WooNostrMarket
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WooNostrMarket_Nostr_Client
 *
 * Handles Nostr keypair generation, event signing, and relay publishing.
 * Uses `nak` CLI tool for signing operations (MVP approach).
 */
class WooNostrMarket_Nostr_Client {

	/**
	 * Settings instance.
	 *
	 * @var WooNostrMarket_Settings
	 */
	private $settings;

	/**
	 * Path to nak CLI.
	 *
	 * @var string
	 */
	private $nak_path = 'nak';

	/**
	 * Common nak paths to search.
	 *
	 * @var array
	 */
	private $nak_search_paths = array(
		'nak',
		'/usr/local/bin/nak',
		'/usr/bin/nak',
		'~/.local/bin/nak',
		'/home/*/go/bin/nak',
	);

	/**
	 * Constructor.
	 *
	 * @param WooNostrMarket_Settings $settings Settings instance.
	 */
	public function __construct( WooNostrMarket_Settings $settings ) {
		$this->settings = $settings;
	}

	/**
	 * Check if nak CLI is available.
	 *
	 * @return bool
	 */
	public function is_nak_available() {
		// First try the configured/found path.
		if ( $this->test_nak_path( $this->nak_path ) ) {
			return true;
		}

		// Search common locations.
		foreach ( $this->nak_search_paths as $path ) {
			// Expand home directory.
			$expanded_path = str_replace( '~', getenv( 'HOME' ) ?: '/root', $path );
			
			// Handle glob patterns.
			if ( strpos( $expanded_path, '*' ) !== false ) {
				$matches = glob( $expanded_path );
				foreach ( $matches as $match ) {
					if ( $this->test_nak_path( $match ) ) {
						$this->nak_path = $match;
						return true;
					}
				}
			} elseif ( $this->test_nak_path( $expanded_path ) ) {
				$this->nak_path = $expanded_path;
				return true;
			}
		}

		return false;
	}

	/**
	 * Test if a nak path is valid.
	 *
	 * @param string $path Path to test.
	 * @return bool
	 */
	private function test_nak_path( $path ) {
		if ( empty( $path ) ) {
			return false;
		}

		$output = array();
		$result = -1;
		exec( escapeshellcmd( $path ) . ' --version 2>&1', $output, $result ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

		return 0 === $result || ! empty( $output );
	}

	/**
	 * Generate a new Nostr keypair.
	 *
	 * @return array|WP_Error Array with 'private_key' and 'public_key' or WP_Error.
	 */
	public function generate_keypair() {
		// Try nak CLI first.
		if ( $this->is_nak_available() ) {
			return $this->generate_keypair_with_nak();
		}

		// Fallback to PHP-based generation.
		return $this->generate_keypair_php();
	}

	/**
	 * Generate keypair using nak CLI.
	 *
	 * @return array|WP_Error
	 */
	private function generate_keypair_with_nak() {
		$output = array();
		$result = -1;

		// Generate private key (nsec).
		exec( escapeshellcmd( $this->nak_path ) . ' key generate 2>&1', $output, $result ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

		if ( 0 !== $result || empty( $output[0] ) ) {
			return new WP_Error( 'key_generation_failed', __( 'Failed to generate private key with nak.', 'woo-nostr-market' ) );
		}

		$private_key_hex = trim( $output[0] );

		// Get public key from private key.
		$output = array();
		exec( 'echo ' . escapeshellarg( $private_key_hex ) . ' | ' . escapeshellcmd( $this->nak_path ) . ' key public 2>&1', $output, $result ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

		if ( 0 !== $result || empty( $output[0] ) ) {
			return new WP_Error( 'pubkey_derivation_failed', __( 'Failed to derive public key with nak.', 'woo-nostr-market' ) );
		}

		$public_key_hex = trim( $output[0] );

		return array(
			'private_key' => $private_key_hex,
			'public_key'  => $public_key_hex,
		);
	}

	/**
	 * Generate keypair using PHP (secp256k1 + random_bytes).
	 *
	 * @return array|WP_Error
	 */
	private function generate_keypair_php() {
		if ( ! WooNostrMarket_Secp256k1::is_available() ) {
			return new WP_Error(
				'no_crypto_available',
				__( 'Key generation requires php-gmp or nak CLI. Install: apt-get install php-gmp', 'woo-nostr-market' )
			);
		}

		// Generate a random 32-byte private key.
		$private_key_hex = bin2hex( random_bytes( 32 ) );

		// Derive public key using secp256k1.
		try {
			$ec             = new WooNostrMarket_Secp256k1();
			$public_key_hex = $ec->derive_public_key( $private_key_hex );
		} catch ( Exception $e ) {
			return new WP_Error( 'keygen_failed', $e->getMessage() );
		}

		return array(
			'private_key' => $private_key_hex,
			'public_key'  => $public_key_hex,
		);
	}

	/**
	 * Get public key from private key.
	 *
	 * Uses PHP-native secp256k1 (preferred) with nak CLI fallback.
	 *
	 * @param string $private_key Private key in hex format.
	 * @return string|WP_Error Public key hex or error.
	 */
	public function get_public_key( $private_key ) {
		// Try PHP-native first.
		if ( WooNostrMarket_Secp256k1::is_available() ) {
			try {
				$ec = new WooNostrMarket_Secp256k1();
				return $ec->derive_public_key( $private_key );
			} catch ( Exception $e ) {
				// Fall through to nak.
			}
		}

		// Fallback to nak CLI.
		if ( ! $this->is_nak_available() ) {
			return new WP_Error( 'key_ops_unavailable', __( 'Neither php-gmp nor nak CLI available for key derivation.', 'woo-nostr-market' ) );
		}

		$output = array();
		$result = -1;

		exec( 'echo ' . escapeshellarg( $private_key ) . ' | ' . escapeshellcmd( $this->nak_path ) . ' key public 2>&1', $output, $result ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

		if ( 0 !== $result || empty( $output[0] ) ) {
			return new WP_Error( 'pubkey_derivation_failed', __( 'Failed to derive public key.', 'woo-nostr-market' ) );
		}

		return trim( $output[0] );
	}

	/**
	 * Create a Nostr event structure (unsigned).
	 *
	 * @param int    $kind    Event kind.
	 * @param string $content Event content (JSON for NIP-15).
	 * @param array  $tags    Event tags.
	 * @return array Event structure.
	 */
	public function create_event( $kind, $content, $tags = array() ) {
		$pubkey = $this->settings->get_public_key();

		return array(
			'pubkey'     => $pubkey,
			'created_at' => time(),
			'kind'       => $kind,
			'tags'       => $tags,
			'content'    => $content,
		);
	}

	/**
	 * Sign an event.
	 *
	 * Uses PHP-native Schnorr signing (preferred) with nak CLI fallback.
	 *
	 * @param array $event Unsigned event.
	 * @return array|WP_Error Signed event with id, pubkey, sig, or error.
	 */
	public function sign_event( $event ) {
		$private_key = $this->settings->get_private_key();

		if ( empty( $private_key ) ) {
			return new WP_Error( 'no_private_key', __( 'No private key configured.', 'woo-nostr-market' ) );
		}

		// Try PHP-native Schnorr signing first.
		if ( WooNostrMarket_Secp256k1::is_available() ) {
			$result = $this->sign_event_php( $event, $private_key );
			if ( ! is_wp_error( $result ) ) {
				return $result;
			}
		}

		// Fallback to nak CLI.
		return $this->sign_event_nak( $event, $private_key );
	}

	/**
	 * Sign an event using PHP-native BIP-340 Schnorr signatures.
	 *
	 * @param array  $event       Unsigned event.
	 * @param string $private_key Hex private key.
	 * @return array|WP_Error Signed event or error.
	 */
	private function sign_event_php( $event, $private_key ) {
		try {
			$ec     = new WooNostrMarket_Secp256k1();
			$pubkey = $ec->derive_public_key( $private_key );

			// Compute event ID: SHA-256 of serialized [0, pubkey, created_at, kind, tags, content].
			$event_id = $ec->compute_event_id(
				$pubkey,
				$event['created_at'],
				$event['kind'],
				$event['tags'],
				$event['content']
			);

			// BIP-340 Schnorr sign the event ID.
			$sig = $ec->schnorr_sign( $event_id, $private_key );

			return array(
				'id'         => $event_id,
				'pubkey'     => $pubkey,
				'created_at' => $event['created_at'],
				'kind'       => $event['kind'],
				'tags'       => $event['tags'],
				'content'    => $event['content'],
				'sig'        => $sig,
			);
		} catch ( Exception $e ) {
			return new WP_Error( 'php_signing_failed', $e->getMessage() );
		}
	}

	/**
	 * Sign an event using nak CLI (fallback).
	 *
	 * @param array  $event       Unsigned event.
	 * @param string $private_key Hex private key.
	 * @return array|WP_Error Signed event or error.
	 */
	private function sign_event_nak( $event, $private_key ) {
		if ( ! $this->is_nak_available() ) {
			return new WP_Error( 'signing_unavailable', __( 'Neither php-gmp nor nak CLI available for event signing.', 'woo-nostr-market' ) );
		}

		$unsigned_json = wp_json_encode(
			array(
				'kind'       => $event['kind'],
				'created_at' => $event['created_at'],
				'tags'       => $event['tags'],
				'content'    => $event['content'],
			),
			JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE
		);

		$cmd = 'echo ' . escapeshellarg( $unsigned_json ) . ' | ' .
			escapeshellcmd( $this->nak_path ) . ' event --sec ' .
			escapeshellarg( $private_key ) . ' 2>&1';

		$output = array();
		$result = -1;

		exec( $cmd, $output, $result ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

		if ( 0 !== $result || empty( $output[0] ) ) {
			$error_msg = ! empty( $output ) ? implode( "\n", $output ) : 'Unknown error';
			return new WP_Error( 'signing_failed', sprintf( __( 'Failed to sign event: %s', 'woo-nostr-market' ), $error_msg ) );
		}

		$signed_event = json_decode( $output[0], true );

		if ( null === $signed_event || ! isset( $signed_event['id'] ) ) {
			return new WP_Error( 'invalid_signed_event', __( 'nak returned invalid event JSON.', 'woo-nostr-market' ) );
		}

		return $signed_event;
	}

	/**
	 * Publish an event to configured relays.
	 *
	 * @param array $event Signed event.
	 * @return array Results per relay.
	 */
	public function publish_event( $event ) {
		$relays  = $this->settings->get_relay_urls();
		$results = array();

		if ( empty( $relays ) ) {
			return array(
				'success' => false,
				'message' => __( 'No relays configured.', 'woo-nostr-market' ),
				'results' => array(),
			);
		}

		// Try nak first, then PHP stream sockets, then HTTP fallback.
		if ( $this->is_nak_available() ) {
			$results = $this->publish_with_nak( $event, $relays );
		} elseif ( function_exists( 'stream_socket_client' ) ) {
			$results = $this->publish_with_php_websocket( $event, $relays );
		} else {
			$results = $this->publish_with_http( $event, $relays );
		}

		$success_count = count( array_filter( $results, function( $r ) {
			return ! empty( $r['success'] );
		} ) );

		return array(
			'success' => $success_count > 0,
			'message' => sprintf(
				/* translators: %1$d: successful publishes, %2$d: total relays */
				__( 'Published to %1$d of %2$d relays.', 'woo-nostr-market' ),
				$success_count,
				count( $relays )
			),
			'results' => $results,
		);
	}

	/**
	 * Publish event using nak CLI.
	 *
	 * @param array $event  Signed event.
	 * @param array $relays Relay URLs.
	 * @return array Results per relay.
	 */
	private function publish_with_nak( $event, $relays ) {
		$results    = array();
		$event_json = wp_json_encode( $event );

		foreach ( $relays as $relay ) {
			$output = array();
			$result = -1;

			$cmd = 'echo ' . escapeshellarg( $event_json ) . ' | ' .
				escapeshellcmd( $this->nak_path ) . ' event ' .
				escapeshellarg( $relay ) . ' 2>&1';

			exec( $cmd, $output, $result ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

			$results[ $relay ] = array(
				'success' => 0 === $result,
				'output'  => implode( "\n", $output ),
			);
		}

		return $results;
	}

	/**
	 * Publish event using PHP stream sockets (WebSocket).
	 *
	 * Minimal WebSocket client — connects, sends EVENT, reads OK response.
	 * No external dependencies.
	 *
	 * @param array $event  Signed event.
	 * @param array $relays Relay URLs.
	 * @return array Results per relay.
	 */
	private function publish_with_php_websocket( $event, $relays ) {
		$results    = array();
		$event_msg  = wp_json_encode( array( 'EVENT', $event ), JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );

		foreach ( $relays as $relay ) {
			try {
				$results[ $relay ] = $this->ws_send_event( $relay, $event_msg );
			} catch ( Exception $e ) {
				$results[ $relay ] = array(
					'success' => false,
					'output'  => $e->getMessage(),
				);
			}
		}

		return $results;
	}

	/**
	 * Send a single event to a relay via WebSocket.
	 *
	 * @param string $relay_url Relay WebSocket URL (wss:// or ws://).
	 * @param string $message   JSON message to send.
	 * @return array Result with success and output.
	 */
	private function ws_send_event( $relay_url, $message ) {
		$parsed = wp_parse_url( $relay_url );
		$scheme = isset( $parsed['scheme'] ) ? $parsed['scheme'] : 'wss';
		$host   = isset( $parsed['host'] ) ? $parsed['host'] : '';
		$port   = isset( $parsed['port'] ) ? $parsed['port'] : ( 'wss' === $scheme ? 443 : 80 );
		$path   = isset( $parsed['path'] ) ? $parsed['path'] : '/';

		if ( empty( $host ) ) {
			return array( 'success' => false, 'output' => 'Invalid relay URL.' );
		}

		$use_ssl = ( 'wss' === $scheme );
		$address = ( $use_ssl ? 'ssl://' : 'tcp://' ) . $host . ':' . $port;

		$context = stream_context_create();
		if ( $use_ssl ) {
			stream_context_set_option( $context, 'ssl', 'verify_peer', true );
			stream_context_set_option( $context, 'ssl', 'verify_peer_name', true );
		}

		$socket = @stream_socket_client( $address, $errno, $errstr, 10, STREAM_CLIENT_CONNECT, $context );
		if ( ! $socket ) {
			return array( 'success' => false, 'output' => "Connection failed: $errstr ($errno)" );
		}

		stream_set_timeout( $socket, 10 );

		// WebSocket handshake.
		$ws_key    = base64_encode( random_bytes( 16 ) ); // phpcs:ignore
		$handshake = "GET $path HTTP/1.1\r\n" .
			"Host: $host\r\n" .
			"Upgrade: websocket\r\n" .
			"Connection: Upgrade\r\n" .
			"Sec-WebSocket-Key: $ws_key\r\n" .
			"Sec-WebSocket-Version: 13\r\n\r\n";

		fwrite( $socket, $handshake );

		// Read handshake response.
		$response = '';
		while ( ! feof( $socket ) ) {
			$line = fgets( $socket, 1024 );
			$response .= $line;
			if ( "\r\n" === $line || false === $line ) {
				break;
			}
		}

		if ( strpos( $response, '101' ) === false ) {
			fclose( $socket );
			return array( 'success' => false, 'output' => 'WebSocket handshake failed.' );
		}

		// Send the EVENT message as a WebSocket text frame.
		$this->ws_write_frame( $socket, $message );

		// Read response (expect ["OK", event_id, true/false, "message"]).
		$reply = $this->ws_read_frame( $socket, 8 );
		fclose( $socket );

		if ( ! empty( $reply ) ) {
			$data = json_decode( $reply, true );
			if ( is_array( $data ) && 'OK' === ( $data[0] ?? '' ) ) {
				return array(
					'success' => false !== ( $data[2] ?? false ),
					'output'  => $data[3] ?? 'OK',
				);
			}
		}

		// If we got here without an error, assume success (some relays don't respond).
		return array( 'success' => true, 'output' => 'Sent (no relay confirmation).' );
	}

	/**
	 * Write a WebSocket text frame.
	 *
	 * @param resource $socket  Socket resource.
	 * @param string   $payload Text payload.
	 */
	private function ws_write_frame( $socket, $payload ) {
		$len  = strlen( $payload );
		$mask = random_bytes( 4 );

		// Frame header: FIN + text opcode.
		$frame = chr( 0x81 ); // FIN=1, opcode=1 (text).

		if ( $len < 126 ) {
			$frame .= chr( $len | 0x80 ); // MASK bit set.
		} elseif ( $len < 65536 ) {
			$frame .= chr( 126 | 0x80 ) . pack( 'n', $len );
		} else {
			$frame .= chr( 127 | 0x80 ) . pack( 'J', $len );
		}

		$frame .= $mask;

		// Mask the payload.
		for ( $i = 0; $i < $len; $i++ ) {
			$frame .= chr( ord( $payload[ $i ] ) ^ ord( $mask[ $i % 4 ] ) );
		}

		fwrite( $socket, $frame );
	}

	/**
	 * Read a WebSocket frame (simplified — text frames only).
	 *
	 * @param resource $socket      Socket resource.
	 * @param int      $timeout_sec Read timeout.
	 * @return string|false Payload or false on failure.
	 */
	private function ws_read_frame( $socket, $timeout_sec = 8 ) {
		stream_set_timeout( $socket, $timeout_sec );

		$header = fread( $socket, 2 );
		if ( false === $header || strlen( $header ) < 2 ) {
			return false;
		}

		$len = ord( $header[1] ) & 0x7f;

		if ( 126 === $len ) {
			$ext = fread( $socket, 2 );
			$len = unpack( 'n', $ext )[1];
		} elseif ( 127 === $len ) {
			$ext = fread( $socket, 8 );
			$len = unpack( 'J', $ext )[1];
		}

		$payload = '';
		while ( strlen( $payload ) < $len ) {
			$chunk = fread( $socket, $len - strlen( $payload ) );
			if ( false === $chunk ) {
				break;
			}
			$payload .= $chunk;
		}

		return $payload;
	}

	/**
	 * Publish event using HTTP (for relays that support it).
	 * This is a fallback method - most relays require WebSocket.
	 *
	 * @param array $event  Signed event.
	 * @param array $relays Relay URLs.
	 * @return array Results per relay.
	 */
	private function publish_with_http( $event, $relays ) {
		$results = array();

		// Convert wss:// to https:// for HTTP-capable relays.
		foreach ( $relays as $relay ) {
			$http_url = str_replace( array( 'wss://', 'ws://' ), array( 'https://', 'http://' ), $relay );

			$response = wp_remote_post(
				$http_url,
				array(
					'headers' => array( 'Content-Type' => 'application/json' ),
					'body'    => wp_json_encode( array( 'EVENT', $event ) ),
					'timeout' => 10,
				)
			);

			$results[ $relay ] = array(
				'success' => ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) < 300,
				'output'  => is_wp_error( $response ) ? $response->get_error_message() : wp_remote_retrieve_body( $response ),
			);
		}

		return $results;
	}

	/**
	 * Create and publish an event in one call.
	 *
	 * @param int    $kind    Event kind.
	 * @param string $content Event content.
	 * @param array  $tags    Event tags.
	 * @return array|WP_Error Publish results or error.
	 */
	public function create_sign_and_publish( $kind, $content, $tags = array() ) {
		// Create event.
		$event = $this->create_event( $kind, $content, $tags );

		// Sign event.
		$signed = $this->sign_event( $event );
		if ( is_wp_error( $signed ) ) {
			return $signed;
		}

		// Publish event.
		return $this->publish_event( $signed );
	}

	/**
	 * Create a delete event (kind 5) for a previously published event.
	 *
	 * @param string $event_id Event ID to delete.
	 * @param int    $kind     Original event kind.
	 * @param string $reason   Deletion reason (optional).
	 * @return array|WP_Error Publish results or error.
	 */
	public function delete_event( $event_id, $kind, $reason = '' ) {
		$tags = array(
			array( 'e', $event_id ),
			array( 'k', (string) $kind ),
		);

		return $this->create_sign_and_publish( 5, $reason, $tags );
	}

	/**
	 * Convert nsec (bech32) to hex private key.
	 *
	 * @param string $nsec Nostr secret key in bech32 format.
	 * @return string|WP_Error Hex private key or error.
	 */
	public function nsec_to_hex( $nsec ) {
		// Try nak first.
		if ( $this->is_nak_available() ) {
			$output = array();
			$result = -1;
			exec( 'echo ' . escapeshellarg( $nsec ) . ' | ' . escapeshellcmd( $this->nak_path ) . ' decode 2>&1', $output, $result ); // phpcs:ignore
			if ( 0 === $result && ! empty( $output[0] ) ) {
				return trim( $output[0] );
			}
		}

		// Pure PHP bech32 decode fallback.
		return $this->bech32_decode_to_hex( $nsec, 'nsec' );
	}

	/**
	 * Decode a bech32-encoded Nostr key (nsec/npub) to hex.
	 *
	 * @param string $bech32 Bech32-encoded string.
	 * @param string $expected_hrp Expected human-readable prefix.
	 * @return string|WP_Error Hex string or error.
	 */
	private function bech32_decode_to_hex( $bech32, $expected_hrp = '' ) {
		$charset = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';

		// Split HRP and data.
		$pos = strrpos( $bech32, '1' );
		if ( false === $pos || $pos < 1 ) {
			return new WP_Error( 'decode_failed', __( 'Invalid bech32 format.', 'woo-nostr-market' ) );
		}

		$hrp  = substr( $bech32, 0, $pos );
		$data = substr( $bech32, $pos + 1 );

		if ( ! empty( $expected_hrp ) && $hrp !== $expected_hrp ) {
			return new WP_Error( 'wrong_prefix', sprintf( __( 'Expected prefix %s, got %s.', 'woo-nostr-market' ), $expected_hrp, $hrp ) );
		}

		// Decode characters to 5-bit values.
		$values = array();
		for ( $i = 0; $i < strlen( $data ); $i++ ) {
			$v = strpos( $charset, $data[ $i ] );
			if ( false === $v ) {
				return new WP_Error( 'decode_failed', __( 'Invalid bech32 character.', 'woo-nostr-market' ) );
			}
			$values[] = $v;
		}

		// Remove 6-byte checksum.
		$values = array_slice( $values, 0, -6 );

		// Convert 5-bit to 8-bit.
		$acc    = 0;
		$bits   = 0;
		$bytes  = array();
		foreach ( $values as $v ) {
			$acc = ( $acc << 5 ) | $v;
			$bits += 5;
			while ( $bits >= 8 ) {
				$bits -= 8;
				$bytes[] = ( $acc >> $bits ) & 0xff;
			}
		}

		// Convert to hex.
		$hex = '';
		foreach ( $bytes as $byte ) {
			$hex .= str_pad( dechex( $byte ), 2, '0', STR_PAD_LEFT );
		}

		if ( 64 !== strlen( $hex ) ) {
			return new WP_Error( 'decode_failed', sprintf( __( 'Decoded key has wrong length (%d, expected 64).', 'woo-nostr-market' ), strlen( $hex ) ) );
		}

		return $hex;
	}

	/**
	 * Convert hex private key to nsec (bech32).
	 *
	 * Uses PHP-native bech32 encoding (preferred) with nak CLI fallback.
	 *
	 * @param string $hex Hex private key.
	 * @return string|WP_Error nsec key or error.
	 */
	public function hex_to_nsec( $hex ) {
		// Try PHP-native first.
		$result = $this->bech32_encode_key( 'nsec', $hex );
		if ( ! is_wp_error( $result ) ) {
			return $result;
		}

		// Fallback to nak CLI.
		if ( ! $this->is_nak_available() ) {
			return new WP_Error( 'encode_unavailable', __( 'Cannot encode nsec: no native support or nak CLI.', 'woo-nostr-market' ) );
		}

		$output = array();
		$ret    = -1;

		exec( escapeshellcmd( $this->nak_path ) . ' encode nsec ' . escapeshellarg( $hex ) . ' 2>&1', $output, $ret ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

		if ( 0 !== $ret || empty( $output[0] ) ) {
			return new WP_Error( 'encode_failed', __( 'Failed to encode to nsec.', 'woo-nostr-market' ) );
		}

		return trim( $output[0] );
	}

	/**
	 * Encode a 32-byte hex key as bech32 (npub/nsec).
	 *
	 * Pure PHP implementation — no external dependencies.
	 *
	 * @param string $hrp Human-readable prefix ('npub' or 'nsec').
	 * @param string $hex 64-character hex string.
	 * @return string|WP_Error Bech32-encoded string or error.
	 */
	private function bech32_encode_key( $hrp, $hex ) {
		if ( 64 !== strlen( $hex ) || ! ctype_xdigit( $hex ) ) {
			return new WP_Error( 'invalid_hex', __( 'Invalid hex key for bech32 encoding.', 'woo-nostr-market' ) );
		}

		$charset = 'qpzry9x8gf2tvdw0s3jn54khce6mua7l';

		// Convert hex to bytes.
		$bytes = array_values( unpack( 'C*', hex2bin( $hex ) ) );

		// Convert 8-bit bytes to 5-bit values.
		$values = array();
		$acc    = 0;
		$bits   = 0;
		foreach ( $bytes as $byte ) {
			$acc   = ( $acc << 8 ) | $byte;
			$bits += 8;
			while ( $bits >= 5 ) {
				$bits    -= 5;
				$values[] = ( $acc >> $bits ) & 31;
			}
		}
		if ( $bits > 0 ) {
			$values[] = ( $acc << ( 5 - $bits ) ) & 31;
		}

		// Compute checksum.
		$checksum = $this->bech32_create_checksum( $hrp, $values );
		$all      = array_merge( $values, $checksum );

		// Encode to bech32 string.
		$result = $hrp . '1';
		foreach ( $all as $v ) {
			$result .= $charset[ $v ];
		}

		return $result;
	}

	/**
	 * Create bech32 checksum.
	 *
	 * @param string $hrp    Human-readable prefix.
	 * @param array  $data   5-bit data values.
	 * @return array 6-element checksum array.
	 */
	private function bech32_create_checksum( $hrp, $data ) {
		$values  = array_merge( $this->bech32_hrp_expand( $hrp ), $data, array( 0, 0, 0, 0, 0, 0 ) );
		$polymod = $this->bech32_polymod( $values ) ^ 1;
		$result  = array();
		for ( $i = 0; $i < 6; $i++ ) {
			$result[] = ( $polymod >> ( 5 * ( 5 - $i ) ) ) & 31;
		}
		return $result;
	}

	/**
	 * Expand HRP for checksum computation.
	 *
	 * @param string $hrp Human-readable prefix.
	 * @return array Expanded values.
	 */
	private function bech32_hrp_expand( $hrp ) {
		$expand = array();
		$len    = strlen( $hrp );
		for ( $i = 0; $i < $len; $i++ ) {
			$expand[] = ord( $hrp[ $i ] ) >> 5;
		}
		$expand[] = 0;
		for ( $i = 0; $i < $len; $i++ ) {
			$expand[] = ord( $hrp[ $i ] ) & 31;
		}
		return $expand;
	}

	/**
	 * Bech32 polymod checksum function.
	 *
	 * @param array $values Input values.
	 * @return int Polymod result.
	 */
	private function bech32_polymod( $values ) {
		$gen = array( 0x3b6a57b2, 0x26508e6d, 0x1ea119fa, 0x3d4233dd, 0x2a1462b3 );
		$chk = 1;
		foreach ( $values as $v ) {
			$b   = $chk >> 25;
			$chk = ( ( $chk & 0x1ffffff ) << 5 ) ^ $v;
			for ( $i = 0; $i < 5; $i++ ) {
				$chk ^= ( ( $b >> $i ) & 1 ) ? $gen[ $i ] : 0;
			}
		}
		return $chk;
	}

	/**
	 * Convert hex public key to npub (bech32).
	 *
	 * Uses PHP-native bech32 encoding (preferred) with nak CLI fallback.
	 *
	 * @param string $hex Hex public key.
	 * @return string|WP_Error npub key or error.
	 */
	public function hex_to_npub( $hex ) {
		// Try PHP-native first.
		$result = $this->bech32_encode_key( 'npub', $hex );
		if ( ! is_wp_error( $result ) ) {
			return $result;
		}

		// Fallback to nak CLI.
		if ( ! $this->is_nak_available() ) {
			return new WP_Error( 'encode_unavailable', __( 'Cannot encode npub: no native support or nak CLI.', 'woo-nostr-market' ) );
		}

		$output = array();
		$ret    = -1;

		exec( escapeshellcmd( $this->nak_path ) . ' encode npub ' . escapeshellarg( $hex ) . ' 2>&1', $output, $ret ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

		if ( 0 !== $ret || empty( $output[0] ) ) {
			return new WP_Error( 'encode_failed', __( 'Failed to encode to npub.', 'woo-nostr-market' ) );
		}

		return trim( $output[0] );
	}
}
