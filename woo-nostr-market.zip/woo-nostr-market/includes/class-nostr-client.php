<?php
/**
 * Nostr client class for event signing and relay publishing.
 *
 * @package WooNostrMarket
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WooNostrMarket_Nostr_Client
 *
 * Handles Nostr keypair generation, event signing, and relay publishing.
 * Uses `nak` CLI tool for signing operations (MVP approach).
 */
class WooNostrMarket_Nostr_Client {

	/**
	 * Settings instance.
	 *
	 * @var WooNostrMarket_Settings
	 */
	private $settings;

	/**
	 * Path to nak CLI.
	 *
	 * @var string
	 */
	private $nak_path = 'nak';

	/**
	 * Common nak paths to search.
	 *
	 * @var array
	 */
	private $nak_search_paths = array(
		'nak',
		'/usr/local/bin/nak',
		'/usr/bin/nak',
		'~/.local/bin/nak',
		'/home/*/go/bin/nak',
	);

	/**
	 * Constructor.
	 *
	 * @param WooNostrMarket_Settings $settings Settings instance.
	 */
	public function __construct( WooNostrMarket_Settings $settings ) {
		$this->settings = $settings;
	}

	/**
	 * Check if nak CLI is available.
	 *
	 * @return bool
	 */
	public function is_nak_available() {
		// First try the configured/found path.
		if ( $this->test_nak_path( $this->nak_path ) ) {
			return true;
		}

		// Search common locations.
		foreach ( $this->nak_search_paths as $path ) {
			// Expand home directory.
			$expanded_path = str_replace( '~', getenv( 'HOME' ) ?: '/root', $path );
			
			// Handle glob patterns.
			if ( strpos( $expanded_path, '*' ) !== false ) {
				$matches = glob( $expanded_path );
				foreach ( $matches as $match ) {
					if ( $this->test_nak_path( $match ) ) {
						$this->nak_path = $match;
						return true;
					}
				}
			} elseif ( $this->test_nak_path( $expanded_path ) ) {
				$this->nak_path = $expanded_path;
				return true;
			}
		}

		return false;
	}

	/**
	 * Test if a nak path is valid.
	 *
	 * @param string $path Path to test.
	 * @return bool
	 */
	private function test_nak_path( $path ) {
		if ( empty( $path ) ) {
			return false;
		}

		$output = array();
		$result = -1;
		exec( escapeshellcmd( $path ) . ' --version 2>&1', $output, $result ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

		return 0 === $result || ! empty( $output );
	}

	/**
	 * Generate a new Nostr keypair.
	 *
	 * @return array|WP_Error Array with 'private_key' and 'public_key' or WP_Error.
	 */
	public function generate_keypair() {
		// Try nak CLI first.
		if ( $this->is_nak_available() ) {
			return $this->generate_keypair_with_nak();
		}

		// Fallback to PHP-based generation.
		return $this->generate_keypair_php();
	}

	/**
	 * Generate keypair using nak CLI.
	 *
	 * @return array|WP_Error
	 */
	private function generate_keypair_with_nak() {
		$output = array();
		$result = -1;

		// Generate private key (nsec).
		exec( escapeshellcmd( $this->nak_path ) . ' key generate 2>&1', $output, $result ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

		if ( 0 !== $result || empty( $output[0] ) ) {
			return new WP_Error( 'key_generation_failed', __( 'Failed to generate private key with nak.', 'woo-nostr-market' ) );
		}

		$private_key_hex = trim( $output[0] );

		// Get public key from private key.
		$output = array();
		exec( 'echo ' . escapeshellarg( $private_key_hex ) . ' | ' . escapeshellcmd( $this->nak_path ) . ' key public 2>&1', $output, $result ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

		if ( 0 !== $result || empty( $output[0] ) ) {
			return new WP_Error( 'pubkey_derivation_failed', __( 'Failed to derive public key with nak.', 'woo-nostr-market' ) );
		}

		$public_key_hex = trim( $output[0] );

		return array(
			'private_key' => $private_key_hex,
			'public_key'  => $public_key_hex,
		);
	}

	/**
	 * Generate keypair using PHP (requires secp256k1 extension or external library).
	 *
	 * @return array|WP_Error
	 */
	private function generate_keypair_php() {
		// Check for OpenSSL.
		if ( ! function_exists( 'openssl_pkey_new' ) ) {
			return new WP_Error(
				'no_crypto_available',
				__( 'Neither nak CLI nor OpenSSL is available for key generation.', 'woo-nostr-market' )
			);
		}

		// Generate a random 32-byte private key.
		$private_key_bytes = random_bytes( 32 );
		$private_key_hex   = bin2hex( $private_key_bytes );

		// Note: Proper public key derivation requires secp256k1 curve operations.
		// For MVP without external libraries, we recommend installing nak CLI.
		// This is a placeholder that indicates the limitation.
		return new WP_Error(
			'php_keygen_unsupported',
			__( 'PHP key generation requires the nak CLI tool. Please install it: go install github.com/fiatjaf/nak@latest', 'woo-nostr-market' )
		);
	}

	/**
	 * Get public key from private key.
	 *
	 * @param string $private_key Private key in hex format.
	 * @return string|WP_Error Public key hex or error.
	 */
	public function get_public_key( $private_key ) {
		if ( ! $this->is_nak_available() ) {
			return new WP_Error( 'nak_unavailable', __( 'nak CLI is required for key operations.', 'woo-nostr-market' ) );
		}

		$output = array();
		$result = -1;

		exec( 'echo ' . escapeshellarg( $private_key ) . ' | ' . escapeshellcmd( $this->nak_path ) . ' key public 2>&1', $output, $result ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

		if ( 0 !== $result || empty( $output[0] ) ) {
			return new WP_Error( 'pubkey_derivation_failed', __( 'Failed to derive public key.', 'woo-nostr-market' ) );
		}

		return trim( $output[0] );
	}

	/**
	 * Create a Nostr event structure (unsigned).
	 *
	 * @param int    $kind    Event kind.
	 * @param string $content Event content (JSON for NIP-15).
	 * @param array  $tags    Event tags.
	 * @return array Event structure.
	 */
	public function create_event( $kind, $content, $tags = array() ) {
		$pubkey = $this->settings->get_public_key();

		return array(
			'pubkey'     => $pubkey,
			'created_at' => time(),
			'kind'       => $kind,
			'tags'       => $tags,
			'content'    => $content,
		);
	}

	/**
	 * Sign an event using nak CLI.
	 *
	 * @param array $event Unsigned event.
	 * @return array|WP_Error Signed event with id and sig, or error.
	 */
	public function sign_event( $event ) {
		$private_key = $this->settings->get_private_key();

		if ( empty( $private_key ) ) {
			return new WP_Error( 'no_private_key', __( 'No private key configured.', 'woo-nostr-market' ) );
		}

		if ( ! $this->is_nak_available() ) {
			return new WP_Error( 'nak_unavailable', __( 'nak CLI is required for signing.', 'woo-nostr-market' ) );
		}

		// Build nak event command.
		$cmd_parts = array(
			escapeshellcmd( $this->nak_path ),
			'event',
			'--sec',
			escapeshellarg( $private_key ),
			'-k',
			escapeshellarg( (string) $event['kind'] ),
			'-c',
			escapeshellarg( $event['content'] ),
		);

		// Add tags.
		foreach ( $event['tags'] as $tag ) {
			$tag_str     = implode( ':', $tag );
			$cmd_parts[] = '-t';
			$cmd_parts[] = escapeshellarg( $tag_str );
		}

		$cmd    = implode( ' ', $cmd_parts ) . ' 2>&1';
		$output = array();
		$result = -1;

		exec( $cmd, $output, $result ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

		if ( 0 !== $result || empty( $output[0] ) ) {
			$error_msg = ! empty( $output ) ? implode( "\n", $output ) : 'Unknown error';
			return new WP_Error( 'signing_failed', sprintf( __( 'Failed to sign event: %s', 'woo-nostr-market' ), $error_msg ) );
		}

		// Parse the JSON output from nak.
		$signed_event = json_decode( $output[0], true );

		if ( null === $signed_event || ! isset( $signed_event['id'] ) ) {
			return new WP_Error( 'invalid_signed_event', __( 'nak returned invalid event JSON.', 'woo-nostr-market' ) );
		}

		return $signed_event;
	}

	/**
	 * Publish an event to configured relays.
	 *
	 * @param array $event Signed event.
	 * @return array Results per relay.
	 */
	public function publish_event( $event ) {
		$relays  = $this->settings->get_relay_urls();
		$results = array();

		if ( empty( $relays ) ) {
			return array(
				'success' => false,
				'message' => __( 'No relays configured.', 'woo-nostr-market' ),
				'results' => array(),
			);
		}

		// Use nak to publish to relays.
		if ( $this->is_nak_available() ) {
			$results = $this->publish_with_nak( $event, $relays );
		} else {
			// Fallback: try WebSocket publish (requires additional implementation).
			$results = $this->publish_with_http( $event, $relays );
		}

		$success_count = count( array_filter( $results, function( $r ) {
			return ! empty( $r['success'] );
		} ) );

		return array(
			'success' => $success_count > 0,
			'message' => sprintf(
				/* translators: %1$d: successful publishes, %2$d: total relays */
				__( 'Published to %1$d of %2$d relays.', 'woo-nostr-market' ),
				$success_count,
				count( $relays )
			),
			'results' => $results,
		);
	}

	/**
	 * Publish event using nak CLI.
	 *
	 * @param array $event  Signed event.
	 * @param array $relays Relay URLs.
	 * @return array Results per relay.
	 */
	private function publish_with_nak( $event, $relays ) {
		$results    = array();
		$event_json = wp_json_encode( $event );

		foreach ( $relays as $relay ) {
			$output = array();
			$result = -1;

			$cmd = 'echo ' . escapeshellarg( $event_json ) . ' | ' .
				escapeshellcmd( $this->nak_path ) . ' event ' .
				escapeshellarg( $relay ) . ' 2>&1';

			exec( $cmd, $output, $result ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

			$results[ $relay ] = array(
				'success' => 0 === $result,
				'output'  => implode( "\n", $output ),
			);
		}

		return $results;
	}

	/**
	 * Publish event using HTTP (for relays that support it).
	 * This is a fallback method - most relays require WebSocket.
	 *
	 * @param array $event  Signed event.
	 * @param array $relays Relay URLs.
	 * @return array Results per relay.
	 */
	private function publish_with_http( $event, $relays ) {
		$results = array();

		// Convert wss:// to https:// for HTTP-capable relays.
		foreach ( $relays as $relay ) {
			$http_url = str_replace( array( 'wss://', 'ws://' ), array( 'https://', 'http://' ), $relay );

			$response = wp_remote_post(
				$http_url,
				array(
					'headers' => array( 'Content-Type' => 'application/json' ),
					'body'    => wp_json_encode( array( 'EVENT', $event ) ),
					'timeout' => 10,
				)
			);

			$results[ $relay ] = array(
				'success' => ! is_wp_error( $response ) && wp_remote_retrieve_response_code( $response ) < 300,
				'output'  => is_wp_error( $response ) ? $response->get_error_message() : wp_remote_retrieve_body( $response ),
			);
		}

		return $results;
	}

	/**
	 * Create and publish an event in one call.
	 *
	 * @param int    $kind    Event kind.
	 * @param string $content Event content.
	 * @param array  $tags    Event tags.
	 * @return array|WP_Error Publish results or error.
	 */
	public function create_sign_and_publish( $kind, $content, $tags = array() ) {
		// Create event.
		$event = $this->create_event( $kind, $content, $tags );

		// Sign event.
		$signed = $this->sign_event( $event );
		if ( is_wp_error( $signed ) ) {
			return $signed;
		}

		// Publish event.
		return $this->publish_event( $signed );
	}

	/**
	 * Create a delete event (kind 5) for a previously published event.
	 *
	 * @param string $event_id Event ID to delete.
	 * @param int    $kind     Original event kind.
	 * @param string $reason   Deletion reason (optional).
	 * @return array|WP_Error Publish results or error.
	 */
	public function delete_event( $event_id, $kind, $reason = '' ) {
		$tags = array(
			array( 'e', $event_id ),
			array( 'k', (string) $kind ),
		);

		return $this->create_sign_and_publish( 5, $reason, $tags );
	}

	/**
	 * Convert nsec (bech32) to hex private key.
	 *
	 * @param string $nsec Nostr secret key in bech32 format.
	 * @return string|WP_Error Hex private key or error.
	 */
	public function nsec_to_hex( $nsec ) {
		if ( ! $this->is_nak_available() ) {
			return new WP_Error( 'nak_unavailable', __( 'nak CLI is required for key conversion.', 'woo-nostr-market' ) );
		}

		$output = array();
		$result = -1;

		exec( 'echo ' . escapeshellarg( $nsec ) . ' | ' . escapeshellcmd( $this->nak_path ) . ' decode 2>&1', $output, $result ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

		if ( 0 !== $result || empty( $output[0] ) ) {
			return new WP_Error( 'decode_failed', __( 'Failed to decode nsec key.', 'woo-nostr-market' ) );
		}

		return trim( $output[0] );
	}

	/**
	 * Convert hex private key to nsec (bech32).
	 *
	 * @param string $hex Hex private key.
	 * @return string|WP_Error nsec key or error.
	 */
	public function hex_to_nsec( $hex ) {
		if ( ! $this->is_nak_available() ) {
			return new WP_Error( 'nak_unavailable', __( 'nak CLI is required for key conversion.', 'woo-nostr-market' ) );
		}

		$output = array();
		$result = -1;

		exec( escapeshellcmd( $this->nak_path ) . ' encode nsec ' . escapeshellarg( $hex ) . ' 2>&1', $output, $result ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

		if ( 0 !== $result || empty( $output[0] ) ) {
			return new WP_Error( 'encode_failed', __( 'Failed to encode to nsec.', 'woo-nostr-market' ) );
		}

		return trim( $output[0] );
	}

	/**
	 * Convert hex public key to npub (bech32).
	 *
	 * @param string $hex Hex public key.
	 * @return string|WP_Error npub key or error.
	 */
	public function hex_to_npub( $hex ) {
		if ( ! $this->is_nak_available() ) {
			return new WP_Error( 'nak_unavailable', __( 'nak CLI is required for key conversion.', 'woo-nostr-market' ) );
		}

		$output = array();
		$result = -1;

		exec( escapeshellcmd( $this->nak_path ) . ' encode npub ' . escapeshellarg( $hex ) . ' 2>&1', $output, $result ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

		if ( 0 !== $result || empty( $output[0] ) ) {
			return new WP_Error( 'encode_failed', __( 'Failed to encode to npub.', 'woo-nostr-market' ) );
		}

		return trim( $output[0] );
	}
}
