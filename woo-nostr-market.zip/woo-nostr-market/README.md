# WooCommerce Nostr Market

Sync your WooCommerce products to the Nostr decentralized marketplace ecosystem using NIP-15.

## Overview

This plugin bridges WooCommerce stores with the Nostr protocol, allowing merchants to publish their products as NIP-15 marketplace listings. Products become discoverable on any NIP-15 compatible marketplace client (Plebeian Market, Shopstr, etc.).

### Features

- **Stall Creation** - Automatically creates a NIP-15 stall (kind:30017) from your WooCommerce store settings
- **Product Sync** - Publishes products as NIP-15 events (kind:30018) when created or updated
- **Auto-Delete** - Publishes deletion events (kind:5) when products are trashed or deleted
- **Multi-Relay** - Publish to multiple Nostr relays for redundancy
- **Encrypted Keys** - Private keys are encrypted using WordPress salts

## Requirements

- WordPress 6.0+
- WooCommerce 7.0+
- PHP 7.4+
- **nak CLI** - Required for Nostr key management and event signing

### Installing nak CLI

The plugin uses the `nak` CLI tool for Nostr operations. Install it with:

```bash
# Using Go
go install github.com/fiatjaf/nak@latest

# Make sure it's in your PATH
# For most setups, add to .bashrc/.zshrc:
export PATH=$PATH:$(go env GOPATH)/bin
```

Verify installation:
```bash
nak --version
```

> **Note:** The `nak` binary must be accessible to the PHP process running WordPress. On shared hosting, you may need to install it to a directory in the web server's PATH or configure the full path in the plugin.

## Installation

1. Download the plugin zip or clone to `/wp-content/plugins/woo-nostr-market/`
2. Activate the plugin via WordPress admin
3. Navigate to **WooCommerce → Nostr Market**
4. Generate or import your Nostr keys
5. Configure relay URLs
6. Publish your stall
7. Sync your products

## Configuration

### 1. Nostr Keys

You need a Nostr keypair to publish events. You can:

- **Generate new keys** - Click "Generate New Keys" to create a fresh keypair
- **Import existing key** - Enter your `nsec` or hex private key to use an existing identity

⚠️ **Important:** Your private key is encrypted and stored in WordPress. Keep a backup!

### 2. Relay URLs

Configure which Nostr relays to publish to. Default relays:
- `wss://relay.damus.io`
- `wss://nos.lol`
- `wss://relay.nostr.band`

Add one relay URL per line. More relays = better discoverability but slower publishing.

### 3. BTCPay Server (Phase 2)

For accepting Lightning payments on Nostr orders:
- Enter your BTCPay Server URL
- Add your API key

This is optional for Phase 1 (product publishing only).

## Usage

### Publishing Your Stall

Click **"Publish/Update Stall"** to create or update your store listing on Nostr. The stall includes:
- Store name (from WordPress General Settings)
- Description (from WordPress tagline)
- Currency (from WooCommerce settings)
- Shipping zones (from WooCommerce shipping settings)

### Syncing Products

Products are automatically synced when:
- A product is published or updated
- Stock quantity changes
- A product is trashed or deleted (publishes delete event)

To sync all existing products, click **"Sync All Products"**.

### What Gets Published

Each product publishes:
- Product ID, name, description
- Price and currency
- Stock quantity
- Images (featured + gallery)
- SKU, weight, dimensions
- Product attributes as specs
- Categories as tags

## NIP-15 Event Format

### Stall (kind:30017)

```json
{
  "id": "unique-stall-uuid",
  "name": "My Store",
  "description": "Store tagline",
  "currency": "usd",
  "shipping": [
    {
      "id": "zone_1",
      "name": "US Shipping",
      "cost": 5.99,
      "regions": ["US"]
    }
  ]
}
```

### Product (kind:30018)

```json
{
  "id": "123",
  "stall_id": "unique-stall-uuid",
  "name": "Product Name",
  "description": "Product description",
  "images": ["https://..."],
  "currency": "usd",
  "price": 29.99,
  "quantity": 100,
  "specs": [
    ["sku", "ABC123"],
    ["weight", "1.5 kg"]
  ]
}
```

## Troubleshooting

### "nak CLI not found"

Ensure `nak` is installed and accessible to the PHP process:
```bash
which nak
# Should output the path, e.g., /usr/local/go/bin/nak
```

If PHP can't find it, the web server's PATH may differ from your shell. Try:
- Adding nak to `/usr/local/bin/`
- Or configuring the full path in the plugin (future enhancement)

### Products not appearing on marketplaces

1. Verify your stall is published (check status panel)
2. Ensure products are synced (check pending count)
3. Confirm relays are accessible
4. Try publishing to `wss://relay.nostr.band` - it indexes marketplace events

### Keys not working

If you imported a key and it's not working:
1. Verify the format (64-char hex or nsec1...)
2. Try generating fresh keys to test
3. Check WordPress error logs for decryption issues

## Development

### Hooks

```php
// Before product sync
do_action( 'woo_nostr_market_before_product_sync', $product_id );

// After product sync
do_action( 'woo_nostr_market_after_product_sync', $product_id, $result );

// Filter product data before publishing
$data = apply_filters( 'woo_nostr_market_product_data', $data, $product_id );
```

### File Structure

```
woo-nostr-market/
├── woo-nostr-market.php       # Main plugin file
├── includes/
│   ├── class-nostr-client.php     # Nostr signing & publishing
│   ├── class-stall-manager.php    # Stall event creation
│   ├── class-product-sync.php     # Product → NIP-15 mapping
│   ├── class-order-listener.php   # Order receiving (Phase 2)
│   └── class-settings.php         # Settings management
├── admin/
│   ├── class-admin-page.php       # Admin UI
│   └── views/
│       └── settings-page.php      # Settings form
└── assets/
    └── css/
        └── admin.css              # Admin styles
```

## Order Receiving (Phase 2)

### How NIP-15 Orders Work

1. Customer finds your product on any NIP-15 marketplace (Shopstr, Plebeian Market, etc.)
2. Customer sends encrypted order via Nostr DM (NIP-04, kind:4) to your merchant pubkey
3. You receive the order, send a Lightning invoice back
4. Customer pays, you fulfill

### The Challenge

WordPress is request/response — it can't maintain persistent WebSocket connections to Nostr relays. To receive orders in real-time, you need an **external listener service**.

### Recommended Setup: nostr-order-listener

We provide a companion service that runs on a VPS and forwards orders to your WordPress:

**[nostr-order-listener](https://github.com/RenAndKiwi/nostr-order-listener)** — Lightweight Node.js service that:
- Subscribes to Nostr relays for your merchant pubkey
- Receives and decrypts incoming order DMs
- Forwards orders to your WordPress webhook endpoint
- **Does NOT handle payments** — your BTCPay Server does that
- **Does NOT log sensitive data** — orders go straight to your WP

```
┌─────────────────────────────────────────────────────────┐
│           nostr-order-listener (shared VPS)              │
│  Subscribes to relays → forwards orders to merchants     │
└─────────────────────────────────────────────────────────┘
                    │
         ┌──────────┴──────────┐
         ▼                     ▼
┌─────────────────┐    ┌─────────────────┐
│  Your WP Store  │    │  Other Merchant │
│  + This Plugin  │    │  + This Plugin  │
│  + BTCPay       │    │  + BTCPay       │
└─────────────────┘    └─────────────────┘
```

You can:
- **Self-host** the listener on your own VPS
- **Use a shared instance** (coming soon)
- **Run locally** for testing

See the [nostr-order-listener README](https://github.com/RenAndKiwi/nostr-order-listener) for setup instructions.

### Alternative: Manual Order Checking

If you don't want to run the listener service, you can:
1. Keep your WordPress admin open with the "Order Inbox" tab
2. The plugin will poll for new orders while the page is open
3. Less reliable, but works for low-volume stores

## Roadmap

### Phase 1 (Current) ✅
- [x] Plugin skeleton
- [x] Key management (encrypted storage)
- [x] Stall publishing
- [x] Product sync
- [x] Delete events
- [x] Admin UI

### Phase 2 (In Progress)
- [x] Webhook endpoint for order listener
- [ ] NIP-04 order receiving via listener
- [ ] WooCommerce order creation from Nostr
- [ ] BTCPay Lightning invoices
- [ ] Payment request messages
- [ ] Order status updates

### Phase 3 (Future)
- [ ] Variable product variations
- [ ] Real-time WebSocket sync
- [ ] Order inbox in admin (browser polling fallback)
- [ ] Webhook triggers
- [ ] REST API

## TODO / Security Enhancements

### 🔐 Browser Signing (NIP-07)
Currently, the plugin stores the nsec (private key) encrypted in WordPress. A more secure approach for the future:

- [ ] **NIP-07 Browser Extension Support** — Allow signing via browser extensions (nos2x, Alby, etc.)
  - Admin triggers "Publish" from WordPress
  - Plugin generates unsigned event
  - Redirects to NIP-07 signing flow in browser
  - Extension signs event, returns to WordPress
  - Plugin publishes signed event to relays
  
  **Benefits:**
  - Private key never touches the server
  - Works with hardware wallets (via extension)
  - User maintains full key custody

- [ ] **External Signing Service** — For headless/automated publishing:
  - Signing service runs on trusted local machine
  - WordPress sends unsigned events via secure channel
  - Service signs and returns
  - No nsec stored on web server

### 🔒 Additional Security TODOs
- [ ] File-based key storage (outside database)
- [ ] Key rotation with automatic republish
- [ ] Audit logging for all signing operations
- [ ] Rate limiting on publish operations
- [ ] Webhook signature verification for BTCPay

## Resources

- [NIP-15 Specification](https://github.com/nostr-protocol/nips/blob/master/15.md)
- [nak CLI](https://github.com/fiatjaf/nak)
- [Plebeian Market](https://plebeian.market)
- [Shopstr](https://shopstr.store)

## License

GPL v2 or later
