<?php
/**
 * Admin settings page view.
 *
 * @package WooNostrMarket
 */

defined( 'ABSPATH' ) || exit;

$signing_mode = $this->settings->get( 'signing_mode', 'server' );
?>

<div class="wrap woo-nostr-market-settings">
	<h1><?php esc_html_e( 'WooCommerce Nostr Market', 'woo-nostr-market' ); ?></h1>

	<!-- Hidden fields for JS -->
	<input type="hidden" id="woo-nostr-saved-pubkey" value="<?php echo esc_attr( $public_key ); ?>">

	<div class="woo-nostr-market-grid">
		<!-- Status Panel -->
		<div class="woo-nostr-market-card">
			<h2><?php esc_html_e( 'Status', 'woo-nostr-market' ); ?></h2>
			<table class="form-table">
				<tr>
					<th><?php esc_html_e( 'NIP-07 Extension', 'woo-nostr-market' ); ?></th>
					<td id="woo-nostr-nip07-status">
						<span class="dashicons dashicons-update spin"></span>
						<?php esc_html_e( 'Checking...', 'woo-nostr-market' ); ?>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Signing Mode', 'woo-nostr-market' ); ?></th>
					<td>
						<?php if ( 'browser' === $signing_mode ) : ?>
							<span class="status-ok">🔐 <?php esc_html_e( 'Browser Extension (Alby/nos2x)', 'woo-nostr-market' ); ?></span>
						<?php elseif ( $has_private_key ) : ?>
							<span class="status-warning">🔑 <?php esc_html_e( 'Server-side (nsec stored)', 'woo-nostr-market' ); ?></span>
						<?php else : ?>
							<span class="status-error">✗ <?php esc_html_e( 'Not configured', 'woo-nostr-market' ); ?></span>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Public Key (npub)', 'woo-nostr-market' ); ?></th>
					<td>
						<?php if ( ! empty( $npub ) ) : ?>
							<code class="woo-nostr-market-key"><?php echo esc_html( $npub ); ?></code>
						<?php else : ?>
							<em id="woo-nostr-connected-pubkey"><?php esc_html_e( 'Not connected', 'woo-nostr-market' ); ?></em>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Stall', 'woo-nostr-market' ); ?></th>
					<td>
						<?php if ( $stall_status['last_published'] ) : ?>
							<span class="status-ok">✓ 
								<?php
								printf(
									/* translators: %s: human-readable time difference */
									esc_html__( 'Published %s ago', 'woo-nostr-market' ),
									esc_html( human_time_diff( $stall_status['last_published'] ) )
								);
								?>
							</span>
						<?php else : ?>
							<span class="status-warning">○ <?php esc_html_e( 'Never published', 'woo-nostr-market' ); ?></span>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Products', 'woo-nostr-market' ); ?></th>
					<td>
						<?php
						printf(
							/* translators: %1$d: synced count, %2$d: total count */
							esc_html__( '%1$d of %2$d synced', 'woo-nostr-market' ),
							(int) $total_products - (int) $pending_count,
							(int) $total_products
						);
						?>
						<?php if ( $pending_count > 0 ) : ?>
							<span class="status-warning">(<?php echo esc_html( $pending_count ); ?> <?php esc_html_e( 'pending', 'woo-nostr-market' ); ?>)</span>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Relays', 'woo-nostr-market' ); ?></th>
					<td>
						<?php echo esc_html( count( $relay_urls ) ); ?> <?php esc_html_e( 'configured', 'woo-nostr-market' ); ?>
					</td>
				</tr>
			</table>
		</div>

		<!-- Quick Actions -->
		<div class="woo-nostr-market-card">
			<h2><?php esc_html_e( 'Quick Actions', 'woo-nostr-market' ); ?></h2>
			
			<!-- Browser Extension Signing (NIP-07) - Preferred -->
			<div class="woo-nostr-browser-signing" style="display: none;">
				<h3>🔐 <?php esc_html_e( 'Browser Extension Signing', 'woo-nostr-market' ); ?></h3>
				<p class="description"><?php esc_html_e( 'Sign events with Alby/nos2x. Your private key never touches the server.', 'woo-nostr-market' ); ?></p>
				
				<p id="woo-nostr-connect-status"></p>
				
				<button type="button" id="woo-nostr-connect-extension" class="button button-secondary">
					<?php esc_html_e( 'Connect Nostr Extension', 'woo-nostr-market' ); ?>
				</button>
				
				<div id="woo-nostr-connection-status" style="display: none; margin-top: 15px;">
					<p><strong><?php esc_html_e( 'Connected as:', 'woo-nostr-market' ); ?></strong> <span id="woo-nostr-connected-pubkey"></span></p>
				</div>

				<hr>

				<p id="woo-nostr-stall-status"></p>
				<button type="button" id="woo-nostr-publish-stall-nip07" class="button button-secondary">
					<?php esc_html_e( 'Publish Stall (Browser Sign)', 'woo-nostr-market' ); ?>
				</button>
				<p class="description"><?php esc_html_e( 'Create or update your store listing on Nostr.', 'woo-nostr-market' ); ?></p>

				<hr>

				<p id="woo-nostr-sync-status"></p>
				<div id="woo-nostr-sync-progress" style="display: none; margin: 10px 0;">
					<div style="background: #e0e0e0; border-radius: 4px; height: 20px; overflow: hidden;">
						<div class="progress-bar" style="background: #0073aa; height: 100%; width: 0%; transition: width 0.3s;"></div>
					</div>
				</div>
				<button type="button" id="woo-nostr-sync-products-nip07" class="button button-primary">
					<?php esc_html_e( 'Sync All Products (Browser Sign)', 'woo-nostr-market' ); ?>
				</button>
				<p class="description">
					<?php
					printf(
						/* translators: %d: number of products */
						esc_html__( 'Sign and publish all %d products. You\'ll approve each signing.', 'woo-nostr-market' ),
						(int) $total_products
					);
					?>
				</p>
			</div>

			<!-- Server-side Signing (Legacy) -->
			<div class="woo-nostr-server-signing">
				<h3>🔑 <?php esc_html_e( 'Server-side Signing', 'woo-nostr-market' ); ?></h3>
				
				<?php if ( ! $nak_available ) : ?>
					<div class="notice notice-warning inline">
						<p>
							<strong><?php esc_html_e( 'nak CLI not found.', 'woo-nostr-market' ); ?></strong>
							<?php esc_html_e( 'Install nak for server-side signing, or use browser extension above.', 'woo-nostr-market' ); ?>
						</p>
					</div>
				<?php endif; ?>

				<form method="post" class="woo-nostr-market-action-form">
					<?php wp_nonce_field( 'woo_nostr_market_settings', 'woo_nostr_market_nonce' ); ?>
					<input type="hidden" name="action_type" value="publish_stall">
					<button type="submit" class="button button-secondary" <?php disabled( ! $has_private_key ); ?>>
						<?php esc_html_e( 'Publish/Update Stall', 'woo-nostr-market' ); ?>
					</button>
				</form>

				<hr>

				<form method="post" class="woo-nostr-market-action-form">
					<?php wp_nonce_field( 'woo_nostr_market_settings', 'woo_nostr_market_nonce' ); ?>
					<input type="hidden" name="action_type" value="sync_all">
					<button type="submit" class="button button-primary" <?php disabled( ! $has_private_key ); ?>>
						<?php esc_html_e( 'Sync All Products', 'woo-nostr-market' ); ?>
					</button>
				</form>
			</div>
		</div>
	</div>

	<!-- Key Management -->
	<div class="woo-nostr-market-card woo-nostr-market-full-width">
		<h2><?php esc_html_e( 'Nostr Key Management', 'woo-nostr-market' ); ?></h2>
		
		<div class="notice notice-info inline" style="margin: 0 0 15px 0;">
			<p>
				<strong><?php esc_html_e( 'Recommended:', 'woo-nostr-market' ); ?></strong>
				<?php esc_html_e( 'Use browser extension signing (Alby, nos2x) above. Your private key stays in your browser — never touches the server.', 'woo-nostr-market' ); ?>
			</p>
		</div>

		<?php if ( $has_private_key ) : ?>
			<div class="notice notice-warning inline" style="margin: 0 0 15px 0;">
				<p>
					<?php esc_html_e( 'Server-side keys are configured. Consider switching to browser extension signing for better security.', 'woo-nostr-market' ); ?>
				</p>
			</div>
		<?php endif; ?>

		<div class="woo-nostr-market-key-actions woo-nostr-server-key-input">
			<h3><?php esc_html_e( 'Server-side Key Storage (Less Secure)', 'woo-nostr-market' ); ?></h3>
			
			<form method="post" class="woo-nostr-market-inline-form">
				<?php wp_nonce_field( 'woo_nostr_market_settings', 'woo_nostr_market_nonce' ); ?>
				<input type="hidden" name="action_type" value="generate_keys">
				<button type="submit" class="button" <?php disabled( ! $nak_available ); ?>>
					<?php esc_html_e( 'Generate New Keys', 'woo-nostr-market' ); ?>
				</button>
			</form>

			<span class="woo-nostr-market-or"><?php esc_html_e( 'or', 'woo-nostr-market' ); ?></span>

			<form method="post" class="woo-nostr-market-inline-form woo-nostr-market-import-form">
				<?php wp_nonce_field( 'woo_nostr_market_settings', 'woo_nostr_market_nonce' ); ?>
				<input type="hidden" name="action_type" value="import_key">
				<input type="password" name="import_key" placeholder="<?php esc_attr_e( 'nsec or hex private key', 'woo-nostr-market' ); ?>" class="regular-text" <?php disabled( ! $nak_available ); ?>>
				<button type="submit" class="button" <?php disabled( ! $nak_available ); ?>>
					<?php esc_html_e( 'Import Key', 'woo-nostr-market' ); ?>
				</button>
			</form>
		</div>
	</div>

	<!-- Settings Form -->
	<form method="post">
		<?php wp_nonce_field( 'woo_nostr_market_settings', 'woo_nostr_market_nonce' ); ?>
		<input type="hidden" name="action_type" value="save_settings">

		<div class="woo-nostr-market-card woo-nostr-market-full-width">
			<h2>🌐 <?php esc_html_e( 'Marketplace Protocols', 'woo-nostr-market' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Choose which marketplace protocols to publish to. Enable both for maximum visibility.', 'woo-nostr-market' ); ?></p>
			<table class="form-table">
				<tr>
					<th scope="row"><?php esc_html_e( 'NIP-15', 'woo-nostr-market' ); ?></th>
					<td>
						<?php $enable_nip15 = $this->settings->get( 'enable_nip15', true ); ?>
						<label>
							<input type="checkbox" name="enable_nip15" value="1" <?php checked( $enable_nip15 ); ?>>
							<?php esc_html_e( 'Enable NIP-15 (Structured Marketplace)', 'woo-nostr-market' ); ?>
						</label>
						<p class="description">
							<?php esc_html_e( 'Publishes kind:30017 (stalls) and kind:30018 (products). Compatible with:', 'woo-nostr-market' ); ?>
							<strong>Plebeian Market</strong>, <strong>LNbits NostrMarket</strong>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'NIP-99', 'woo-nostr-market' ); ?></th>
					<td>
						<?php $enable_nip99 = $this->settings->get( 'enable_nip99', true ); ?>
						<label>
							<input type="checkbox" name="enable_nip99" value="1" <?php checked( $enable_nip99 ); ?>>
							<?php esc_html_e( 'Enable NIP-99 (Classified Listings)', 'woo-nostr-market' ); ?>
						</label>
						<p class="description">
							<?php esc_html_e( 'Publishes kind:30402 (classified listings). Compatible with:', 'woo-nostr-market' ); ?>
							<strong>Shopstr</strong>, <strong>Amethyst</strong>, <?php esc_html_e( 'and other NIP-99 clients', 'woo-nostr-market' ); ?>
						</p>
					</td>
				</tr>
			</table>
		</div>

		<div class="woo-nostr-market-card woo-nostr-market-full-width">
			<h2>📡 <?php esc_html_e( 'Relay Configuration', 'woo-nostr-market' ); ?></h2>
			<table class="form-table">
				<tr>
					<th scope="row">
						<label for="relay_urls"><?php esc_html_e( 'Relay URLs', 'woo-nostr-market' ); ?></label>
					</th>
					<td>
						<textarea name="relay_urls" id="relay_urls" rows="5" class="large-text code"><?php echo esc_textarea( implode( "\n", $relay_urls ) ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Enter one relay URL per line. Must start with wss:// or ws://', 'woo-nostr-market' ); ?></p>
						<p class="description">
							<?php esc_html_e( 'Recommended:', 'woo-nostr-market' ); ?>
							<code>wss://relay.damus.io</code>,
							<code>wss://nos.lol</code>,
							<code>wss://relay.nostr.band</code>
						</p>
					</td>
				</tr>
			</table>
		</div>

			<div class="woo-nostr-market-card woo-nostr-market-full-width">
			<h2>📦 <?php esc_html_e( 'Order Receiving', 'woo-nostr-market' ); ?></h2>
			<p class="description">
				<?php esc_html_e( 'To receive orders from Nostr marketplaces, you need the nostr-order-listener service.', 'woo-nostr-market' ); ?>
				<a href="https://github.com/RenAndKiwi/nostr-order-listener" target="_blank"><?php esc_html_e( 'Learn more →', 'woo-nostr-market' ); ?></a>
			</p>
			
			<table class="form-table">
				<tr>
					<th scope="row"><?php esc_html_e( 'Webhook URL', 'woo-nostr-market' ); ?></th>
					<td>
						<?php
						$webhook_url = rest_url( 'woo-nostr-market/v1/order-webhook' );
						?>
						<code style="background: #f0f0f0; padding: 5px 10px; display: inline-block;"><?php echo esc_html( $webhook_url ); ?></code>
						<button type="button" class="button button-small" onclick="navigator.clipboard.writeText('<?php echo esc_js( $webhook_url ); ?>'); this.textContent='Copied!';">
							<?php esc_html_e( 'Copy', 'woo-nostr-market' ); ?>
						</button>
						<p class="description"><?php esc_html_e( 'Provide this URL when registering with the nostr-order-listener service.', 'woo-nostr-market' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="webhook_secret"><?php esc_html_e( 'Webhook Secret', 'woo-nostr-market' ); ?></label>
					</th>
					<td>
						<?php
						$has_webhook_secret = ! empty( $this->settings->get( 'webhook_secret' ) );
						$generated_secret   = wp_generate_password( 32, false );
						?>
						<input type="password" name="webhook_secret" id="webhook_secret" value="" class="regular-text" placeholder="<?php echo $has_webhook_secret ? '••••••••••••••••' : esc_attr( $generated_secret ); ?>">
						<?php if ( ! $has_webhook_secret ) : ?>
							<button type="button" class="button button-small" onclick="document.getElementById('webhook_secret').value='<?php echo esc_js( $generated_secret ); ?>'; document.getElementById('webhook_secret').type='text';">
								<?php esc_html_e( 'Generate', 'woo-nostr-market' ); ?>
							</button>
						<?php endif; ?>
						<p class="description">
							<?php if ( $has_webhook_secret ) : ?>
								<?php esc_html_e( 'Webhook secret is configured. Enter a new secret to replace it.', 'woo-nostr-market' ); ?>
							<?php else : ?>
								<?php esc_html_e( 'Enter a secure secret (min 16 characters). This must match the secret configured in nostr-order-listener.', 'woo-nostr-market' ); ?>
							<?php endif; ?>
						</p>
					</td>
				</tr>
				<tr>
					<th scope="row"><?php esc_html_e( 'Status', 'woo-nostr-market' ); ?></th>
					<td>
						<?php
						$order_listener = woo_nostr_market()->order_listener;
						$is_active = $order_listener && $order_listener->is_active();
						?>
						<?php if ( $is_active ) : ?>
							<span style="color: green;">✓ <?php esc_html_e( 'Ready to receive orders', 'woo-nostr-market' ); ?></span>
						<?php elseif ( empty( $this->settings->get_private_key() ) ) : ?>
							<span style="color: orange;">⚠ <?php esc_html_e( 'Configure Nostr keys first', 'woo-nostr-market' ); ?></span>
						<?php elseif ( ! $has_webhook_secret ) : ?>
							<span style="color: orange;">⚠ <?php esc_html_e( 'Set webhook secret to enable order receiving', 'woo-nostr-market' ); ?></span>
						<?php else : ?>
							<span style="color: red;">✗ <?php esc_html_e( 'Not configured', 'woo-nostr-market' ); ?></span>
						<?php endif; ?>
					</td>
				</tr>
			</table>
		</div>

		<div class="woo-nostr-market-card woo-nostr-market-full-width">
			<h2>⚡ <?php esc_html_e( 'BTCPay Server', 'woo-nostr-market' ); ?></h2>
			<p class="description"><?php esc_html_e( 'Configure BTCPay Server for Lightning invoice generation. Required for order processing.', 'woo-nostr-market' ); ?></p>
			<table class="form-table">
				<tr>
					<th scope="row">
						<label for="btcpay_url"><?php esc_html_e( 'BTCPay Server URL', 'woo-nostr-market' ); ?></label>
					</th>
					<td>
						<input type="url" name="btcpay_url" id="btcpay_url" value="<?php echo esc_attr( $btcpay_url ); ?>" class="regular-text" placeholder="https://btcpay.example.com">
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="btcpay_store_id"><?php esc_html_e( 'Store ID', 'woo-nostr-market' ); ?></label>
					</th>
					<td>
						<?php $btcpay_store_id = $this->settings->get( 'btcpay_store_id', '' ); ?>
						<input type="text" name="btcpay_store_id" id="btcpay_store_id" value="<?php echo esc_attr( $btcpay_store_id ); ?>" class="regular-text" placeholder="store-id-here">
						<p class="description"><?php esc_html_e( 'Find this in BTCPay Server → Settings → General → Store ID', 'woo-nostr-market' ); ?></p>
					</td>
				</tr>
				<tr>
					<th scope="row">
						<label for="btcpay_api_key"><?php esc_html_e( 'API Key', 'woo-nostr-market' ); ?></label>
					</th>
					<td>
						<input type="password" name="btcpay_api_key" id="btcpay_api_key" value="" class="regular-text" placeholder="<?php echo $has_btcpay_key ? '••••••••' : ''; ?>">
						<p class="description">
							<?php if ( $has_btcpay_key ) : ?>
								<?php esc_html_e( 'API key is saved. Enter a new key to replace it.', 'woo-nostr-market' ); ?>
							<?php else : ?>
								<?php esc_html_e( 'Create an API key in BTCPay Server with invoice permissions.', 'woo-nostr-market' ); ?>
							<?php endif; ?>
						</p>
					</td>
				</tr>
			</table>
		</div>

		<div class="woo-nostr-market-card woo-nostr-market-full-width">
			<h2>⚡ <?php esc_html_e( 'Lightning Address (Fallback)', 'woo-nostr-market' ); ?></h2>
			<p class="description"><?php esc_html_e( 'If BTCPay is not configured, this Lightning address will be used in payment requests.', 'woo-nostr-market' ); ?></p>
			<table class="form-table">
				<tr>
					<th scope="row">
						<label for="lightning_address"><?php esc_html_e( 'Lightning Address', 'woo-nostr-market' ); ?></label>
					</th>
					<td>
						<?php $lightning_address = $this->settings->get( 'lightning_address', '' ); ?>
						<input type="text" name="lightning_address" id="lightning_address" value="<?php echo esc_attr( $lightning_address ); ?>" class="regular-text" placeholder="you@getalby.com">
						<p class="description"><?php esc_html_e( 'e.g., yourname@getalby.com, yourname@walletofsatoshi.com', 'woo-nostr-market' ); ?></p>
					</td>
				</tr>
			</table>
		</div>

		<div class="woo-nostr-market-card woo-nostr-market-full-width">
			<h2><?php esc_html_e( 'Stall Information', 'woo-nostr-market' ); ?></h2>
			<p class="description"><?php esc_html_e( 'This information is pulled from your WooCommerce settings.', 'woo-nostr-market' ); ?></p>
			<table class="form-table">
				<tr>
					<th><?php esc_html_e( 'Store Name', 'woo-nostr-market' ); ?></th>
					<td>
						<strong><?php echo esc_html( $stall_status['name'] ); ?></strong>
						<a href="<?php echo esc_url( admin_url( 'options-general.php' ) ); ?>" class="button-link"><?php esc_html_e( 'Edit', 'woo-nostr-market' ); ?></a>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Description', 'woo-nostr-market' ); ?></th>
					<td>
						<?php echo esc_html( $stall_status['description'] ?: __( '(none)', 'woo-nostr-market' ) ); ?>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Currency', 'woo-nostr-market' ); ?></th>
					<td>
						<strong><?php echo esc_html( strtoupper( $stall_status['currency'] ) ); ?></strong>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings' ) ); ?>" class="button-link"><?php esc_html_e( 'Edit', 'woo-nostr-market' ); ?></a>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Shipping Zones', 'woo-nostr-market' ); ?></th>
					<td>
						<?php echo esc_html( $stall_status['shipping_zones'] ); ?> <?php esc_html_e( 'zones configured', 'woo-nostr-market' ); ?>
						<a href="<?php echo esc_url( admin_url( 'admin.php?page=wc-settings&tab=shipping' ) ); ?>" class="button-link"><?php esc_html_e( 'Manage', 'woo-nostr-market' ); ?></a>
					</td>
				</tr>
				<tr>
					<th><?php esc_html_e( 'Stall ID', 'woo-nostr-market' ); ?></th>
					<td>
						<code><?php echo esc_html( $stall_status['stall_id'] ); ?></code>
					</td>
				</tr>
			</table>
		</div>

		<?php submit_button( __( 'Save Settings', 'woo-nostr-market' ) ); ?>
	</form>
</div>
