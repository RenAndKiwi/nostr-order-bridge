<?php
/**
 * Admin page class for plugin settings.
 *
 * @package WooNostrMarket
 */

defined( 'ABSPATH' ) || exit;

/**
 * Class WooNostrMarket_Admin_Page
 *
 * Handles the WordPress admin settings page under WooCommerce.
 */
class WooNostrMarket_Admin_Page {

	/**
	 * Settings instance.
	 *
	 * @var WooNostrMarket_Settings
	 */
	private $settings;

	/**
	 * Nostr client instance.
	 *
	 * @var WooNostrMarket_Nostr_Client
	 */
	private $nostr_client;

	/**
	 * Stall manager instance.
	 *
	 * @var WooNostrMarket_Stall_Manager
	 */
	private $stall_manager;

	/**
	 * Product sync instance.
	 *
	 * @var WooNostrMarket_Product_Sync
	 */
	private $product_sync;

	/**
	 * Constructor.
	 *
	 * @param WooNostrMarket_Settings      $settings      Settings instance.
	 * @param WooNostrMarket_Nostr_Client  $nostr_client  Nostr client instance.
	 * @param WooNostrMarket_Stall_Manager $stall_manager Stall manager instance.
	 * @param WooNostrMarket_Product_Sync  $product_sync  Product sync instance.
	 */
	public function __construct(
		WooNostrMarket_Settings $settings,
		WooNostrMarket_Nostr_Client $nostr_client,
		WooNostrMarket_Stall_Manager $stall_manager,
		WooNostrMarket_Product_Sync $product_sync
	) {
		$this->settings      = $settings;
		$this->nostr_client  = $nostr_client;
		$this->stall_manager = $stall_manager;
		$this->product_sync  = $product_sync;

		$this->init_hooks();
	}

	/**
	 * Initialize hooks.
	 */
	private function init_hooks() {
		add_action( 'admin_menu', array( $this, 'add_menu_page' ) );
		add_action( 'admin_init', array( $this, 'handle_form_submission' ) );
		add_action( 'admin_notices', array( $this, 'show_admin_notices' ) );
	}

	/**
	 * Add submenu page under WooCommerce.
	 */
	public function add_menu_page() {
		add_submenu_page(
			'woocommerce',
			__( 'Nostr Market', 'woo-nostr-market' ),
			__( 'Nostr Market', 'woo-nostr-market' ),
			'manage_woocommerce',
			'woo-nostr-market',
			array( $this, 'render_page' )
		);
	}

	/**
	 * Handle form submissions.
	 */
	public function handle_form_submission() {
		if ( ! isset( $_POST['woo_nostr_market_nonce'] ) ) {
			return;
		}

		if ( ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['woo_nostr_market_nonce'] ) ), 'woo_nostr_market_settings' ) ) {
			add_settings_error( 'woo_nostr_market', 'nonce_failed', __( 'Security check failed.', 'woo-nostr-market' ), 'error' );
			return;
		}

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			add_settings_error( 'woo_nostr_market', 'no_permission', __( 'You do not have permission to modify these settings.', 'woo-nostr-market' ), 'error' );
			return;
		}

		$action = isset( $_POST['action_type'] ) ? sanitize_text_field( wp_unslash( $_POST['action_type'] ) ) : '';

		switch ( $action ) {
			case 'save_settings':
				$this->save_settings();
				break;

			case 'generate_keys':
				$this->generate_keys();
				break;

			case 'import_key':
				$this->import_key();
				break;

			case 'publish_stall':
				$this->publish_stall();
				break;

			case 'sync_all':
				$this->sync_all_products();
				break;
		}
	}

	/**
	 * Save settings.
	 */
	private function save_settings() {
		// Relay URLs.
		if ( isset( $_POST['relay_urls'] ) ) {
			$relays = sanitize_textarea_field( wp_unslash( $_POST['relay_urls'] ) );
			$relays = array_filter( array_map( 'trim', explode( "\n", $relays ) ) );
			$relays = array_filter( $relays, function( $url ) {
				return preg_match( '/^wss?:\/\//', $url );
			} );
			$this->settings->set( 'relay_urls', $relays );
		}

		// BTCPay URL.
		if ( isset( $_POST['btcpay_url'] ) ) {
			$this->settings->set( 'btcpay_url', esc_url_raw( wp_unslash( $_POST['btcpay_url'] ) ) );
		}

		// BTCPay API Key.
		if ( isset( $_POST['btcpay_api_key'] ) && ! empty( $_POST['btcpay_api_key'] ) ) {
			$this->settings->set( 'btcpay_api_key', sanitize_text_field( wp_unslash( $_POST['btcpay_api_key'] ) ) );
		}

		// BTCPay Store ID.
		if ( isset( $_POST['btcpay_store_id'] ) ) {
			$this->settings->set( 'btcpay_store_id', sanitize_text_field( wp_unslash( $_POST['btcpay_store_id'] ) ) );
		}

		// Lightning Address.
		if ( isset( $_POST['lightning_address'] ) ) {
			$this->settings->set( 'lightning_address', sanitize_text_field( wp_unslash( $_POST['lightning_address'] ) ) );
		}

		// Webhook Secret.
		if ( isset( $_POST['webhook_secret'] ) && ! empty( $_POST['webhook_secret'] ) ) {
			$secret = sanitize_text_field( wp_unslash( $_POST['webhook_secret'] ) );
			if ( strlen( $secret ) < 16 ) {
				add_settings_error( 'woo_nostr_market', 'weak_secret', __( 'Webhook secret must be at least 16 characters.', 'woo-nostr-market' ), 'error' );
			} else {
				$this->settings->set( 'webhook_secret', $secret );
			}
		}

		// Marketplace Protocols.
		$this->settings->set( 'enable_nip15', isset( $_POST['enable_nip15'] ) );
		$this->settings->set( 'enable_nip99', isset( $_POST['enable_nip99'] ) );

		add_settings_error( 'woo_nostr_market', 'settings_saved', __( 'Settings saved.', 'woo-nostr-market' ), 'success' );
	}

	/**
	 * Generate new Nostr keys.
	 */
	private function generate_keys() {
		$result = $this->nostr_client->generate_keypair();

		if ( is_wp_error( $result ) ) {
			add_settings_error( 'woo_nostr_market', 'key_gen_failed', $result->get_error_message(), 'error' );
			return;
		}

		$this->settings->set( 'nostr_private_key', $result['private_key'] );
		$this->settings->set( 'nostr_public_key', $result['public_key'] );

		add_settings_error(
			'woo_nostr_market',
			'keys_generated',
			__( 'New Nostr keys generated successfully!', 'woo-nostr-market' ),
			'success'
		);
	}

	/**
	 * Import existing Nostr key.
	 */
	private function import_key() {
		if ( ! isset( $_POST['import_key'] ) || empty( $_POST['import_key'] ) ) {
			add_settings_error( 'woo_nostr_market', 'no_key', __( 'Please provide a private key to import.', 'woo-nostr-market' ), 'error' );
			return;
		}

		$key = sanitize_text_field( wp_unslash( $_POST['import_key'] ) );

		// Check if it's nsec format and convert.
		if ( strpos( $key, 'nsec' ) === 0 ) {
			$converted = $this->nostr_client->nsec_to_hex( $key );
			if ( is_wp_error( $converted ) ) {
				add_settings_error( 'woo_nostr_market', 'convert_failed', $converted->get_error_message(), 'error' );
				return;
			}
			$key = $converted;
		}

		// Validate hex format (64 chars).
		if ( ! preg_match( '/^[a-fA-F0-9]{64}$/', $key ) ) {
			add_settings_error( 'woo_nostr_market', 'invalid_key', __( 'Invalid private key format. Expected 64-character hex or nsec.', 'woo-nostr-market' ), 'error' );
			return;
		}

		// Derive public key.
		$pubkey = $this->nostr_client->get_public_key( $key );
		if ( is_wp_error( $pubkey ) ) {
			add_settings_error( 'woo_nostr_market', 'pubkey_failed', $pubkey->get_error_message(), 'error' );
			return;
		}

		$this->settings->set( 'nostr_private_key', $key );
		$this->settings->set( 'nostr_public_key', $pubkey );

		add_settings_error(
			'woo_nostr_market',
			'key_imported',
			__( 'Private key imported successfully!', 'woo-nostr-market' ),
			'success'
		);
	}

	/**
	 * Publish stall to Nostr.
	 */
	private function publish_stall() {
		$validation = $this->stall_manager->validate();

		if ( ! $validation['valid'] ) {
			add_settings_error(
				'woo_nostr_market',
				'stall_invalid',
				implode( ' ', $validation['errors'] ),
				'error'
			);
			return;
		}

		$result = $this->stall_manager->publish_stall();

		if ( is_wp_error( $result ) ) {
			add_settings_error( 'woo_nostr_market', 'stall_failed', $result->get_error_message(), 'error' );
			return;
		}

		add_settings_error(
			'woo_nostr_market',
			'stall_published',
			$result['message'],
			$result['success'] ? 'success' : 'warning'
		);
	}

	/**
	 * Sync all products to Nostr.
	 */
	private function sync_all_products() {
		if ( ! $this->settings->is_configured() ) {
			add_settings_error( 'woo_nostr_market', 'not_configured', __( 'Please configure your Nostr keys first.', 'woo-nostr-market' ), 'error' );
			return;
		}

		$result = $this->product_sync->sync_all_products();

		$message = sprintf(
			/* translators: %1$d: successful syncs, %2$d: failed syncs, %3$d: total products */
			__( 'Sync complete: %1$d successful, %2$d failed out of %3$d products.', 'woo-nostr-market' ),
			$result['success'],
			$result['failed'],
			$result['total']
		);

		add_settings_error(
			'woo_nostr_market',
			'sync_complete',
			$message,
			$result['failed'] > 0 ? 'warning' : 'success'
		);
	}

	/**
	 * Show admin notices.
	 */
	public function show_admin_notices() {
		settings_errors( 'woo_nostr_market' );
	}

	/**
	 * Render the admin page.
	 */
	public function render_page() {
		// Check nak availability.
		$nak_available = $this->nostr_client->is_nak_available();

		// Get current settings.
		$public_key    = $this->settings->get_public_key();
		$has_private_key = ! empty( $this->settings->get_private_key() );
		$relay_urls    = $this->settings->get_relay_urls();
		$btcpay_url    = $this->settings->get_btcpay_url();
		$has_btcpay_key = ! empty( $this->settings->get_btcpay_api_key() );

		// Get stall status.
		$stall_status = $this->stall_manager->get_status();

		// Get product sync stats.
		$pending_count = $this->product_sync->get_pending_sync_count();
		$total_products = wp_count_posts( 'product' )->publish;

		// Get npub for display.
		$npub = '';
		if ( ! empty( $public_key ) ) {
			$npub_result = $this->nostr_client->hex_to_npub( $public_key );
			if ( ! is_wp_error( $npub_result ) ) {
				$npub = $npub_result;
			}
		}

		// Include the view.
		include WOO_NOSTR_MARKET_PLUGIN_DIR . 'admin/views/settings-page.php';
	}
}
